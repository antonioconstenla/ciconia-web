"""Collecte et restitution des messages (info, avertissements, erreurs)."""
