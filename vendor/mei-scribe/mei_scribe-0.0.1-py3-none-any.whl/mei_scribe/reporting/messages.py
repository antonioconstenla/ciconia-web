"""Structure simple pour les messages classés par sévérité.

Fournit une énumération de sévérités (INFO, WARNING, ERROR), un message
unitaire et un conteneur permettant de les accumuler. Aucune logique avancée
(formatage, i18n, filtrage...) n'est prévue à ce stade.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class Severity(str, Enum):
    """Niveaux de sévérité d'un message."""

    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"


@dataclass
class Message:
    """Un message de rapport avec sa sévérité."""

    severity: Severity
    text: str


@dataclass
class Report:
    """Conteneur accumulant des messages."""

    messages: list[Message] = field(default_factory=list)

    def add(self, severity: Severity, text: str) -> None:
        """Ajoute un message au rapport."""
        self.messages.append(Message(severity=severity, text=text))

    def info(self, text: str) -> None:
        """Ajoute un message d'information."""
        self.add(Severity.INFO, text)

    def warning(self, text: str) -> None:
        """Ajoute un avertissement."""
        self.add(Severity.WARNING, text)

    def error(self, text: str) -> None:
        """Ajoute une erreur."""
        self.add(Severity.ERROR, text)
