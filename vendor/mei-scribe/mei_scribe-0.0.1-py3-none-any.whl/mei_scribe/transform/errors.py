"""Erreurs sémantiques des transformations J7.2."""

from __future__ import annotations


class SemanticTransformError(ValueError):
    """La transformation CMN ou mensurale ne peut pas être réalisée sans perte."""
