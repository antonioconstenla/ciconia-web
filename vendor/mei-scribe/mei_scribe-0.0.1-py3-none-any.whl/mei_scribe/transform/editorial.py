"""Projection EDITORIAL_UNCERTAINTY_V1 vers les siblings CMN et mensural."""

from __future__ import annotations

from dataclasses import replace

from mei_scribe.model.document import (
    DamageDirective,
    GapDirective,
    InputDocument,
    InputEventAddress,
    InputNote,
    StructuredDirective,
    SuppliedDirective,
    UnclearDirective,
)
from mei_scribe.signals.ligatures import resolve_ligatures
from mei_scribe.transform.clefs import (
    ResolvedSuppliedClefTarget,
    modern_clef_for_diplomatic_clef,
    resolve_supplied_clef,
)
from mei_scribe.transform.errors import SemanticTransformError
from mei_scribe.transform.projection import (
    classify_projection_mode,
    is_diplomatic,
)
from mei_scribe.transform.model import (
    CmnDocument,
    CmnSuppliedInlineClef,
    EditorialAttrs,
    LyricEditorialEdit,
    MensuralClef,
    MensuralClefGroup,
    MensuralDocument,
    MensuralInlineClef,
    MensuralVoice,
    OutputDamage,
    OutputDiagnostic,
    OutputGap,
    ResolvedEditorialAttachment,
)


def project_editorial(
    document: InputDocument,
    cmn: CmnDocument,
    mensural: MensuralDocument,
) -> tuple[CmnDocument, MensuralDocument, tuple[OutputDiagnostic, ...]]:
    """Résout chaque directive éditoriale sur les deux siblings, sans perte silencieuse."""
    directives = [
        directive
        for directive in document.directives
        if isinstance(
            directive, (UnclearDirective, SuppliedDirective, DamageDirective, GapDirective)
        )
    ]
    event_directives = [
        directive
        for directive in directives
        if not _is_supplied_clef(directive) and not isinstance(directive, GapDirective)
    ]
    gap_directives = [
        directive for directive in directives if isinstance(directive, GapDirective)
    ]
    clef_directives = [
        directive
        for directive in directives
        if _is_supplied_clef(directive)
    ]
    if not event_directives and not clef_directives and not gap_directives:
        return cmn, mensural, ()

    diagnostics: list[OutputDiagnostic] = []
    start_directives = [
        directive
        for directive in event_directives
        if _is_ligature_start(directive)
    ]
    note_event_directives = [
        directive
        for directive in event_directives
        if not _is_ligature_start(directive)
    ]
    lyric_edits = _resolve_lyric_edits(document, note_event_directives)
    _require_ligature_membership_members(document, note_event_directives)
    for directive in event_directives:
        _require_one_to_one_event(
            _cmn_events(cmn), document, directive, sibling="CMN"
        )
        _require_mensural_one_to_one(document, mensural, directive)
        diagnostics.extend(_source_token_diagnostics(directive))
    for directive in gap_directives:
        diagnostics.extend(_source_token_diagnostics(directive))
    for directive in clef_directives:
        diagnostics.extend(_source_token_diagnostics(directive))

    cmn, mensural, start_diagnostics = _project_ligature_start_boundaries(
        document, cmn, mensural, start_directives
    )
    diagnostics.extend(start_diagnostics)

    cmn_attachments = _merge_gap_attachments(
        _attachments_for_cmn(document, cmn, note_event_directives, lyric_edits),
        _gap_attachments_for_cmn(cmn, gap_directives),
    )
    mensural_attachments = _merge_gap_attachments(
        _attachments_for_mensural(
            document, mensural, note_event_directives, lyric_edits
        ),
        _gap_attachments_for_mensural(mensural, gap_directives),
    )
    cmn, mensural, clef_diagnostics = _project_supplied_clefs(
        document, cmn, mensural, clef_directives
    )
    return (
        replace(cmn, editorial=cmn_attachments),
        replace(mensural, editorial=mensural_attachments),
        tuple(diagnostics) + clef_diagnostics,
    )


def _is_ligature_start(directive: StructuredDirective) -> bool:
    return isinstance(directive, UnclearDirective) and directive.target == "ligature-start"


def _ligature_provenance_key(
    source_xml_ids: tuple[str, ...],
) -> tuple[str | None, str | None]:
    staff = source_xml_ids[0] if source_xml_ids else None
    pedal = source_xml_ids[1] if len(source_xml_ids) > 1 else None
    return (staff, pedal)


def _is_supplied_clef(directive: StructuredDirective) -> bool:
    return isinstance(directive, SuppliedDirective) and directive.target == "clef"


def _project_supplied_clefs(
    document: InputDocument,
    cmn: CmnDocument,
    mensural: MensuralDocument,
    directives: list[StructuredDirective],
) -> tuple[CmnDocument, MensuralDocument, tuple[OutputDiagnostic, ...]]:
    if not directives:
        return cmn, mensural, ()

    supplied = [directive for directive in directives if isinstance(directive, SuppliedDirective)]
    resolved = [resolve_supplied_clef(document, directive) for directive in supplied]
    _assert_unique_supplied_clefs(supplied, resolved)

    initial_by_voice = {
        target.voice_identity: (directive, target)
        for directive, target in zip(supplied, resolved, strict=True)
        if target.kind == "initial"
    }
    inline_pairs = [
        (directive, target)
        for directive, target in zip(supplied, resolved, strict=True)
        if target.kind == "inline"
    ]

    cmn_voices = []
    for voice in cmn.voices:
        pair = initial_by_voice.get(voice.identity)
        if pair is None:
            cmn_voices.append(voice)
            continue
        directive, target = pair
        expected = modern_clef_for_diplomatic_clef(target.source_clef)
        if (voice.clef.shape, voice.clef.line, voice.clef.dis, voice.clef.dis_place) != (
            expected.shape,
            expected.line,
            expected.dis,
            expected.dis_place,
        ):
            raise SemanticTransformError(
                _directive_ctx(
                    directive,
                    "supplied clef would change the CMN projected clef value",
                )
            )
        cmn_voices.append(
            replace(voice, clef_supplied=_editorial_attrs_for_clef(directive))
        )

    mensural_voices = []
    for voice in mensural.voices:
        pair = initial_by_voice.get(voice.identity)
        events = _apply_inline_supplied_clefs(voice, inline_pairs)
        if pair is None:
            mensural_voices.append(
                voice if events is voice.events else replace(voice, events=events)
            )
            continue
        directive, target = pair
        if isinstance(voice.clefs, MensuralClefGroup):
            raise SemanticTransformError(
                _directive_ctx(
                    directive,
                    "supplied:target=clef with clefGrp is deferred",
                )
            )
        if not isinstance(voice.clefs, MensuralClef):
            raise SemanticTransformError(
                _directive_ctx(
                    directive,
                    "supplied initial clef requires a single diplomatic clef",
                )
            )
        if (voice.clefs.shape, voice.clefs.line) != (
            target.source_clef.shape,
            target.source_clef.line,
        ):
            raise SemanticTransformError(
                _directive_ctx(
                    directive,
                    "supplied clef would change the mensural diplomatic clef value",
                )
            )
        mensural_voices.append(
            replace(
                voice,
                events=events,
                clef_supplied=_editorial_attrs_for_clef(directive),
            )
        )

    inline_cmn = tuple(
        CmnSuppliedInlineClef(
            voice_identity=target.voice_identity,
            measure_n=target.measure_n or directive.anchor.measure_n,
            insert_before_ordinal=target.insert_before_ordinal
            or directive.anchor.ordinal,
            clef=modern_clef_for_diplomatic_clef(target.source_clef),
            attrs=_editorial_attrs_for_clef(directive),
        )
        for directive, target in inline_pairs
    )
    return (
        replace(
            cmn,
            voices=tuple(cmn_voices),
            supplied_inline_clefs=cmn.supplied_inline_clefs + inline_cmn,
        ),
        replace(mensural, voices=tuple(mensural_voices)),
        (),
    )


def _apply_inline_supplied_clefs(
    voice: MensuralVoice,
    inline_pairs: list[tuple[SuppliedDirective, ResolvedSuppliedClefTarget]],
):
    updates = {
        target.inline_source_xml_id: (directive, target)
        for directive, target in inline_pairs
        if target.voice_identity == voice.identity and target.inline_source_xml_id
    }
    if not updates:
        return voice.events
    events = []
    seen: set[str] = set()
    for event in voice.events:
        if not isinstance(event, MensuralInlineClef) or not event.provenance.source_xml_ids:
            events.append(event)
            continue
        xml_id = event.provenance.source_xml_ids[0]
        pair = updates.get(xml_id)
        if pair is None:
            events.append(event)
            continue
        directive, target = pair
        if (event.shape, event.line) != (
            target.source_clef.shape,
            target.source_clef.line,
        ):
            raise SemanticTransformError(
                _directive_ctx(
                    directive,
                    "supplied clef would change the mensural inline clef value",
                )
            )
        seen.add(xml_id)
        events.append(replace(event, supplied=_editorial_attrs_for_clef(directive)))
    missing = set(updates) - seen
    if missing:
        sample = next(iter(missing))
        directive, _target = updates[sample]
        raise SemanticTransformError(
            _directive_ctx(
                directive,
                f"supplied inline clef {sample!r} unresolved in mensural output",
            )
        )
    return tuple(events)


def _assert_unique_supplied_clefs(
    directives: list[SuppliedDirective],
    resolved: list[ResolvedSuppliedClefTarget],
) -> None:
    seen_initial: set[str] = set()
    seen_inline: set[str] = set()
    for directive, target in zip(directives, resolved, strict=True):
        if target.kind == "initial":
            if target.voice_identity in seen_initial:
                raise SemanticTransformError(
                    _directive_ctx(
                        directive,
                        "duplicate supplied:target=clef on the initial clef",
                    )
                )
            seen_initial.add(target.voice_identity)
            continue
        key = target.inline_source_xml_id or ""
        if key in seen_inline:
            raise SemanticTransformError(
                _directive_ctx(
                    directive,
                    "duplicate supplied:target=clef on the same inline clef",
                )
            )
        seen_inline.add(key)


def _editorial_attrs_for_clef(directive: StructuredDirective) -> EditorialAttrs:
    if not isinstance(directive, SuppliedDirective):
        raise TypeError(f"expected SuppliedDirective, got {type(directive)!r}")
    return EditorialAttrs(
        reason=directive.reason,
        agent=directive.agent,
        evidence=directive.evidence,
        cert=directive.cert,
        source_token=directive.source_token,
    )


def _attachments_for_cmn(
    document: InputDocument,
    cmn: CmnDocument,
    directives: list[StructuredDirective],
    lyric_edits: dict[UnclearDirective, LyricEditorialEdit],
) -> tuple[ResolvedEditorialAttachment, ...]:
    grouped: dict[tuple[str, int, int], list[StructuredDirective]] = {}
    coords: dict[tuple[str, int, int], tuple[str, int, int]] = {}
    for directive in directives:
        event = _require_one_to_one_event(
            _cmn_events(cmn), document, directive, sibling="CMN"
        )
        measure_n = _cmn_measure_n(cmn, event, directive.anchor)
        source_key = _anchor_key(directive.anchor)
        grouped.setdefault(source_key, []).append(directive)
        coords[source_key] = (directive.anchor.voice_identity, measure_n, event.ordinal)
    return tuple(
        _attachment_from_group(
            group, *coords[key], document=document, lyric_edits=lyric_edits
        )
        for key, group in grouped.items()
    )


def _attachments_for_mensural(
    document: InputDocument,
    mensural: MensuralDocument,
    directives: list[StructuredDirective],
    lyric_edits: dict[UnclearDirective, LyricEditorialEdit],
) -> tuple[ResolvedEditorialAttachment, ...]:
    grouped: dict[tuple[str, int], list[StructuredDirective]] = {}
    coords: dict[tuple[str, int], tuple[str, None, int]] = {}
    for directive in directives:
        event, voice_identity = _require_mensural_one_to_one(
            document, mensural, directive
        )
        output_key = (voice_identity, event.ordinal)
        grouped.setdefault(output_key, []).append(directive)
        coords[output_key] = (voice_identity, None, event.ordinal)
    return tuple(
        _attachment_from_group(
            group, *coords[key], document=document, lyric_edits=lyric_edits
        )
        for key, group in grouped.items()
    )


def _attachment_from_group(
    group: list[StructuredDirective],
    voice_identity: str,
    measure_n: int | None,
    ordinal: int,
    *,
    document: InputDocument,
    lyric_edits: dict[UnclearDirective, LyricEditorialEdit],
) -> ResolvedEditorialAttachment:
    wrappers: list[tuple[str, EditorialAttrs]] = []
    edits: list[LyricEditorialEdit] = []
    damage: OutputDamage | None = None
    supplied_source_xml_id: str | None = None
    for directive in group:
        if isinstance(directive, DamageDirective):
            damage = OutputDamage(
                agent=directive.agent,
                extent=directive.extent,
                atleast=directive.atleast,
                atmost=directive.atmost,
                unit=directive.unit,
            )
            continue
        attrs = EditorialAttrs(
            reason=directive.reason,
            agent=directive.agent,
            evidence=directive.evidence,
            cert=directive.cert,
            source_token=directive.source_token,
            mei_type=_event_mei_type(directive),
        )
        if isinstance(directive, UnclearDirective) and directive.target == "lyric":
            edits.append(lyric_edits[directive])
        elif isinstance(directive, UnclearDirective):
            wrappers.append(("unclear", attrs))
        elif isinstance(directive, SuppliedDirective):
            wrappers.append(("supplied", attrs))
            if directive.target == "note":
                carrier = document.event_at(
                    directive.anchor.voice_identity,
                    directive.anchor.measure_n,
                    directive.anchor.ordinal,
                )
                if isinstance(carrier, InputNote):
                    if (
                        supplied_source_xml_id is not None
                        and supplied_source_xml_id != carrier.source_xml_id
                    ):
                        raise SemanticTransformError(
                            "competing supplied:target=note carriers on one "
                            "output event"
                        )
                    supplied_source_xml_id = carrier.source_xml_id
    wrappers.sort(key=_wrapper_order)
    verse_ids = [edit.verse_n for edit in edits]
    if len(verse_ids) != len(set(verse_ids)):
        raise SemanticTransformError(
            "duplicate resolved lyric target on one output event"
        )
    return ResolvedEditorialAttachment(
        voice_identity=voice_identity,
        measure_n=measure_n,
        ordinal=ordinal,
        event_wrappers=tuple(wrappers),
        lyric_edits=tuple(edits),
        damage=damage,
        supplied_source_xml_id=supplied_source_xml_id,
    )


def _event_mei_type(directive: StructuredDirective) -> str | None:
    target = getattr(directive, "target", None)
    if target in {"dur", "pitch", "ligature-membership"}:
        return target
    return None


def _wrapper_order(item: tuple[str, EditorialAttrs]) -> int:
    """Canonical nest: pitch, ligature-membership, dur, then whole-note/supplied."""
    _element, attrs = item
    if attrs.mei_type == "pitch":
        return 0
    if attrs.mei_type == "ligature-membership":
        return 1
    if attrs.mei_type == "dur":
        return 2
    return 3


def _require_ligature_membership_members(
    document: InputDocument,
    directives: list[StructuredDirective],
) -> None:
    """Fail closed unless ligature-membership anchors a resolved ligature member."""
    membership = [
        directive
        for directive in directives
        if isinstance(directive, UnclearDirective)
        and directive.target == "ligature-membership"
    ]
    if not membership:
        return
    member_addresses = {
        address
        for ligature in resolve_ligatures(document)
        for address in ligature.member_addresses
    }
    for directive in membership:
        if directive.anchor not in member_addresses:
            raise SemanticTransformError(
                _directive_ctx(
                    directive,
                    "ligature-membership-not-member: "
                    "not a member of any resolved ligature",
                )
            )


def _project_ligature_start_boundaries(
    document: InputDocument,
    cmn: CmnDocument,
    mensural: MensuralDocument,
    directives: list[StructuredDirective],
) -> tuple[CmnDocument, MensuralDocument, tuple[OutputDiagnostic, ...]]:
    """Attach start-boundary uncertainty to ligature groups, never to notes."""
    starts = [
        directive
        for directive in directives
        if isinstance(directive, UnclearDirective)
        and directive.target == "ligature-start"
    ]
    if not starts:
        return cmn, mensural, ()

    resolved = resolve_ligatures(document)
    by_member: dict[InputEventAddress, list] = {}
    for ligature in resolved:
        for address in ligature.member_addresses:
            by_member.setdefault(address, []).append(ligature)

    attrs_by_key: dict[tuple[str | None, str | None], EditorialAttrs] = {}
    for directive in starts:
        hosts = by_member.get(directive.anchor, [])
        if len(hosts) != 1:
            raise SemanticTransformError(
                _directive_ctx(
                    directive,
                    "ligature-start-not-unique-ligature: "
                    "anchor must belong to exactly one resolved ligature",
                )
            )
        host = hosts[0]
        key = (host.staff_text_xml_id, host.pedal_xml_id)
        if key in attrs_by_key:
            raise SemanticTransformError(
                _directive_ctx(
                    directive,
                    "ligature-start-duplicate: "
                    "exactly one ligature-start per resolved ligature",
                )
            )
        attrs_by_key[key] = EditorialAttrs(
            reason=directive.reason,
            agent=directive.agent,
            evidence=directive.evidence,
            cert=directive.cert,
            source_token=directive.source_token,
            mei_type="ligature-start",
        )

    cmn_ligatures = tuple(
        replace(
            ligature,
            start_boundary=attrs_by_key.get(
                _ligature_provenance_key(ligature.provenance.source_xml_ids)
            ),
        )
        for ligature in cmn.ligatures
    )
    mensural_voices = tuple(
        replace(
            voice,
            ligatures=tuple(
                replace(
                    ligature,
                    start_boundary=attrs_by_key.get(
                        _ligature_provenance_key(ligature.provenance.source_xml_ids)
                    ),
                )
                for ligature in voice.ligatures
            ),
        )
        for voice in mensural.voices
    )
    diagnostics: list[OutputDiagnostic] = []
    for directive in starts:
        diagnostics.append(
            OutputDiagnostic(
                severity="WARNING",
                code="ligature-start-cmn-structural-deferred",
                feature="ligature-start",
                message=(
                    "ligature-start boundary uncertainty is serialized on "
                    "Mensural <unclear type=\"ligature-start\"><ligature/>; "
                    "CMN keeps bracketSpan on the preserved first member "
                    "without a structural parallel"
                ),
                voice_identity=directive.anchor.voice_identity,
                measure_n=directive.anchor.measure_n,
                ordinal=directive.anchor.ordinal,
                source_text=directive.source_text,
                source_xml_id=directive.source_xml_id,
            )
        )
    return (
        replace(cmn, ligatures=cmn_ligatures),
        replace(mensural, voices=mensural_voices),
        tuple(diagnostics),
    )


def _output_gap(directive: GapDirective) -> OutputGap:
    return OutputGap(
        reason=directive.reason,
        extent=directive.extent,
        unit=directive.unit,
        evidence=directive.evidence,
        cert=directive.cert,
        source_token=directive.source_token,
    )


def _gap_attachments_for_cmn(
    cmn: CmnDocument,
    directives: list[GapDirective],
) -> tuple[ResolvedEditorialAttachment, ...]:
    attachments: list[ResolvedEditorialAttachment] = []
    for directive in directives:
        event = _resolve_gap_host(_cmn_events(cmn), directive, sibling="CMN")
        measure_n = _cmn_measure_n(cmn, event, directive.anchor)
        attachments.append(
            _gap_attachment(
                directive,
                voice_identity=directive.anchor.voice_identity,
                measure_n=measure_n,
                ordinal=event.ordinal,
            )
        )
    return tuple(attachments)


def _gap_attachments_for_mensural(
    mensural: MensuralDocument,
    directives: list[GapDirective],
) -> tuple[ResolvedEditorialAttachment, ...]:
    events = [
        (event, voice.identity, None)
        for voice in mensural.voices
        for event in voice.events
        if hasattr(event, "provenance")
    ]
    attachments: list[ResolvedEditorialAttachment] = []
    for directive in directives:
        event = _resolve_gap_host(events, directive, sibling="mensural")
        voice_identity = next(
            voice.identity
            for voice in mensural.voices
            for candidate in voice.events
            if candidate is event
        )
        attachments.append(
            _gap_attachment(
                directive,
                voice_identity=voice_identity,
                measure_n=None,
                ordinal=event.ordinal,
            )
        )
    return tuple(attachments)


def _gap_attachment(
    directive: GapDirective,
    *,
    voice_identity: str,
    measure_n: int | None,
    ordinal: int,
) -> ResolvedEditorialAttachment:
    output = _output_gap(directive)
    return ResolvedEditorialAttachment(
        voice_identity=voice_identity,
        measure_n=measure_n,
        ordinal=ordinal,
        gap_before=output if directive.scope == "before" else None,
        gap_after=output if directive.scope == "after" else None,
    )


def _merge_gap_attachments(
    existing: tuple[ResolvedEditorialAttachment, ...],
    gaps: tuple[ResolvedEditorialAttachment, ...],
) -> tuple[ResolvedEditorialAttachment, ...]:
    by_coord: dict[tuple[str, int | None, int], ResolvedEditorialAttachment] = {
        (item.voice_identity, item.measure_n, item.ordinal): item for item in existing
    }
    order = [(item.voice_identity, item.measure_n, item.ordinal) for item in existing]
    for item in gaps:
        key = (item.voice_identity, item.measure_n, item.ordinal)
        current = by_coord.get(key)
        if current is None:
            by_coord[key] = item
            order.append(key)
            continue
        if item.gap_before is not None:
            if current.gap_before is not None:
                raise SemanticTransformError(
                    "duplicate gap scope=before on one output event"
                )
            current = replace(current, gap_before=item.gap_before)
        if item.gap_after is not None:
            if current.gap_after is not None:
                raise SemanticTransformError(
                    "duplicate gap scope=after on one output event"
                )
            current = replace(current, gap_after=item.gap_after)
        by_coord[key] = current
    return tuple(by_coord[key] for key in order)


def _resolve_gap_host(
    events: list[tuple[object, str, int | None]],
    directive: GapDirective,
    *,
    sibling: str,
) -> object:
    matches = [
        event
        for event, _voice, _measure_n in events
        if directive.anchor in event.provenance.source_addresses
    ]
    if not matches:
        raise SemanticTransformError(
            _directive_ctx(
                directive,
                f"editorial target unresolved in {sibling} output",
            )
        )
    if len(matches) > 1:
        raise SemanticTransformError(
            _directive_ctx(
                directive,
                f"editorial target ambiguous in {sibling} output "
                f"matches={len(matches)}",
            )
        )
    event = matches[0]
    addresses = event.provenance.source_addresses
    if len(addresses) == 1:
        return event
    if directive.scope == "before" and addresses[0] == directive.anchor:
        return event
    if directive.scope == "after" and addresses[-1] == directive.anchor:
        return event
    raise SemanticTransformError(
        _directive_ctx(
            directive,
            f"gap placement is ambiguous on a fused source-event chain in {sibling}; "
            "V1 allows only scope=before on the first member or "
            "scope=after on the last member",
        )
    )


def _resolve_lyric_edits(
    document: InputDocument,
    directives: list[StructuredDirective],
) -> dict[UnclearDirective, LyricEditorialEdit]:
    lyric_dirs = [
        directive
        for directive in directives
        if isinstance(directive, UnclearDirective) and directive.target == "lyric"
    ]
    grouped: dict[tuple[str, int, int], list[UnclearDirective]] = {}
    for directive in lyric_dirs:
        grouped.setdefault(_anchor_key(directive.anchor), []).append(directive)
    resolved: dict[UnclearDirective, LyricEditorialEdit] = {}
    for group in grouped.values():
        seen: dict[int | None, UnclearDirective] = {}
        for directive in group:
            edit = _resolve_one_lyric_edit(document, directive, group)
            previous = seen.get(edit.verse_n)
            if previous is not None:
                raise SemanticTransformError(
                    _directive_ctx(
                        directive,
                        "duplicate resolved lyric target "
                        f"verse={edit.verse_n!r}",
                    )
                )
            seen[edit.verse_n] = directive
            resolved[directive] = edit
    return resolved


def _resolve_one_lyric_edit(
    document: InputDocument,
    directive: UnclearDirective,
    group: list[UnclearDirective],
) -> LyricEditorialEdit:
    event = document.event_at(
        directive.anchor.voice_identity,
        directive.anchor.measure_n,
        directive.anchor.ordinal,
    )
    if not isinstance(event, InputNote):
        raise SemanticTransformError(
            _directive_ctx(directive, "target=lyric must resolve to a note")
        )
    attrs = EditorialAttrs(
        reason=directive.reason,
        agent=directive.agent,
        evidence=directive.evidence,
        cert=directive.cert,
        source_token=directive.source_token,
        extent=directive.extent,
        unit=directive.unit,
    )
    if directive.verse_n is not None:
        matches = [
            syllable
            for syllable in event.lyrics
            if syllable.verse_n == directive.verse_n
        ]
        if len(matches) > 1:
            raise SemanticTransformError(
                _directive_ctx(
                    directive,
                    "target=lyric is ambiguous: "
                    f"verse={directive.verse_n} has {len(matches)} syllable(s)",
                )
            )
        return LyricEditorialEdit(
            verse_n=directive.verse_n,
            attrs=attrs,
            placeholder=len(matches) == 0,
            source_xml_id=event.source_xml_id,
        )
    if len(event.lyrics) > 1:
        raise SemanticTransformError(
            _directive_ctx(
                directive,
                "target=lyric is ambiguous: "
                f"note has {len(event.lyrics)} syllable(s)",
            )
        )
    if len(event.lyrics) == 1:
        return LyricEditorialEdit(
            verse_n=event.lyrics[0].verse_n,
            attrs=attrs,
            placeholder=False,
            source_xml_id=event.source_xml_id,
        )
    # Zero native lyrics: unqualified → unnumbered placeholder (verse_n=None).
    # Distinct verse identities on the same note (e.g. unqualified + verse=2)
    # are allowed; duplicate resolved verse_n is rejected by the caller.
    # ``group`` remains for call-site parity; uniqueness is not gated on size.
    _ = group
    return LyricEditorialEdit(
        verse_n=None,
        attrs=attrs,
        placeholder=True,
        source_xml_id=event.source_xml_id,
    )


def _require_one_to_one_event(
    events: list[tuple[object, str, int | None]],
    document: InputDocument,
    directive: StructuredDirective,
    *,
    sibling: str,
) -> object:
    matches = [
        (event, voice, measure_n)
        for event, voice, measure_n in events
        if directive.anchor in event.provenance.source_addresses
    ]
    if not matches:
        raise SemanticTransformError(
            _directive_ctx(
                directive,
                f"editorial target unresolved in {sibling} output",
            )
        )
    if len(matches) > 1:
        raise SemanticTransformError(
            _directive_ctx(
                directive,
                f"editorial target ambiguous in {sibling} output "
                f"matches={len(matches)}",
            )
        )
    event, _voice, _measure = matches[0]
    if len(event.provenance.source_addresses) != 1:
        if not _may_attach_to_diplomatic_fused(document, directive):
            raise SemanticTransformError(
                _directive_ctx(
                    directive,
                    f"editorial-target-absorbed in {sibling}: "
                    "source event was consumed by a musical transform",
                )
            )
    return event


def _may_attach_to_diplomatic_fused(
    document: InputDocument, directive: StructuredDirective
) -> bool:
    """Narrow diplomatic fused-event attach: lyric uncertainty or supplied note."""
    if not is_diplomatic(classify_projection_mode(document)):
        return False
    if isinstance(directive, UnclearDirective) and directive.target == "lyric":
        return True
    if isinstance(directive, SuppliedDirective) and directive.target == "note":
        return True
    return False


def _require_mensural_one_to_one(
    document: InputDocument,
    mensural: MensuralDocument,
    directive: StructuredDirective,
) -> tuple[object, str]:
    events = [
        (event, voice.identity, None)
        for voice in mensural.voices
        for event in voice.events
        if hasattr(event, "provenance")
    ]
    event = _require_one_to_one_event(
        events, document, directive, sibling="mensural"
    )
    voice_identity = next(
        voice.identity
        for voice in mensural.voices
        for candidate in voice.events
        if candidate is event
    )
    return event, voice_identity


def _cmn_events(cmn: CmnDocument) -> list[tuple[object, str, int | None]]:
    located: list[tuple[object, str, int | None]] = []
    for measure in cmn.measures:
        for content in measure.voices:
            for event in content.events:
                located.append((event, content.voice_identity, measure.n))
    return located


def _cmn_measure_n(cmn: CmnDocument, event: object, anchor: InputEventAddress) -> int:
    for measure in cmn.measures:
        for content in measure.voices:
            if content.voice_identity != anchor.voice_identity:
                continue
            for candidate in content.events:
                if candidate is event:
                    return measure.n
    return anchor.measure_n


def _anchor_key(anchor: InputEventAddress) -> tuple[str, int, int]:
    return (anchor.voice_identity, anchor.measure_n, anchor.ordinal)


def _source_token_diagnostics(directive: StructuredDirective) -> tuple[OutputDiagnostic, ...]:
    token = getattr(directive, "source_token", None)
    if not token:
        return ()
    return (
        OutputDiagnostic(
            severity="WARNING",
            code="editorial-source-reference-deferred",
            feature="editorial-source",
            message=(
                f"source token {token!r} retained but not serialized as MEI @source"
            ),
            voice_identity=directive.anchor.voice_identity,
            measure_n=directive.anchor.measure_n,
            ordinal=directive.anchor.ordinal,
            source_text=directive.source_text,
            source_xml_id=directive.source_xml_id,
        ),
    )


def _directive_ctx(directive: StructuredDirective, message: str) -> str:
    anchor = directive.anchor
    return (
        f"voice={anchor.voice_identity!r} measure={anchor.measure_n} "
        f"ordinal={anchor.ordinal} xml:id={directive.source_xml_id!r}: {message} "
        f"in {directive.source_text!r}"
    )
