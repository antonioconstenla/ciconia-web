"""Validation et projection des clefs J7.2 (CMN et mensural)."""

from __future__ import annotations

from dataclasses import dataclass

from mei_scribe.model.document import (
    ClefGroupDirective,
    InputClef,
    InputDocument,
    InputEventAddress,
    InputInlineClef,
    InputMeasureRest,
    InputNote,
    InputRest,
    SuppliedDirective,
    Voice,
    is_rhythmic_event,
)
from mei_scribe.transform.errors import SemanticTransformError
from mei_scribe.transform.model import (
    CmnClef,
    MensuralClef,
    MensuralClefGroup,
    opening_clef_members,
)

_G2 = CmnClef(shape="G", line=2)
_G2_8VB = CmnClef(shape="G", line=2, dis=8, dis_place="below")


@dataclass(frozen=True)
class InitialClefPolicy:
    """One approved initial configuration and its CMN reading clef.

    ``source`` is an ordered diplomatic configuration: one clef, or the
    compound C4+F2 group. Lone C4 and C4+F2 are distinct rows.
    """

    source: tuple[InputClef, ...]
    cmn: CmnClef


INITIAL_CLEF_POLICY: tuple[InitialClefPolicy, ...] = (
    InitialClefPolicy((InputClef(shape="C", line=1),), _G2),
    InitialClefPolicy((InputClef(shape="C", line=2),), _G2),
    InitialClefPolicy((InputClef(shape="C", line=3),), _G2),
    InitialClefPolicy((InputClef(shape="C", line=4),), _G2_8VB),
    InitialClefPolicy((InputClef(shape="C", line=5),), _G2_8VB),
    InitialClefPolicy((InputClef(shape="F", line=3),), _G2_8VB),
    InitialClefPolicy((InputClef(shape="F", line=4),), _G2_8VB),
    InitialClefPolicy(
        (InputClef(shape="C", line=4), InputClef(shape="F", line=2)),
        _G2_8VB,
    ),
)

SUPPORTED_CLEF_GROUP: tuple[InputClef, ...] = INITIAL_CLEF_POLICY[-1].source


def _shape_line_key(
    members: tuple[InputClef, ...] | tuple[MensuralClef, ...],
) -> tuple[tuple[str, int], ...]:
    return tuple((member.shape, member.line) for member in members)


def _policy_for(
    members: tuple[InputClef, ...] | tuple[MensuralClef, ...],
) -> InitialClefPolicy | None:
    key = _shape_line_key(members)
    for row in INITIAL_CLEF_POLICY:
        if _shape_line_key(row.source) == key:
            return row
    return None


@dataclass(frozen=True)
class ResolvedSuppliedClefTarget:
    """Association fail-closed de ``supplied:target=clef`` vers une clef source."""

    kind: str
    voice_identity: str
    source_clef: InputClef
    inline_source_xml_id: str | None = None
    measure_n: int | None = None
    insert_before_ordinal: int | None = None


def first_voice_event_address(
    document: InputDocument, voice_identity: str
) -> InputEventAddress:
    """Adresse du premier événement musical de la voix (ordre source)."""
    for measure in document.measures:
        for content in measure.voices:
            if content.voice_identity != voice_identity:
                continue
            if not content.events:
                continue
            event = content.events[0]
            if isinstance(event, InputNote):
                kind = "note"
            elif isinstance(event, InputRest):
                kind = "rest"
            elif isinstance(event, InputMeasureRest):
                kind = "mRest"
            else:
                raise SemanticTransformError(
                    f"unsupported first event type {type(event)!r}"
                )
            return InputEventAddress(
                voice_identity=voice_identity,
                measure_n=content.measure_n,
                ordinal=event.ordinal,
                event_kind=kind,
            )
    raise SemanticTransformError(
        f"voice {voice_identity!r} has no musical events for clef anchoring"
    )


def _clef_groups_for_voice(
    document: InputDocument, voice_identity: str
) -> list[ClefGroupDirective]:
    return [
        directive
        for directive in document.directives
        if isinstance(directive, ClefGroupDirective)
        and directive.anchor.voice_identity == voice_identity
    ]


def diplomatic_clefs_for_voice(
    document: InputDocument, voice: Voice
) -> MensuralClef | MensuralClefGroup:
    """Clefs diplomatiques initiales supportées par J7.2."""
    groups = _clef_groups_for_voice(document, voice.identity)
    if len(groups) > 1:
        raise SemanticTransformError(
            f"multiple clefGrp directives for voice {voice.identity!r}"
        )
    if len(groups) == 1:
        group = groups[0]
        first = first_voice_event_address(document, voice.identity)
        if (
            group.anchor.voice_identity != first.voice_identity
            or group.anchor.measure_n != first.measure_n
            or group.anchor.ordinal != first.ordinal
        ):
            raise SemanticTransformError(
                f"clefGrp for voice {voice.identity!r} must be anchored "
                f"at the first musical event; got measure={group.anchor.measure_n} "
                f"ordinal={group.anchor.ordinal}"
            )
        row = _policy_for(group.clefs)
        if row is None or len(row.source) < 2:
            raise SemanticTransformError(
                f"unsupported diplomatic clef group for voice {voice.identity!r}: "
                f"{group.clefs!r}"
            )
        return MensuralClefGroup(
            members=tuple(
                MensuralClef(shape=clef.shape, line=clef.line) for clef in group.clefs
            ),
            source_text=group.source_text,
            source_xml_id=group.source_xml_id,
        )

    source = voice.initial_clef
    if source is None:
        raise SemanticTransformError(
            f"voice {voice.identity!r} has no initial diplomatic clef"
        )
    row = _policy_for((source,))
    if row is not None and len(row.source) == 1:
        return MensuralClef(shape=source.shape, line=source.line)
    raise SemanticTransformError(
        f"unsupported initial source clef {source.shape}{source.line} "
        f"for voice {voice.identity!r}"
    )


def modern_clef_for_members(members: tuple[MensuralClef, ...]) -> CmnClef:
    """Explicit source→CMN map from ``INITIAL_CLEF_POLICY`` (no tessitura)."""
    row = _policy_for(members)
    if row is None:
        raise SemanticTransformError(
            f"unsupported diplomatic clefs for CMN mapping: {members!r}"
        )
    return row.cmn


def modern_clef_for_voice(document: InputDocument, voice: Voice) -> CmnClef:
    """Clef moderne de lecture dérivée des clefs diplomatiques supportées."""
    diplomatic = diplomatic_clefs_for_voice(document, voice)
    try:
        return modern_clef_for_members(opening_clef_members(diplomatic))
    except SemanticTransformError as exc:
        raise SemanticTransformError(
            f"unsupported diplomatic clefs for CMN mapping of voice "
            f"{voice.identity!r}: {diplomatic!r}"
        ) from exc


def modern_clef_for_diplomatic_clef(clef: InputClef) -> CmnClef:
    """Modern reading clef for one diplomatic shape/line (inline or initial)."""
    return modern_clef_for_members((MensuralClef(shape=clef.shape, line=clef.line),))


def resolve_supplied_clef(
    document: InputDocument, directive: SuppliedDirective
) -> ResolvedSuppliedClefTarget:
    """Associe ``supplied:target=clef`` à une unique clef initiale ou intermédiaire."""
    if directive.target != "clef":
        raise SemanticTransformError(
            f"resolve_supplied_clef expected target=clef, got {directive.target!r}"
        )
    voice_identity = directive.anchor.voice_identity
    stream = _voice_event_stream(document, voice_identity)
    anchor_index = _index_of_anchor(stream, directive.anchor)
    if anchor_index is None:
        raise SemanticTransformError(
            _supplied_clef_ctx(
                directive,
                "supplied clef anchor did not resolve to a rhythmic event",
            )
        )

    if anchor_index > 0:
        previous = stream[anchor_index - 1][1]
        if isinstance(previous, InputInlineClef):
            if _clef_groups_for_voice(document, voice_identity):
                raise SemanticTransformError(
                    _supplied_clef_ctx(
                        directive,
                        "supplied:target=clef with clefGrp is deferred",
                    )
                )
            return ResolvedSuppliedClefTarget(
                kind="inline",
                voice_identity=voice_identity,
                source_clef=previous.clef,
                inline_source_xml_id=previous.source_xml_id,
                measure_n=directive.anchor.measure_n,
                insert_before_ordinal=directive.anchor.ordinal,
            )

    first = first_voice_event_address(document, voice_identity)
    if (
        directive.anchor.voice_identity == first.voice_identity
        and directive.anchor.measure_n == first.measure_n
        and directive.anchor.ordinal == first.ordinal
    ):
        if _clef_groups_for_voice(document, voice_identity):
            raise SemanticTransformError(
                _supplied_clef_ctx(
                    directive,
                    "supplied:target=clef with clefGrp is deferred",
                )
            )
        voice = _voice_by_identity(document, voice_identity)
        if voice.initial_clef is None:
            raise SemanticTransformError(
                _supplied_clef_ctx(
                    directive,
                    "supplied:target=clef has no initial staffDef clef",
                )
            )
        return ResolvedSuppliedClefTarget(
            kind="initial",
            voice_identity=voice_identity,
            source_clef=voice.initial_clef,
            measure_n=first.measure_n,
        )

    raise SemanticTransformError(
        _supplied_clef_ctx(
            directive,
            "supplied:target=clef is ambiguous: StaffText is not on the "
            "first event and no unique immediately preceding inline clef",
        )
    )


def _voice_event_stream(
    document: InputDocument, voice_identity: str
) -> list[tuple[int, object]]:
    stream: list[tuple[int, object]] = []
    for measure in document.measures:
        for content in measure.voices:
            if content.voice_identity != voice_identity:
                continue
            for event in content.events:
                stream.append((content.measure_n, event))
    return stream


def _index_of_anchor(
    stream: list[tuple[int, object]], anchor: InputEventAddress
) -> int | None:
    for index, (measure_n, event) in enumerate(stream):
        if not is_rhythmic_event(event):
            continue
        if (
            measure_n == anchor.measure_n
            and getattr(event, "ordinal", None) == anchor.ordinal
        ):
            return index
    return None


def _voice_by_identity(document: InputDocument, voice_identity: str) -> Voice:
    for voice in document.voices_in_order():
        if voice.identity == voice_identity:
            return voice
    raise SemanticTransformError(f"unknown voice {voice_identity!r}")


def _supplied_clef_ctx(directive: SuppliedDirective, message: str) -> str:
    anchor = directive.anchor
    return (
        f"voice={anchor.voice_identity!r} measure={anchor.measure_n} "
        f"ordinal={anchor.ordinal} xml:id={directive.source_xml_id!r}: "
        f"{message} in {directive.source_text!r}"
    )
