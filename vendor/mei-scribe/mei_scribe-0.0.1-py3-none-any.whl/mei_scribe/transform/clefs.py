"""Validation et projection des clefs J7.2 (CMN et mensural)."""

from __future__ import annotations

from mei_scribe.model.document import (
    ClefGroupDirective,
    InputClef,
    InputDocument,
    InputEventAddress,
    InputMeasureRest,
    InputNote,
    InputRest,
    Voice,
)
from mei_scribe.transform.errors import SemanticTransformError
from mei_scribe.transform.model import (
    CmnClef,
    MensuralClef,
    MensuralClefGroup,
    opening_clef_members,
)

SUPPORTED_CLEF_GROUP: tuple[InputClef, ...] = (
    InputClef(shape="C", line=4),
    InputClef(shape="F", line=2),
)


def first_voice_event_address(
    document: InputDocument, voice_identity: str
) -> InputEventAddress:
    """Adresse du premier événement musical de la voix (ordre source)."""
    for measure in document.measures:
        for content in measure.voices:
            if content.voice_identity != voice_identity:
                continue
            if not content.events:
                continue
            event = content.events[0]
            if isinstance(event, InputNote):
                kind = "note"
            elif isinstance(event, InputRest):
                kind = "rest"
            elif isinstance(event, InputMeasureRest):
                kind = "mRest"
            else:
                raise SemanticTransformError(
                    f"unsupported first event type {type(event)!r}"
                )
            return InputEventAddress(
                voice_identity=voice_identity,
                measure_n=content.measure_n,
                ordinal=event.ordinal,
                event_kind=kind,
            )
    raise SemanticTransformError(
        f"voice {voice_identity!r} has no musical events for clef anchoring"
    )


def _clef_groups_for_voice(
    document: InputDocument, voice_identity: str
) -> list[ClefGroupDirective]:
    return [
        directive
        for directive in document.directives
        if isinstance(directive, ClefGroupDirective)
        and directive.anchor.voice_identity == voice_identity
    ]


def diplomatic_clefs_for_voice(
    document: InputDocument, voice: Voice
) -> MensuralClef | MensuralClefGroup:
    """Clefs diplomatiques initiales supportées par J7.2."""
    groups = _clef_groups_for_voice(document, voice.identity)
    if len(groups) > 1:
        raise SemanticTransformError(
            f"multiple clefGrp directives for voice {voice.identity!r}"
        )
    if len(groups) == 1:
        group = groups[0]
        first = first_voice_event_address(document, voice.identity)
        if (
            group.anchor.voice_identity != first.voice_identity
            or group.anchor.measure_n != first.measure_n
            or group.anchor.ordinal != first.ordinal
        ):
            raise SemanticTransformError(
                f"clefGrp for voice {voice.identity!r} must be anchored "
                f"at the first musical event; got measure={group.anchor.measure_n} "
                f"ordinal={group.anchor.ordinal}"
            )
        if group.clefs != SUPPORTED_CLEF_GROUP:
            raise SemanticTransformError(
                f"unsupported diplomatic clef group for voice {voice.identity!r}: "
                f"{group.clefs!r}"
            )
        return MensuralClefGroup(
            members=tuple(
                MensuralClef(shape=clef.shape, line=clef.line) for clef in group.clefs
            ),
            source_text=group.source_text,
            source_xml_id=group.source_xml_id,
        )

    source = voice.initial_clef
    if source is None:
        raise SemanticTransformError(
            f"voice {voice.identity!r} has no initial diplomatic clef"
        )
    if source.shape == "C" and source.line in {1, 2}:
        return MensuralClef(shape=source.shape, line=source.line)
    raise SemanticTransformError(
        f"unsupported initial source clef {source.shape}{source.line} "
        f"for voice {voice.identity!r}"
    )


def modern_clef_for_voice(document: InputDocument, voice: Voice) -> CmnClef:
    """Clef moderne de lecture dérivée des clefs diplomatiques supportées."""
    diplomatic = diplomatic_clefs_for_voice(document, voice)
    members = opening_clef_members(diplomatic)
    if members == (MensuralClef(shape="C", line=1),) or members == (
        MensuralClef(shape="C", line=2),
    ):
        return CmnClef(shape="G", line=2)
    if members == (
        MensuralClef(shape="C", line=4),
        MensuralClef(shape="F", line=2),
    ):
        return CmnClef(shape="G", line=2, dis=8, dis_place="below")
    raise SemanticTransformError(
        f"unsupported diplomatic clefs for CMN mapping of voice "
        f"{voice.identity!r}: {diplomatic!r}"
    )
