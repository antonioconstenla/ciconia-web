"""Projection of explicit ``note:graphy=`` paleographic overrides."""

from __future__ import annotations

from dataclasses import replace

from mei_scribe.model.document import InputDocument, NoteGraphyDirective
from mei_scribe.transform.errors import SemanticTransformError
from mei_scribe.transform.model import MensuralDocument, MensuralNote, MensuralVoice

SUPPORTED_GRAPHY_CAUDATA = "caudata"
SMUFL_AUTH = "smufl"
GLYPH_CAUDATA = "mensuralBlackSemibrevisCaudata"


def is_supported_note_graphy(directive: NoteGraphyDirective) -> bool:
    """Return True when the graphy token is implemented."""
    return directive.graphy == SUPPORTED_GRAPHY_CAUDATA


def apply_note_graphy_directives(
    document: InputDocument, mensural: MensuralDocument
) -> tuple[MensuralDocument, frozenset[NoteGraphyDirective]]:
    """Project every supported ``note:graphy=caudata`` onto exactly one note.

    Resolution uses provenance membership:

        directive.anchor ∈ note.provenance.source_addresses

    Unsupported graphy tokens are recognized but not projected; the caller
    retains ``deferred-note-graphy``. Identical supported directives targeting
    the same surviving note are deduplicated. Conflicting glyphs, unresolved
    anchors, ambiguous matches, and non-note targets are blocking semantic
    errors (no silent loss).
    """
    directives = [
        directive
        for directive in document.directives
        if isinstance(directive, NoteGraphyDirective)
    ]
    supported = [d for d in directives if is_supported_note_graphy(d)]
    if not supported:
        return mensural, frozenset()

    by_note: dict[tuple[str, int], list[NoteGraphyDirective]] = {}
    for directive in supported:
        matches: list[tuple[MensuralVoice, object]] = []
        for voice in mensural.voices:
            for event in voice.events:
                if directive.anchor in event.provenance.source_addresses:
                    matches.append((voice, event))

        if not matches:
            raise SemanticTransformError(
                "note-graphy directive target unresolved: "
                f"voice={directive.anchor.voice_identity!r} "
                f"measure={directive.anchor.measure_n} "
                f"ordinal={directive.anchor.ordinal} "
                f"text={directive.source_text!r}"
            )
        if len(matches) > 1:
            raise SemanticTransformError(
                "note-graphy directive target ambiguous: "
                f"voice={directive.anchor.voice_identity!r} "
                f"measure={directive.anchor.measure_n} "
                f"ordinal={directive.anchor.ordinal} "
                f"matches={len(matches)}"
            )

        voice, event = matches[0]
        if not isinstance(event, MensuralNote):
            raise SemanticTransformError(
                "note-graphy directive must resolve to a note; "
                f"got {type(event).__name__} for "
                f"voice={directive.anchor.voice_identity!r} "
                f"measure={directive.anchor.measure_n} "
                f"ordinal={directive.anchor.ordinal}"
            )

        key = (voice.identity, event.ordinal)
        by_note.setdefault(key, []).append(directive)

    glyph_by_note: dict[tuple[str, int], str] = {}
    consumed: list[NoteGraphyDirective] = []
    for key, group in by_note.items():
        variants = {directive.graphy for directive in group}
        if len(variants) > 1:
            raise SemanticTransformError(
                "conflicting note-graphy directives resolve to the same "
                f"output note: voice={key[0]!r} ordinal={key[1]} "
                f"variants={sorted(variants)!r}"
            )
        glyph_by_note[key] = GLYPH_CAUDATA
        consumed.extend(group)

    new_voices: list[MensuralVoice] = []
    for voice in mensural.voices:
        new_events = []
        for event in voice.events:
            if isinstance(event, MensuralNote):
                key = (voice.identity, event.ordinal)
                if key in glyph_by_note:
                    glyph_name = glyph_by_note[key]
                    if (
                        event.glyph_name is not None
                        and event.glyph_name != glyph_name
                    ):
                        raise SemanticTransformError(
                            "conflicting paleographic glyphs on the same "
                            f"output note: voice={key[0]!r} ordinal={key[1]} "
                            f"existing={event.glyph_name!r} "
                            f"incoming={glyph_name!r}"
                        )
                    event = replace(
                        event,
                        glyph_auth=SMUFL_AUTH,
                        glyph_name=glyph_name,
                    )
            new_events.append(event)
        new_voices.append(replace(voice, events=tuple(new_events)))

    return replace(mensural, voices=tuple(new_voices)), frozenset(consumed)
