"""Phase 6B: résolution de hauteur custos et intégrité d'ancrage.

La représentabilité d'ancre est généralisée en Phase 6C1
(``source_systems.resolve_boundary_anchor_target``) et réutilisée ici.
"""

from __future__ import annotations

from mei_scribe.model.document import (
    InputDocument,
    InputEventAddress,
    InputInlineClef,
    InputMeasureRest,
    InputNote,
    InputRest,
)
from mei_scribe.transform.errors import SemanticTransformError
from mei_scribe.transform.model import MensuralDocument, SourceSystemBoundary
from mei_scribe.transform.source_systems import (
    CUSTOS_KIND,
    validate_source_system_boundary_representable,
)


def _iter_voice_events(
    document: InputDocument, voice_identity: str
) -> list[tuple[InputEventAddress | None, object]]:
    items: list[tuple[InputEventAddress | None, object]] = []
    for measure in document.measures:
        for content in measure.voices:
            if content.voice_identity != voice_identity:
                continue
            for event in content.events:
                if isinstance(event, InputInlineClef):
                    items.append((None, event))
                    continue
                kind = (
                    "note"
                    if isinstance(event, InputNote)
                    else "rest"
                    if isinstance(event, InputRest)
                    else "mRest"
                )
                address = InputEventAddress(
                    voice_identity=voice_identity,
                    measure_n=content.measure_n,
                    ordinal=event.ordinal,
                    event_kind=kind,
                )
                items.append((address, event))
    return items


def resolve_custos_boundaries(
    input_document: InputDocument,
    mensural_document: MensuralDocument,
) -> MensuralDocument:
    """Valide toutes les ruptures et peuple ``custos_pitch`` pour les custos."""
    updated: list[SourceSystemBoundary] = []
    for boundary in mensural_document.source_system_boundaries:
        # Phase 6C1: every SourceSystemBoundary must be representable.
        code_prefix = (
            "custos" if CUSTOS_KIND in boundary.kinds else "source-system-boundary"
        )
        validate_source_system_boundary_representable(
            boundary, mensural_document, code_prefix=code_prefix
        )
        if CUSTOS_KIND not in boundary.kinds:
            updated.append(boundary)
            continue
        pitch = _resolve_custos_pitch(input_document, boundary.anchor)
        updated.append(
            SourceSystemBoundary(
                anchor=boundary.anchor,
                kinds=boundary.kinds,
                source_markers=boundary.source_markers,
                document_order=boundary.document_order,
                custos_pitch=pitch,
            )
        )
    return MensuralDocument(
        metadata=mensural_document.metadata,
        voices=mensural_document.voices,
        anchored_texts=mensural_document.anchored_texts,
        source_system_boundaries=tuple(updated),
    )


def _resolve_custos_pitch(
    document: InputDocument,
    anchor: InputEventAddress,
) -> tuple[str, int]:
    stream = _iter_voice_events(document, anchor.voice_identity)
    for index, (address, event) in enumerate(stream):
        if address is None:
            continue
        if address != anchor:
            continue
        if isinstance(event, InputNote):
            return (event.pname, event.oct)
        if isinstance(event, (InputRest, InputMeasureRest)):
            for later_address, later_event in stream[index + 1 :]:
                if later_address is None or isinstance(later_event, InputInlineClef):
                    continue
                if isinstance(later_event, InputNote):
                    return (later_event.pname, later_event.oct)
            raise SemanticTransformError(
                "custos-pitch-unresolved: "
                f"voice={anchor.voice_identity!r} "
                f"measure={anchor.measure_n} ordinal={anchor.ordinal}"
            )
        raise SemanticTransformError(
            "custos-pitch-unresolved: "
            f"voice={anchor.voice_identity!r} "
            f"measure={anchor.measure_n} ordinal={anchor.ordinal}"
        )
    raise SemanticTransformError(
        "custos-pitch-unresolved: "
        f"voice={anchor.voice_identity!r} "
        f"measure={anchor.measure_n} ordinal={anchor.ordinal}"
    )
