"""Normalisation et représentabilité des ruptures de système source.

Phase 6A : normalisation ``custos`` / ``system:start`` → ``SourceSystemBoundary``.
Phase 6C1 : validation de représentabilité pour TOUTES les ruptures.
"""

from __future__ import annotations

from dataclasses import dataclass

from mei_scribe.model.document import (
    CustosDirective,
    InputDocument,
    InputEventAddress,
    SystemStartDirective,
)
from mei_scribe.transform.errors import SemanticTransformError
from mei_scribe.transform.model import (
    MensuralDocument,
    MensuralLigature,
    MensuralNote,
    MensuralRest,
    MensuralVoice,
    SourceSystemBoundary,
    SourceSystemMarker,
)

CUSTOS_KIND = "custos"
SYSTEM_START_KIND = "system:start"

_RhythmicMensuralEvent = MensuralNote | MensuralRest


@dataclass
class _BoundaryAccumulator:
    anchor: InputEventAddress
    kinds: set[str]
    markers: list[SourceSystemMarker]


@dataclass(frozen=True)
class BoundaryAnchorTarget:
    """Cible mensurale résolue pour une ``SourceSystemBoundary``."""

    voice: MensuralVoice
    event: _RhythmicMensuralEvent
    event_index: int


def normalize_source_system_boundaries(
    document: InputDocument,
) -> tuple[SourceSystemBoundary, ...]:
    """Normalise les directives source en ruptures de système immuables.

    - L'ordre suit l'ordre documentaire des directives (pas les xml:id).
    - Même ancre + kinds différents → une rupture union.
    - Même ancre + kind dupliqué → erreur bloquante.
    """
    groups: dict[tuple[str, int, int], _BoundaryAccumulator] = {}
    order_counter = 0

    for directive in document.directives:
        if isinstance(directive, CustosDirective):
            kind = CUSTOS_KIND
        elif isinstance(directive, SystemStartDirective):
            kind = SYSTEM_START_KIND
        else:
            continue

        anchor = directive.anchor
        key = (anchor.voice_identity, anchor.measure_n, anchor.ordinal)
        marker = SourceSystemMarker(
            kind=kind,
            source_text=directive.source_text,
            source_xml_id=directive.source_xml_id,
            document_order=order_counter,
        )
        order_counter += 1

        if key not in groups:
            groups[key] = _BoundaryAccumulator(
                anchor=anchor,
                kinds={kind},
                markers=[marker],
            )
            continue

        acc = groups[key]
        if kind in acc.kinds:
            code = (
                "duplicate-custos-boundary"
                if kind == CUSTOS_KIND
                else "duplicate-system-start-boundary"
            )
            raise SemanticTransformError(
                f"{code}: duplicate {kind!r} at "
                f"voice={anchor.voice_identity!r} "
                f"measure={anchor.measure_n} ordinal={anchor.ordinal}"
            )
        acc.kinds.add(kind)
        acc.markers.append(marker)

    boundaries: list[SourceSystemBoundary] = []
    for acc in groups.values():
        markers = tuple(sorted(acc.markers, key=lambda m: m.document_order))
        boundaries.append(
            SourceSystemBoundary(
                anchor=acc.anchor,
                kinds=frozenset(acc.kinds),
                source_markers=markers,
                document_order=markers[0].document_order,
                custos_pitch=None,
            )
        )

    boundaries.sort(key=lambda b: b.document_order)
    return tuple(boundaries)


def resolve_boundary_anchor_target(
    boundary: SourceSystemBoundary,
    document: MensuralDocument,
    *,
    code_prefix: str = "source-system-boundary",
) -> BoundaryAnchorTarget:
    """Résout l'événement mensural rythmique représentant l'ancre.

    - Zéro match → ``{prefix}-anchor-unresolved``
    - Match unique : ancre doit être ``provenance[0]`` sinon fused
    - Multi-match : uniquement projection mRest segmentée sûre → premier match
    - Multi-match non sûr → ``{prefix}-anchor-ambiguous``
    """
    anchor = boundary.anchor
    voice = next(
        (item for item in document.voices if item.identity == anchor.voice_identity),
        None,
    )
    if voice is None:
        raise SemanticTransformError(
            f"{code_prefix}-anchor-unresolved: "
            f"voice={anchor.voice_identity!r} "
            f"measure={anchor.measure_n} ordinal={anchor.ordinal}"
        )

    matches: list[tuple[int, _RhythmicMensuralEvent]] = []
    for index, event in enumerate(voice.events):
        if not isinstance(event, (MensuralNote, MensuralRest)):
            continue
        if anchor in event.provenance.source_addresses:
            matches.append((index, event))

    if not matches:
        raise SemanticTransformError(
            f"{code_prefix}-anchor-unresolved: "
            f"voice={anchor.voice_identity!r} "
            f"measure={anchor.measure_n} ordinal={anchor.ordinal}"
        )

    if len(matches) == 1:
        index, event = matches[0]
        provenance = event.provenance.source_addresses
        if not provenance or provenance[0] != anchor:
            raise SemanticTransformError(
                f"{code_prefix}-anchor-inside-fused-event: "
                f"voice={anchor.voice_identity!r} "
                f"measure={anchor.measure_n} ordinal={anchor.ordinal}"
            )
        return BoundaryAnchorTarget(voice=voice, event=event, event_index=index)

    first_index, first_event = matches[0]
    provenance = first_event.provenance.source_addresses
    if not provenance or provenance[0] != anchor:
        if provenance and anchor in provenance:
            raise SemanticTransformError(
                f"{code_prefix}-anchor-inside-fused-event: "
                f"voice={anchor.voice_identity!r} "
                f"measure={anchor.measure_n} ordinal={anchor.ordinal}"
            )
        raise SemanticTransformError(
            f"{code_prefix}-anchor-ambiguous: "
            f"voice={anchor.voice_identity!r} "
            f"measure={anchor.measure_n} ordinal={anchor.ordinal} "
            f"matches={len(matches)}"
        )
    match_events = [event for _, event in matches]
    if not _is_safe_segmented_rest_matches(anchor, match_events):
        raise SemanticTransformError(
            f"{code_prefix}-anchor-ambiguous: "
            f"voice={anchor.voice_identity!r} "
            f"measure={anchor.measure_n} ordinal={anchor.ordinal} "
            f"matches={len(matches)}"
        )
    return BoundaryAnchorTarget(
        voice=voice, event=first_event, event_index=first_index
    )


def validate_source_system_boundary_representable(
    boundary: SourceSystemBoundary,
    document: MensuralDocument,
    *,
    code_prefix: str = "source-system-boundary",
) -> BoundaryAnchorTarget:
    """Valide la représentabilité d'une rupture pour toutes les kinds."""
    target = resolve_boundary_anchor_target(
        boundary, document, code_prefix=code_prefix
    )
    _validate_boundary_not_inside_ligature(
        boundary, target, code_prefix=code_prefix
    )
    return target


def _validate_boundary_not_inside_ligature(
    boundary: SourceSystemBoundary,
    target: BoundaryAnchorTarget,
    *,
    code_prefix: str,
) -> None:
    """Block boundaries anchored to non-first ligature members."""
    event = target.event
    if not isinstance(event, MensuralNote):
        return

    containing: list[MensuralLigature] = []
    for ligature in target.voice.ligatures:
        if event.ordinal in ligature.member_ordinals:
            containing.append(ligature)

    if not containing:
        return

    anchor = boundary.anchor
    if len(containing) > 1:
        raise SemanticTransformError(
            f"{code_prefix}-anchor-ambiguous: "
            f"voice={anchor.voice_identity!r} "
            f"measure={anchor.measure_n} ordinal={anchor.ordinal} "
            f"ligatures={len(containing)}"
        )

    ligature = containing[0]
    if event.ordinal == ligature.member_ordinals[0]:
        return

    first_member_ordinal = ligature.member_ordinals[0]
    member_position = ligature.member_ordinals.index(event.ordinal) + 1
    raise SemanticTransformError(
        f"{code_prefix}-anchor-inside-ligature: "
        f"voice={anchor.voice_identity!r} "
        f"measure={anchor.measure_n} ordinal={anchor.ordinal} "
        f"ligature_first_member_ordinal={first_member_ordinal} "
        f"ligature_member_position={member_position}"
    )


def _is_safe_segmented_rest_matches(
    anchor: InputEventAddress,
    matches: list[_RhythmicMensuralEvent],
) -> bool:
    """True when multiple ``MensuralRest`` segments share one source-rest projection."""
    if not all(isinstance(event, MensuralRest) for event in matches):
        return False
    provenance = matches[0].provenance.source_addresses
    if not provenance or provenance[0] != anchor:
        return False
    return all(
        event.provenance.source_addresses == provenance for event in matches[1:]
    )


def section_start_index_for_boundary(
    boundary: SourceSystemBoundary,
    document: MensuralDocument,
    *,
    code_prefix: str = "source-system-boundary",
) -> int:
    """Index in ``voice.events`` where the new section begins.

    Starts at the rhythmic anchor event, then walks backward through immediately
    consecutive ``MensuralInlineClef`` events. Business anchor is unchanged.
    """
    from mei_scribe.transform.model import MensuralInlineClef

    target = validate_source_system_boundary_representable(
        boundary, document, code_prefix=code_prefix
    )
    start = target.event_index
    while start > 0 and isinstance(
        target.voice.events[start - 1], MensuralInlineClef
    ):
        start -= 1
    return start
