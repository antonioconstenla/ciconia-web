"""Transformations sémantiques J7.2 : CMN et mensural siblings."""

from __future__ import annotations

from mei_scribe.model.document import (
    ClefGroupDirective,
    InputDocument,
    InputNote,
    NoteGraphyDirective,
    NoteStemDirective,
    RestDurationDirective,
)
from mei_scribe.transform.cmn import transform_to_cmn
from mei_scribe.transform.errors import SemanticTransformError
from mei_scribe.transform.mensural import transform_to_mensural
from mei_scribe.transform.model import (
    OutputDiagnostic,
    TransformationBundle,
)
from mei_scribe.transform.note_graphy import is_supported_note_graphy
from mei_scribe.transform.note_stem import is_complete_note_stem

__all__ = [
    "SemanticTransformError",
    "TransformationBundle",
    "transform_document",
    "transform_to_cmn",
    "transform_to_mensural",
]


def transform_document(document: InputDocument) -> TransformationBundle:
    """Transforme un ``InputDocument`` en couple sibling CMN + mensural.

    Les deux transformations partent du même document d'entrée. La mensurale
    ne consomme jamais le résultat CMN. Aucun XML n'est reparsé.
    """
    _reject_blocking_input_diagnostics(document)
    cmn = transform_to_cmn(document)
    mensural = transform_to_mensural(document)
    # Complete NoteStemDirectives and supported note:graphy=caudata are
    # projected inside transform_to_mensural; failure raises before
    # diagnostics. Partial stems and unsupported graphy remain recognized
    # but unprojected.
    consumed_stems = frozenset(
        directive
        for directive in document.directives
        if isinstance(directive, NoteStemDirective)
        and is_complete_note_stem(directive)
    )
    consumed_graphy = frozenset(
        directive
        for directive in document.directives
        if isinstance(directive, NoteGraphyDirective)
        and is_supported_note_graphy(directive)
    )
    diagnostics = _deferred_diagnostics(
        document, consumed_stems, consumed_graphy
    )
    return TransformationBundle(
        cmn=cmn,
        mensural=mensural,
        diagnostics=diagnostics,
    )


def _reject_blocking_input_diagnostics(document: InputDocument) -> None:
    blocking = [
        diagnostic
        for diagnostic in document.diagnostics
        if diagnostic.code
        in {"unknown-structured-directive", "unstructured-staff-text"}
    ]
    if blocking:
        sample = blocking[0]
        raise SemanticTransformError(
            f"unhandled input diagnostic {sample.code!r}: "
            f"{sample.source_text!r}"
        )


def _deferred_diagnostics(
    document: InputDocument,
    consumed_note_stems: frozenset[NoteStemDirective] = frozenset(),
    consumed_note_graphy: frozenset[NoteGraphyDirective] = frozenset(),
) -> tuple[OutputDiagnostic, ...]:
    diagnostics: list[OutputDiagnostic] = []

    for directive in document.directives:
        if isinstance(directive, RestDurationDirective):
            continue
        if isinstance(directive, ClefGroupDirective):
            continue
        if isinstance(directive, NoteStemDirective):
            if directive in consumed_note_stems:
                continue
            diagnostics.append(
                OutputDiagnostic(
                    severity="WARNING",
                    code="deferred-note-stem",
                    feature="note-stem",
                    message=(
                        "note stem graphy deferred: incomplete directive "
                        "(requires stem.dir + stem.pos + stem.form)"
                        if not is_complete_note_stem(directive)
                        else "note stem graphy deferred to a later milestone"
                    ),
                    voice_identity=directive.anchor.voice_identity,
                    measure_n=directive.anchor.measure_n,
                    ordinal=directive.anchor.ordinal,
                    source_text=directive.source_text,
                    source_xml_id=directive.source_xml_id,
                )
            )
        elif isinstance(directive, NoteGraphyDirective):
            if directive in consumed_note_graphy:
                continue
            diagnostics.append(
                OutputDiagnostic(
                    severity="WARNING",
                    code="deferred-note-graphy",
                    feature="note-graphy",
                    message=(
                        "note graphy deferred: unsupported value "
                        f"{directive.graphy!r}"
                    ),
                    voice_identity=directive.anchor.voice_identity,
                    measure_n=directive.anchor.measure_n,
                    ordinal=directive.anchor.ordinal,
                    source_text=directive.source_text,
                    source_xml_id=directive.source_xml_id,
                )
            )
    diagnostics.extend(_gestural_only_accidentals(document))
    return tuple(diagnostics)


def _gestural_only_accidentals(
    document: InputDocument,
) -> tuple[OutputDiagnostic, ...]:
    diagnostics: list[OutputDiagnostic] = []
    for measure in document.measures:
        for voice in measure.voices:
            for event in voice.events:
                if not isinstance(event, InputNote):
                    continue
                if event.written_accidental is not None:
                    continue
                gestural = event.gestural_accidental
                if gestural is None:
                    continue
                diagnostics.append(
                    OutputDiagnostic(
                        severity="WARNING",
                        code="accid-ges-only",
                        feature="accidental",
                        message=(
                            "gestural accidental (accid.ges) with no written "
                            "@accid; not emitted as a written accidental"
                        ),
                        voice_identity=voice.voice_identity,
                        measure_n=measure.n,
                        ordinal=event.ordinal,
                        source_xml_id=gestural.source_xml_id or event.source_xml_id,
                    )
                )
    return tuple(diagnostics)
