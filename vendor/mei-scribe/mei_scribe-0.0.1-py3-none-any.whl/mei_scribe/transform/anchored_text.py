"""Projection du texte ancré J8.1 vers le modèle de sortie."""

from __future__ import annotations

from mei_scribe.model.document import AnchoredTextDirective, InputDocument
from mei_scribe.transform.model import OutputAnchoredText


def project_anchored_text(document: InputDocument) -> tuple[OutputAnchoredText, ...]:
    """Projette toutes les ``AnchoredTextDirective`` dans l'ordre source."""
    return tuple(
        OutputAnchoredText(
            func=directive.func,
            text=directive.text,
            anchor=directive.anchor,
        )
        for directive in document.directives
        if isinstance(directive, AnchoredTextDirective)
    )
