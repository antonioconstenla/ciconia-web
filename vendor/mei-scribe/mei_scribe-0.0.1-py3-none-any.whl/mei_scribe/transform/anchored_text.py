"""Projection du texte ancré J8.1 / ANCHORED_TEXT_EDITORIAL_V1."""

from __future__ import annotations

from collections import defaultdict

from mei_scribe.model.document import (
    AnchoredTextChoice,
    AnchoredTextDirective,
    AnchoredTextUnclear,
    InputDocument,
    InputEventAddress,
)
from mei_scribe.signals.anchored_text import (
    EDITORIAL_ALTERNATIVE,
    iter_source_tokens,
    order_anchored_text_directives,
)
from mei_scribe.transform.model import OutputAnchoredText, OutputDiagnostic


def project_anchored_text(document: InputDocument) -> tuple[OutputAnchoredText, ...]:
    """Projette les ``AnchoredTextDirective`` avec ordre logique lyricBlock.

    Compatible ``editorial=alternative`` members on one anchor merge into a
    single ``OutputAnchoredText`` carrying ``AnchoredTextChoice``. Reading
    child order is lexicographic for deterministic serialization only.
    """
    directives = tuple(
        directive
        for directive in document.directives
        if isinstance(directive, AnchoredTextDirective)
    )
    ordered = order_anchored_text_directives(directives)
    alternative_groups: dict[InputEventAddress, list[AnchoredTextDirective]] = (
        defaultdict(list)
    )
    for directive in ordered:
        if directive.editorial == EDITORIAL_ALTERNATIVE:
            alternative_groups[directive.anchor].append(directive)

    emitted_alternatives: set[InputEventAddress] = set()
    projected: list[OutputAnchoredText] = []
    for directive in ordered:
        if directive.editorial == EDITORIAL_ALTERNATIVE:
            if directive.anchor in emitted_alternatives:
                continue
            emitted_alternatives.add(directive.anchor)
            projected.append(
                _project_alternative_set(alternative_groups[directive.anchor])
            )
            continue
        projected.append(
            OutputAnchoredText(
                func=directive.func,
                text=directive.text,
                anchor=directive.anchor,
                n=directive.n,
                parts=directive.parts,
                verse_n=directive.verse_n,
            )
        )
    return tuple(projected)


def _project_alternative_set(
    members: list[AnchoredTextDirective],
) -> OutputAnchoredText:
    sample = members[0]
    # Serialization order only: lexicographic by reading text. Source StaffText
    # order is preserved separately on AnchoredTextChoice member provenance.
    sorted_members = sorted(members, key=lambda member: member.text)
    readings = tuple(
        AnchoredTextUnclear(text=member.text, evidence=member.evidence)
        for member in sorted_members
    )
    return OutputAnchoredText(
        func=sample.func,
        text="",
        anchor=sample.anchor,
        parts=(
            AnchoredTextChoice(
                readings=readings,
                member_source_xml_ids=tuple(
                    member.source_xml_id for member in members
                ),
                member_source_texts=tuple(
                    member.source_text for member in members
                ),
            ),
        ),
        verse_n=sample.verse_n,
    )


def source_diagnostics_from_anchored_text(
    document: InputDocument,
) -> tuple[OutputDiagnostic, ...]:
    """Reuse EDITORIAL_UNCERTAINTY_V1 source-token diagnostics."""
    diagnostics: list[OutputDiagnostic] = []
    for directive in document.directives:
        if not isinstance(directive, AnchoredTextDirective):
            continue
        for token, _part in iter_source_tokens(directive):
            diagnostics.append(
                OutputDiagnostic(
                    severity="WARNING",
                    code="editorial-source-reference-deferred",
                    feature="editorial-source",
                    message=(
                        f"source token {token!r} retained but not "
                        "serialized as MEI @source"
                    ),
                    voice_identity=directive.anchor.voice_identity,
                    measure_n=directive.anchor.measure_n,
                    ordinal=directive.anchor.ordinal,
                    source_text=directive.source_text,
                    source_xml_id=directive.source_xml_id,
                )
            )
    return tuple(diagnostics)
