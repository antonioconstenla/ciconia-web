"""Projection des métadonnées d'entrée vers les modèles de sortie J7.2."""

from __future__ import annotations

from mei_scribe.model.document import InputDocument, InputDocumentMetadata
from mei_scribe.transform.errors import SemanticTransformError
from mei_scribe.transform.model import OutputDocumentMetadata, OutputParatext


def project_output_metadata(document: InputDocument) -> OutputDocumentMetadata:
    """Projette les métadonnées nécessaires à la sérialisation J7.3.

    Ne conserve pas ``availability_lines`` : les champs structurés et les
    paratextes suffisent. Aucun XML n'est reparsé.
    """
    meta = document.metadata
    if meta is None:
        raise SemanticTransformError("missing document metadata for transform")
    return _from_input_metadata(meta)


def _from_input_metadata(meta: InputDocumentMetadata) -> OutputDocumentMetadata:
    mensuration = meta.mensuration
    return OutputDocumentMetadata(
        title=meta.title,
        composer=meta.composer,
        source_siglum=meta.source_siglum,
        source_repo=meta.source_repo,
        source_idno=meta.source_idno,
        transcriber=meta.transcriber,
        license=meta.license,
        notation_type=meta.notation_type,
        modusminor=None if mensuration is None else mensuration.modusminor,
        tempus=None if mensuration is None else mensuration.tempus,
        prolatio=None if mensuration is None else mensuration.prolatio,
        modusmaior=None if mensuration is None else mensuration.modusmaior,
        mensur_in_source=meta.mensur_in_source,
        paratexts=tuple(
            OutputParatext(
                surface=paratext.surface,
                type=paratext.type,
                position=paratext.position,
                text=paratext.text,
            )
            for paratext in meta.paratexts
        ),
    )
