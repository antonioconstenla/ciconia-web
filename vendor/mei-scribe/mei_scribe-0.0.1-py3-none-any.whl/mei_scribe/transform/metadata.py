"""Projection des métadonnées d'entrée vers les modèles de sortie J7.2."""

from __future__ import annotations

from mei_scribe.model.document import InputDocument, InputDocumentMetadata
from mei_scribe.transform.errors import SemanticTransformError
from mei_scribe.transform.model import OutputDocumentMetadata, OutputParatext
from mei_scribe.transform.projection import ProjectionMode, classify_projection_mode


def project_output_metadata(document: InputDocument) -> OutputDocumentMetadata:
    """Projette les métadonnées nécessaires à la sérialisation J7.3.

    Ne conserve pas ``availability_lines`` : les champs structurés et les
    paratextes suffisent. Aucun XML n'est reparsé.
    """
    meta = document.metadata
    if meta is None:
        raise SemanticTransformError("missing document metadata for transform")
    mode = classify_projection_mode(document)
    return _from_input_metadata(meta, mode)


def _from_input_metadata(
    meta: InputDocumentMetadata, mode: ProjectionMode
) -> OutputDocumentMetadata:
    mensuration = meta.mensuration
    if mode is ProjectionMode.DIPLOMATIC_UNKNOWN:
        modusminor = None
        tempus = None
        prolatio = None
        modusmaior = None
    elif mode is ProjectionMode.DIPLOMATIC_KNOWN_222:
        assert mensuration is not None
        modusminor = mensuration.modusminor
        tempus = mensuration.tempus
        prolatio = mensuration.prolatio
        modusmaior = None
    else:
        modusminor = None if mensuration is None else mensuration.modusminor
        tempus = None if mensuration is None else mensuration.tempus
        prolatio = None if mensuration is None else mensuration.prolatio
        modusmaior = None if mensuration is None else mensuration.modusmaior
    return OutputDocumentMetadata(
        title=meta.title,
        composer=meta.composer,
        source_siglum=meta.source_siglum,
        source_repo=meta.source_repo,
        source_idno=meta.source_idno,
        transcriber=meta.transcriber,
        license=meta.license,
        notation_type=meta.notation_type,
        modusminor=modusminor,
        tempus=tempus,
        prolatio=prolatio,
        modusmaior=modusmaior,
        mensur_in_source=meta.mensur_in_source,
        paratexts=tuple(
            OutputParatext(
                surface=paratext.surface,
                type=paratext.type,
                position=paratext.position,
                text=paratext.text,
            )
            for paratext in meta.paratexts
        ),
        projection_mode=mode.value,
    )
