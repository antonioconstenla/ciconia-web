"""Modèles sémantiques de sortie J7.2 (CMN et mensural), indépendants de l'XML."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Union

from mei_scribe.model.document import InputEventAddress, InputLyricSyllable


@dataclass(frozen=True)
class SourceSystemMarker:
    """Provenance immuable d'un marqueur source contribuant à une rupture."""

    kind: str
    source_text: str
    source_xml_id: str
    document_order: int


@dataclass(frozen=True)
class SourceSystemBoundary:
    """Rupture de système source normalisée, ancrée à une adresse métier."""

    anchor: InputEventAddress
    kinds: frozenset[str]
    source_markers: tuple[SourceSystemMarker, ...]
    document_order: int
    custos_pitch: tuple[str, int] | None = None


@dataclass(frozen=True)
class EventProvenance:
    """Provenance structurée vers une ou plusieurs adresses source."""

    source_addresses: tuple[InputEventAddress, ...]
    source_xml_ids: tuple[str, ...] = ()


@dataclass(frozen=True)
class OutputWrittenAccidental:
    """Accident écrit projeté dans un modèle de sortie."""

    accid: str
    source_xml_id: str | None = None
    enclose: str | None = None


@dataclass(frozen=True)
class OutputParatext:
    """Paratexte structuré de sortie (sans reparcourir availability_lines)."""

    surface: str
    type: str
    position: str
    text: str

    def other_char_type(self) -> str:
        """Type ``otherChar`` déterministe pour la sérialisation J8.1."""
        return f"paratext-{self.type}-{self.surface}-{self.position}"


@dataclass(frozen=True)
class OutputAnchoredText:
    """Texte ancré projeté pour émission MEI (J8.1)."""

    func: str
    text: str
    anchor: InputEventAddress


@dataclass(frozen=True)
class OutputDocumentMetadata:
    """Métadonnées communes aux siblings CMN et mensural pour J7.3."""

    title: str | None
    composer: str | None
    source_siglum: str | None
    source_repo: str | None
    source_idno: str | None
    transcriber: str | None
    license: str | None
    notation_type: str | None
    modusminor: int | None
    tempus: int | None
    prolatio: int | None
    mensur_in_source: bool | None
    paratexts: tuple[OutputParatext, ...]
    modusmaior: int | None = None


@dataclass(frozen=True)
class CmnClef:
    """Clef moderne de lecture CMN."""

    shape: str
    line: int
    dis: int | None = None
    dis_place: str | None = None


@dataclass(frozen=True)
class MensuralClef:
    """Clef diplomatique mensurale (shape + line)."""

    shape: str
    line: int


@dataclass(frozen=True)
class MensuralClefGroup:
    """Groupe de clefs diplomatiques simultanées (identité ``clefGrp``)."""

    members: tuple[MensuralClef, ...]
    source_text: str = ""
    source_xml_id: str = ""

    def __post_init__(self) -> None:
        if len(self.members) < 2:
            raise ValueError("MensuralClefGroup requires at least two members")


def opening_clef_members(
    clefs: MensuralClef | MensuralClefGroup,
) -> tuple[MensuralClef, ...]:
    """Ordered opening diplomatic clefs; preserves group member order."""
    if isinstance(clefs, MensuralClefGroup):
        return clefs.members
    if isinstance(clefs, MensuralClef):
        return (clefs,)
    raise TypeError(f"unsupported opening clefs type {type(clefs)!r}")


@dataclass(frozen=True)
class CmnNote:
    """Note CMN : valeurs source préservées, sans résolution rythmique."""

    ordinal: int
    pname: str
    oct: int
    dur: str
    dots: int
    lyrics: tuple[InputLyricSyllable, ...]
    written_accidental: OutputWrittenAccidental | None
    provenance: EventProvenance


@dataclass(frozen=True)
class CmnRest:
    """Silence CMN ordinaire."""

    ordinal: int
    dur: str
    dots: int
    provenance: EventProvenance


@dataclass(frozen=True)
class CmnMeasureRest:
    """Silence de mesure CMN."""

    ordinal: int
    provenance: EventProvenance


CmnEvent = Union[CmnNote, CmnRest, CmnMeasureRest]


@dataclass(frozen=True)
class CmnTuplet:
    """Tuplet CMN non résolu."""

    num: int
    numbase: int
    measure_n: int
    voice_identity: str
    member_ordinals: tuple[int, ...]
    provenance: EventProvenance


@dataclass(frozen=True)
class CmnTie:
    """Tie CMN technique non résolue (peut traverser des mesures)."""

    start_measure_n: int
    start_ordinal: int
    end_measure_n: int
    end_ordinal: int
    voice_identity: str
    provenance: EventProvenance


@dataclass(frozen=True)
class CmnLigature:
    """Ligature source projetée en bornes CMN explicites (bracket).

    Les membres suivent les adresses source explicites de ``ResolvedLigature``.
    Une note créée uniquement comme continuation de tie technique n'est pas
    un endpoint : le bracket s'arrête sur la dernière tête explicitement
    membre de la ligature source.
    """

    voice_identity: str
    start_measure_n: int
    start_ordinal: int
    end_measure_n: int
    end_ordinal: int
    member_addresses: tuple[InputEventAddress, ...]
    source_text: str
    provenance: EventProvenance


@dataclass(frozen=True)
class CmnVoiceMeasure:
    """Contenu d'une voix dans une mesure CMN."""

    voice_identity: str
    events: tuple[CmnEvent, ...]


@dataclass(frozen=True)
class CmnMeasure:
    """Mesure CMN conservée."""

    n: int
    voices: tuple[CmnVoiceMeasure, ...]


@dataclass(frozen=True)
class CmnVoice:
    """Voix du modèle CMN."""

    identity: str
    name: str
    rank: int
    clef: CmnClef


@dataclass(frozen=True)
class CmnDocument:
    """Document sémantique CMN polyphonique mesuré."""

    metadata: OutputDocumentMetadata
    voices: tuple[CmnVoice, ...]
    measures: tuple[CmnMeasure, ...]
    tuplets: tuple[CmnTuplet, ...]
    ties: tuple[CmnTie, ...]
    ligatures: tuple[CmnLigature, ...] = ()
    anchored_texts: tuple[OutputAnchoredText, ...] = ()
    # Métrique CMN source (nécessaire à la sérialisation scoreDef J7.3).
    meter_count: int | None = None
    meter_unit: int | None = None


@dataclass(frozen=True)
class MensuralNote:
    """Note mensurale résolue."""

    ordinal: int
    pname: str
    oct: int
    dur: str
    quality: str | None
    lyrics: tuple[InputLyricSyllable, ...]
    written_accidental: OutputWrittenAccidental | None
    provenance: EventProvenance
    # Normal vertical stem only (never used to encode a left cauda).
    stem_dir: str | None = None
    stem_pos: str | None = None
    stem_form: str | None = None
    # Visual graphy independent of logical duration (SMuFL via att.extSym).
    glyph_auth: str | None = None
    glyph_name: str | None = None


@dataclass(frozen=True)
class MensuralRest:
    """Silence mensural (ordinaire ou grand silence segmenté)."""

    ordinal: int
    unit: str
    count: int
    provenance: EventProvenance


@dataclass(frozen=True)
class MensuralInlineClef:
    """Changement de clef cadencé mensural (diplomatique, non modernisé)."""

    shape: str
    line: int
    provenance: EventProvenance


MensuralEvent = Union[MensuralNote, MensuralRest, MensuralInlineClef]


@dataclass(frozen=True)
class MensuralLigature:
    """Ligature projetée sur les ordinals mensuraux de sortie."""

    voice_identity: str
    member_ordinals: tuple[int, ...]
    effective_forms: tuple[str, ...]
    source_text: str
    provenance: EventProvenance


@dataclass(frozen=True)
class MensuralVoice:
    """Voix mensurale en flux continu."""

    identity: str
    name: str
    rank: int
    clefs: MensuralClef | MensuralClefGroup
    events: tuple[MensuralEvent, ...]
    ligatures: tuple[MensuralLigature, ...]


@dataclass(frozen=True)
class MensuralDocument:
    """Document sémantique mensural (voix successives, sans mesures)."""

    metadata: OutputDocumentMetadata
    voices: tuple[MensuralVoice, ...]
    anchored_texts: tuple[OutputAnchoredText, ...] = ()
    source_system_boundaries: tuple[SourceSystemBoundary, ...] = ()

    @property
    def notation_type(self) -> str | None:
        return self.metadata.notation_type

    @property
    def mensuration_modusminor(self) -> int | None:
        return self.metadata.modusminor

    @property
    def mensuration_tempus(self) -> int | None:
        return self.metadata.tempus

    @property
    def mensuration_prolatio(self) -> int | None:
        return self.metadata.prolatio

    @property
    def mensuration_modusmaior(self) -> int | None:
        return self.metadata.modusmaior

    @property
    def mensur_in_source(self) -> bool | None:
        return self.metadata.mensur_in_source


@dataclass(frozen=True)
class OutputDiagnostic:
    """Diagnostic déterministe de sortie (éléments différés)."""

    severity: str
    code: str
    feature: str
    message: str
    voice_identity: str | None = None
    measure_n: int | None = None
    ordinal: int | None = None
    source_text: str | None = None
    source_xml_id: str | None = None
    surface: str | None = None
    paratext_type: str | None = None
    position: str | None = None


@dataclass(frozen=True)
class TransformationBundle:
    """Résultat sibling : CMN + mensural + diagnostics."""

    cmn: CmnDocument
    mensural: MensuralDocument
    diagnostics: tuple[OutputDiagnostic, ...]
