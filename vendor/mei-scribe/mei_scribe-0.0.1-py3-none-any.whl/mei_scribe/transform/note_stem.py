"""Projection of explicit note-stem graphy onto mensural output notes."""

from __future__ import annotations

from dataclasses import replace

from mei_scribe.model.document import InputDocument, NoteStemDirective
from mei_scribe.transform.errors import SemanticTransformError
from mei_scribe.transform.model import MensuralDocument, MensuralNote, MensuralVoice


def is_complete_note_stem(directive: NoteStemDirective) -> bool:
    """Return True when all three paleographic stem fields are present."""
    return (
        directive.stem_dir is not None
        and directive.stem_pos is not None
        and directive.stem_form is not None
    )


def apply_note_stem_directives(
    document: InputDocument, mensural: MensuralDocument
) -> tuple[MensuralDocument, frozenset[NoteStemDirective]]:
    """Project every *complete* ``NoteStemDirective`` onto exactly one note.

    Resolution uses provenance membership:

        directive.anchor ∈ note.provenance.source_addresses

    Partial (incomplete) directives are recognized but not projected; the
    caller must retain ``deferred-note-stem`` for them. Identical complete
    directives targeting the same surviving note are deduplicated.
    Conflicting *complete* graphy on one note, unresolved anchors, ambiguous
    matches, and non-note targets are blocking semantic errors (no silent
    loss).

    Returns the updated mensural document and the frozenset of complete
    directives that were successfully consumed.
    """
    directives = [
        directive
        for directive in document.directives
        if isinstance(directive, NoteStemDirective)
    ]
    complete = [d for d in directives if is_complete_note_stem(d)]
    if not complete:
        return mensural, frozenset()

    by_note: dict[tuple[str, int], list[NoteStemDirective]] = {}
    for directive in complete:
        matches: list[tuple[MensuralVoice, object]] = []
        for voice in mensural.voices:
            for event in voice.events:
                if directive.anchor in event.provenance.source_addresses:
                    matches.append((voice, event))

        if not matches:
            raise SemanticTransformError(
                "note-stem directive target unresolved: "
                f"voice={directive.anchor.voice_identity!r} "
                f"measure={directive.anchor.measure_n} "
                f"ordinal={directive.anchor.ordinal} "
                f"text={directive.source_text!r}"
            )
        if len(matches) > 1:
            raise SemanticTransformError(
                "note-stem directive target ambiguous: "
                f"voice={directive.anchor.voice_identity!r} "
                f"measure={directive.anchor.measure_n} "
                f"ordinal={directive.anchor.ordinal} "
                f"matches={len(matches)}"
            )

        voice, event = matches[0]
        if not isinstance(event, MensuralNote):
            raise SemanticTransformError(
                "note-stem directive must resolve to a note; "
                f"got {type(event).__name__} for "
                f"voice={directive.anchor.voice_identity!r} "
                f"measure={directive.anchor.measure_n} "
                f"ordinal={directive.anchor.ordinal}"
            )

        key = (voice.identity, event.ordinal)
        by_note.setdefault(key, []).append(directive)

    graphy_by_note: dict[tuple[str, int], tuple[str, str, str]] = {}
    consumed: list[NoteStemDirective] = []
    for key, group in by_note.items():
        variants = {
            (directive.stem_dir, directive.stem_pos, directive.stem_form)
            for directive in group
        }
        # Completeness is already guaranteed; cast is for the type checker.
        assert all(
            d is not None and p is not None and f is not None for d, p, f in variants
        )
        if len(variants) > 1:
            raise SemanticTransformError(
                "conflicting note-stem directives resolve to the same output note: "
                f"voice={key[0]!r} ordinal={key[1]} variants={sorted(variants)!r}"
            )
        stem_dir, stem_pos, stem_form = next(iter(variants))
        assert stem_dir is not None and stem_pos is not None and stem_form is not None
        graphy_by_note[key] = (stem_dir, stem_pos, stem_form)
        consumed.extend(group)

    new_voices: list[MensuralVoice] = []
    for voice in mensural.voices:
        new_events = []
        for event in voice.events:
            if isinstance(event, MensuralNote):
                key = (voice.identity, event.ordinal)
                if key in graphy_by_note:
                    stem_dir, stem_pos, stem_form = graphy_by_note[key]
                    event = _project_complete_stem(
                        event, stem_dir, stem_pos, stem_form
                    )
            new_events.append(event)
        new_voices.append(replace(voice, events=tuple(new_events)))

    return replace(mensural, voices=tuple(new_voices)), frozenset(consumed)


SMUFL_AUTH = "smufl"
GLYPH_OBLIQUE = "mensuralBlackSemibrevisOblique"
_D9_STEMMED = frozenset({"minima", "semiminima"})


def _project_complete_stem(
    note: MensuralNote, stem_dir: str, stem_pos: str, stem_form: str
) -> MensuralNote:
    """Map a complete source triple onto normal-stem + optional cauda glyph.

    ``stem.form=oblique`` encodes a short left cauda, not an oblique vertical
    stem. Source dir/pos are ignored for the normal stem: minima/semiminima
    keep the D9 upward stem; other durations have no normal stem.
    """
    if stem_form == "oblique":
        return replace(
            note,
            glyph_auth=SMUFL_AUTH,
            glyph_name=GLYPH_OBLIQUE,
            stem_dir="up" if note.dur in _D9_STEMMED else None,
            stem_pos=None,
            stem_form=None,
        )
    return replace(
        note,
        stem_dir=stem_dir,
        stem_pos=stem_pos,
        stem_form=stem_form,
    )
