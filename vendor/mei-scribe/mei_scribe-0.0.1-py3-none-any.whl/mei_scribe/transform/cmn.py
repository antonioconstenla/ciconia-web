"""Transformation sémantique vers le modèle CMN (J7.2).

Produit un ``CmnDocument`` depuis un ``InputDocument`` déjà lu.
Ne reparcourt jamais le XML source. Ne résout ni tuplets ni ties.
"""

from __future__ import annotations

from mei_scribe.model.document import (
    InputDocument,
    InputEventAddress,
    InputInlineClef,
    InputMeasureRest,
    InputNote,
    InputRest,
    InputTieSpan,
    InputTuplet,
    ResolvedLigature,
    Voice,
)
from mei_scribe.signals.ligatures import resolve_ligatures
from mei_scribe.signals.space import index_space_directives
from mei_scribe.transform.clefs import modern_clef_for_voice
from mei_scribe.transform.errors import SemanticTransformError
from mei_scribe.transform.anchored_text import project_anchored_text
from mei_scribe.transform.metadata import project_output_metadata
from mei_scribe.transform.model import (
    CmnDocument,
    CmnLigature,
    CmnMeasure,
    CmnMeasureRest,
    CmnNote,
    CmnRest,
    CmnSpace,
    CmnTie,
    CmnTuplet,
    CmnVoice,
    CmnVoiceMeasure,
    EventProvenance,
    OutputWrittenAccidental,
)


def transform_to_cmn(document: InputDocument) -> CmnDocument:
    """Construit le modèle CMN sibling depuis ``document``."""
    metadata = project_output_metadata(document)
    source_voices = document.voices_in_order()
    space_by_anchor = index_space_directives(document)
    consumed_spaces: set[tuple[str, int, int]] = set()
    voices = tuple(_cmn_voice(voice, document) for voice in source_voices)
    measures = tuple(
        _cmn_measure(measure, space_by_anchor, consumed_spaces)
        for measure in document.measures
    )
    unused_spaces = set(space_by_anchor) - consumed_spaces
    if unused_spaces:
        sample = next(iter(unused_spaces))
        raise SemanticTransformError(
            "unconsumed space:type=measure-fill directive at "
            f"voice={sample[0]!r} measure={sample[1]} ordinal={sample[2]}"
        )
    tuplets = tuple(_cmn_tuplet(tuplet) for tuplet in document.tuplets)
    ties = tuple(
        _cmn_tie(tie)
        for tie in document.signals
        if isinstance(tie, InputTieSpan)
    )
    ligatures = tuple(
        _project_cmn_ligature(lig) for lig in resolve_ligatures(document)
    )
    meter_count, meter_unit = _shared_meter(source_voices)
    return CmnDocument(
        metadata=metadata,
        voices=voices,
        measures=measures,
        tuplets=tuplets,
        ties=ties,
        ligatures=ligatures,
        anchored_texts=project_anchored_text(document),
        meter_count=meter_count,
        meter_unit=meter_unit,
    )


def _shared_meter(voices: tuple[Voice, ...]) -> tuple[int | None, int | None]:
    """Exige une métrique homogène entre voix pour le scoreDef CMN."""
    if not voices:
        return (None, None)
    meters = tuple((voice.meter_count, voice.meter_unit) for voice in voices)
    first = meters[0]
    if any(meter != first for meter in meters[1:]):
        rendered = ", ".join(
            f"{voice.identity}=(count={voice.meter_count!r}, unit={voice.meter_unit!r})"
            for voice in voices
        )
        raise SemanticTransformError(
            f"inconsistent CMN meters across voices: {rendered}"
        )
    return first


def _cmn_voice(voice: Voice, document: InputDocument) -> CmnVoice:
    return CmnVoice(
        identity=voice.identity,
        name=voice.name,
        rank=voice.rank,
        clef=modern_clef_for_voice(document, voice),
    )


def _cmn_measure(measure, space_by_anchor, consumed_spaces) -> CmnMeasure:
    voices = tuple(
        CmnVoiceMeasure(
            voice_identity=content.voice_identity,
            events=tuple(
                _cmn_event(
                    event,
                    content.voice_identity,
                    content.measure_n,
                    space_by_anchor,
                    consumed_spaces,
                )
                for event in content.events
                # Diplomatic midstream clefs stay on the input model and the
                # mensural sibling; CMN keeps a single modernized staffDef clef.
                if not isinstance(event, InputInlineClef)
            ),
        )
        for content in measure.voices
    )
    return CmnMeasure(n=measure.n, voices=voices)


def _cmn_event(
    event,
    voice_identity: str,
    measure_n: int,
    space_by_anchor=None,
    consumed_spaces=None,
):
    address = InputEventAddress(
        voice_identity=voice_identity,
        measure_n=measure_n,
        ordinal=event.ordinal,
        event_kind=_kind(event),
    )
    provenance = EventProvenance(
        source_addresses=(address,),
        source_xml_ids=(event.source_xml_id,),
    )
    if isinstance(event, InputNote):
        accidental = None
        if event.written_accidental is not None:
            accidental = OutputWrittenAccidental(
                accid=event.written_accidental.accid,
                source_xml_id=event.written_accidental.source_xml_id,
                enclose=event.written_accidental.enclose,
            )
        return CmnNote(
            ordinal=event.ordinal,
            pname=event.pname,
            oct=event.oct,
            dur=event.dur,
            dots=event.dots,
            lyrics=event.lyrics,
            written_accidental=accidental,
            provenance=provenance,
        )
    if isinstance(event, InputRest):
        key = (voice_identity, measure_n, event.ordinal)
        if space_by_anchor and key in space_by_anchor:
            if consumed_spaces is not None:
                consumed_spaces.add(key)
            return CmnSpace(
                ordinal=event.ordinal,
                dur=event.dur,
                provenance=provenance,
            )
        return CmnRest(
            ordinal=event.ordinal,
            dur=event.dur,
            dots=event.dots,
            provenance=provenance,
        )
    if isinstance(event, InputMeasureRest):
        return CmnMeasureRest(ordinal=event.ordinal, provenance=provenance)
    raise SemanticTransformError(f"unsupported CMN event type {type(event)!r}")


def _kind(event) -> str:
    if isinstance(event, InputNote):
        return "note"
    if isinstance(event, InputRest):
        return "rest"
    if isinstance(event, InputMeasureRest):
        return "mRest"
    raise SemanticTransformError(f"unsupported event type {type(event)!r}")


def _cmn_tuplet(tuplet: InputTuplet) -> CmnTuplet:
    if not tuplet.member_addresses:
        raise SemanticTransformError("empty tuplet in CMN transform")
    voice = tuplet.member_addresses[0].voice_identity
    measure_n = tuplet.member_addresses[0].measure_n
    if any(
        address.voice_identity != voice or address.measure_n != measure_n
        for address in tuplet.member_addresses
    ):
        raise SemanticTransformError(
            "CMN tuplet members must share voice and measure"
        )
    return CmnTuplet(
        num=tuplet.num,
        numbase=tuplet.numbase,
        measure_n=measure_n,
        voice_identity=voice,
        member_ordinals=tuple(a.ordinal for a in tuplet.member_addresses),
        provenance=EventProvenance(
            source_addresses=tuplet.member_addresses,
            source_xml_ids=(tuplet.source_xml_id,),
        ),
    )


def _cmn_tie(tie: InputTieSpan) -> CmnTie:
    if tie.start.voice_identity != tie.end.voice_identity:
        raise SemanticTransformError("CMN tie endpoints must share a voice")
    return CmnTie(
        start_measure_n=tie.start.measure_n,
        start_ordinal=tie.start.ordinal,
        end_measure_n=tie.end.measure_n,
        end_ordinal=tie.end.ordinal,
        voice_identity=tie.start.voice_identity,
        provenance=EventProvenance(
            source_addresses=(tie.start, tie.end),
            source_xml_ids=(tie.source_xml_id,),
        ),
    )


def _project_cmn_ligature(lig: ResolvedLigature) -> CmnLigature:
    """Projette les membres EXPLICITES de la ligature source vers le CMN.

    Ne prolonge jamais le bracket à travers une tie technique : l'endpoint
    est la dernière adresse membre de ``ResolvedLigature``.
    """
    if len(lig.member_addresses) < 2:
        raise SemanticTransformError(
            "CMN ligature must contain at least two source members"
        )
    start = lig.member_addresses[0]
    end = lig.member_addresses[-1]
    if start.voice_identity != lig.voice_identity:
        raise SemanticTransformError("CMN ligature start voice mismatch")
    if end.voice_identity != lig.voice_identity:
        raise SemanticTransformError("CMN ligature end voice mismatch")
    if any(address.event_kind != "note" for address in lig.member_addresses):
        raise SemanticTransformError("CMN ligature members must be notes")
    return CmnLigature(
        voice_identity=lig.voice_identity,
        start_measure_n=start.measure_n,
        start_ordinal=start.ordinal,
        end_measure_n=end.measure_n,
        end_ordinal=end.ordinal,
        member_addresses=lig.member_addresses,
        source_text=lig.source_text,
        provenance=EventProvenance(
            source_addresses=lig.member_addresses,
            source_xml_ids=(lig.staff_text_xml_id, lig.pedal_xml_id),
        ),
    )
