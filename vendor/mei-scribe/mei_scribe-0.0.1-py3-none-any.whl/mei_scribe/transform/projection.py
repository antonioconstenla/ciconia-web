"""Explicit mensural projection routing (DIPLOMATIC_MENSURATION_V1)."""

from __future__ import annotations

from enum import Enum

from mei_scribe.model.document import InputDocument
from mei_scribe.transform.errors import SemanticTransformError

SUPPORTED_NOTATION = "mensural.black"
INTERPRETIVE_232_VALUES = (2, 3, 2)
DIPLOMATIC_222_VALUES = (2, 2, 2)


class ProjectionMode(str, Enum):
    """Internal routing mode for CMN/mensural projection."""

    INTERPRETIVE_232 = "interpretive-232"
    DIPLOMATIC_KNOWN_222 = "diplomatic-known-222"
    DIPLOMATIC_UNKNOWN = "diplomatic-unknown"


def is_diplomatic(mode: ProjectionMode) -> bool:
    return mode in {
        ProjectionMode.DIPLOMATIC_KNOWN_222,
        ProjectionMode.DIPLOMATIC_UNKNOWN,
    }


def classify_projection_mode(document: InputDocument) -> ProjectionMode:
    """Return the authorized projection mode or fail closed."""
    meta = document.metadata
    if meta is None:
        raise SemanticTransformError("missing document metadata for mensural transform")
    if meta.notation_type != SUPPORTED_NOTATION:
        raise SemanticTransformError(
            f"unsupported notation_type {meta.notation_type!r}"
        )

    has_mensuration_line = any(
        line.startswith("mensuration:") for line in meta.availability_lines
    )
    if meta.mensuration is None:
        if has_mensuration_line:
            raise SemanticTransformError(
                "legacy free-text mensuration does not activate diplomatic unknown"
            )
        if meta.mensur_in_source is True:
            raise SemanticTransformError(
                "mensur_in_source=true is not allowed when mensuration is unknown; "
                "refusing to invent a graphic <mensur>"
            )
        return ProjectionMode.DIPLOMATIC_UNKNOWN

    values = (
        meta.mensuration.modusminor,
        meta.mensuration.tempus,
        meta.mensuration.prolatio,
    )
    if values == INTERPRETIVE_232_VALUES:
        if meta.mensur_in_source is not False:
            raise SemanticTransformError(
                "J7.2 expects mensur_in_source=false for the normative contract"
            )
        return ProjectionMode.INTERPRETIVE_232
    if values == DIPLOMATIC_222_VALUES:
        if meta.mensur_in_source is True:
            raise SemanticTransformError(
                "mensur_in_source=true is not allowed for diplomatic 2/2/2; "
                "refusing to invent a graphic <mensur>"
            )
        return ProjectionMode.DIPLOMATIC_KNOWN_222
    raise SemanticTransformError(
        f"unsupported mensuration {values!r}; "
        f"J7.2 supports only {INTERPRETIVE_232_VALUES!r} "
        f"or diplomatic {DIPLOMATIC_222_VALUES!r}"
    )
