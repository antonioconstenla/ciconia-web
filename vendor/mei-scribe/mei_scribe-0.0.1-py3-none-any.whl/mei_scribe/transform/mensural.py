"""Transformation sémantique vers le modèle mensural (J7.2).

Produit un ``MensuralDocument`` depuis un ``InputDocument`` déjà lu.
Sibling de la transformation CMN : ne consomme jamais un ``CmnDocument``.
"""

from __future__ import annotations

from fractions import Fraction

from mei_scribe.model.document import (
    InputDocument,
    InputEventAddress,
    InputInlineClef,
    InputMeasureRest,
    InputNote,
    InputRest,
    InputTieSpan,
    InputTuplet,
    NoteGraphyDirective,
    RestDurationDirective,
    StructuredMensuration,
    Voice,
    is_rhythmic_event,
)
from mei_scribe.signals.ligatures import resolve_ligatures
from mei_scribe.transform.clefs import diplomatic_clefs_for_voice
from mei_scribe.transform.errors import SemanticTransformError
from mei_scribe.transform.anchored_text import project_anchored_text
from mei_scribe.transform.metadata import project_output_metadata
from mei_scribe.transform.model import (
    EventProvenance,
    MensuralDocument,
    MensuralEvent,
    MensuralInlineClef,
    MensuralLigature,
    MensuralNote,
    MensuralRest,
    MensuralVoice,
    OutputWrittenAccidental,
)
from mei_scribe.transform.note_graphy import apply_note_graphy_directives
from mei_scribe.transform.note_stem import apply_note_stem_directives
from mei_scribe.transform.custos import resolve_custos_boundaries
from mei_scribe.transform.source_systems import normalize_source_system_boundaries

SUPPORTED_NOTATION = "mensural.black"
SUPPORTED_MENSURATION = (2, 3, 2)


def transform_to_mensural(document: InputDocument) -> MensuralDocument:
    """Construit le modèle mensural sibling depuis ``document``."""
    _require_supported_mensuration(document)
    metadata = project_output_metadata(document)
    tuplet_members = _tuplet_member_index(document)
    tie_chains = _build_tie_chains(document, tuplet_members)
    cop_altera_member2 = _collect_cop_altera_member2_keys(document, tie_chains)

    voices: list[MensuralVoice] = []
    for voice in document.voices_in_order():
        events, note_map = _transform_voice_stream(
            document,
            voice,
            tuplet_members,
            tie_chains,
            cop_altera_member2,
        )
        ligatures = _project_ligatures(document, voice.identity, note_map)
        voices.append(
            MensuralVoice(
                identity=voice.identity,
                name=voice.name,
                rank=voice.rank,
                clefs=diplomatic_clefs_for_voice(document, voice),
                events=tuple(events),
                ligatures=ligatures,
            )
        )

    mensural = MensuralDocument(
        metadata=metadata,
        voices=tuple(voices),
        anchored_texts=project_anchored_text(document),
        source_system_boundaries=normalize_source_system_boundaries(document),
    )
    updated, _consumed = apply_note_stem_directives(document, mensural)
    updated, _consumed_graphy = apply_note_graphy_directives(document, updated)
    return resolve_custos_boundaries(document, updated)


def _require_supported_mensuration(document: InputDocument) -> None:
    meta = document.metadata
    if meta is None:
        raise SemanticTransformError("missing document metadata for mensural transform")
    if meta.notation_type != SUPPORTED_NOTATION:
        raise SemanticTransformError(
            f"unsupported notation_type {meta.notation_type!r}"
        )
    if meta.mensuration is None:
        raise SemanticTransformError("missing structured mensuration")
    values = (
        meta.mensuration.modusminor,
        meta.mensuration.tempus,
        meta.mensuration.prolatio,
    )
    if values != SUPPORTED_MENSURATION:
        raise SemanticTransformError(
            f"unsupported mensuration {values!r}; "
            f"J7.2 supports only {SUPPORTED_MENSURATION!r}"
        )
    if meta.mensur_in_source is not False:
        raise SemanticTransformError(
            "J7.2 expects mensur_in_source=false for the normative contract"
        )


def _address_key(address: InputEventAddress) -> tuple[str, int, int]:
    return (address.voice_identity, address.measure_n, address.ordinal)


def _tuplet_member_index(
    document: InputDocument,
) -> dict[tuple[str, int, int], InputTuplet]:
    index: dict[tuple[str, int, int], InputTuplet] = {}
    for tuplet in document.tuplets:
        if tuplet.num != 3 or tuplet.numbase != 2:
            raise SemanticTransformError(
                f"unsupported tuplet ratio {tuplet.num}:{tuplet.numbase}"
            )
        for address in tuplet.member_addresses:
            key = _address_key(address)
            if key in index:
                raise SemanticTransformError(
                    f"event belongs to multiple tuplets: {address!r}"
                )
            index[key] = tuplet
    return index


def _build_tie_chains(
    document: InputDocument,
    tuplet_members: dict[tuple[str, int, int], InputTuplet],
) -> list[tuple[InputEventAddress, ...]]:
    ties = [s for s in document.signals if isinstance(s, InputTieSpan)]
    successors: dict[tuple[str, int, int], InputEventAddress] = {}
    predecessors: dict[tuple[str, int, int], InputEventAddress] = {}

    for tie in ties:
        if tie.start.event_kind != "note" or tie.end.event_kind != "note":
            raise SemanticTransformError("tie endpoints must be notes")
        if tie.start.voice_identity != tie.end.voice_identity:
            raise SemanticTransformError("tie endpoints must share a voice")
        if (tie.start.measure_n, tie.start.ordinal) >= (
            tie.end.measure_n,
            tie.end.ordinal,
        ):
            raise SemanticTransformError("tie start must precede end")
        start_key = _address_key(tie.start)
        end_key = _address_key(tie.end)
        if start_key in tuplet_members or end_key in tuplet_members:
            raise SemanticTransformError(
                "tie member inside a tuplet is not supported in J7.2"
            )
        if start_key in successors:
            raise SemanticTransformError(
                f"note has multiple tie successors: {tie.start!r}"
            )
        if end_key in predecessors:
            raise SemanticTransformError(
                f"note has multiple tie predecessors: {tie.end!r}"
            )
        successors[start_key] = tie.end
        predecessors[end_key] = tie.start

    # Build chains from roots (no predecessor).
    chains: list[tuple[InputEventAddress, ...]] = []
    visited: set[tuple[str, int, int]] = set()
    roots = [
        address
        for address in (
            tie.start for tie in ties
        )
        if _address_key(address) not in predecessors
    ]
    # Stable order by document order of first member.
    roots = sorted(roots, key=lambda a: (a.voice_identity, a.measure_n, a.ordinal))

    for root in roots:
        chain = [root]
        current = root
        seen = {_address_key(root)}
        while _address_key(current) in successors:
            nxt = successors[_address_key(current)]
            key = _address_key(nxt)
            if key in seen:
                raise SemanticTransformError("tie cycle detected")
            chain.append(nxt)
            seen.add(key)
            current = nxt
        for address in chain:
            visited.add(_address_key(address))
        _validate_chain_notes(document, tuple(chain))
        chains.append(tuple(chain))

    # Every tie endpoint must belong to a chain.
    for tie in ties:
        if _address_key(tie.start) not in visited or _address_key(tie.end) not in visited:
            raise SemanticTransformError("incomplete tie chain coverage")

    return chains


def _longa_semibreves(mensuration: StructuredMensuration) -> Fraction:
    """Taille d'une longa en semibreves CMN : tempus × modusminor."""
    return Fraction(mensuration.tempus) * Fraction(mensuration.modusminor)


def _classify_fused_mensural_duration(
    total_sb: Fraction, longa_sb: Fraction
) -> str:
    """Classe une durée fusionnée par équivalent de longae, pas par longueur de chaîne."""
    if longa_sb <= 0:
        raise SemanticTransformError(f"invalid longa size {longa_sb}")
    quotient = total_sb / longa_sb
    if quotient.denominator != 1:
        raise SemanticTransformError(
            f"unsupported tied duration sum {total_sb} "
            f"(not an integer number of longae of {longa_sb})"
        )
    longae = quotient.numerator
    if longae == 1:
        return "longa"
    if longae in (2, 3):
        return "maxima"
    raise SemanticTransformError(
        f"unsupported tied duration sum {total_sb} "
        f"({longae} longae-equivalent; expected 1, 2, or 3)"
    )


def _require_supported_tie_figure(
    notes: list[InputNote], longa_sb: Fraction
) -> str:
    """Membres = breves pointées ; la figure résulte de la durée totale."""
    if not notes:
        raise SemanticTransformError("empty tie chain")
    for note in notes:
        if note.dur != "breve" or note.dots != 1:
            raise SemanticTransformError(
                "unsupported tie figure; fused ties support only dotted breves "
                f"(got dur={note.dur!r} dots={note.dots})"
            )
    total = sum(
        (_cmn_duration_semibreves(note.dur, note.dots) for note in notes),
        start=Fraction(0),
    )
    return _classify_fused_mensural_duration(total, longa_sb)


def _validate_chain_notes(
    document: InputDocument, chain: tuple[InputEventAddress, ...]
) -> None:
    notes = [document.event_at(a.voice_identity, a.measure_n, a.ordinal) for a in chain]
    if not all(isinstance(note, InputNote) for note in notes):
        raise SemanticTransformError("tie chain must contain only notes")
    typed = [note for note in notes if isinstance(note, InputNote)]
    first = typed[0]
    for note in typed[1:]:
        if note.pname != first.pname or note.oct != first.oct:
            raise SemanticTransformError("tie chain pitches must be identical")

    # Adjacency in the voice rhythmic stream (all events, not only notes).
    stream = _voice_event_addresses(document, chain[0].voice_identity)
    index = {_address_key(address): i for i, address in enumerate(stream)}
    positions = [index[_address_key(address)] for address in chain]
    for left, right in zip(positions, positions[1:]):
        if right != left + 1:
            raise SemanticTransformError(
                "tie chain members must be adjacent in the voice stream"
            )

    # Lyrics / accidentals compatibility.
    lyric_sets = [note.lyrics for note in typed if note.lyrics]
    if len(lyric_sets) > 1:
        first_lyrics = lyric_sets[0]
        for other in lyric_sets[1:]:
            if other != first_lyrics:
                raise SemanticTransformError(
                    "incompatible lyrics across tied note chain"
                )
    accidents = [
        note.written_accidental
        for note in typed
        if note.written_accidental is not None
    ]
    if len(accidents) > 1:
        first_acc = accidents[0]
        for other in accidents[1:]:
            if other != first_acc:
                raise SemanticTransformError(
                    "incompatible written accidentals across tied note chain"
                )

    meta = document.metadata
    if meta is None or meta.mensuration is None:
        raise SemanticTransformError("missing structured mensuration")
    _require_supported_tie_figure(typed, _longa_semibreves(meta.mensuration))


def _voice_event_addresses(
    document: InputDocument, voice_identity: str
) -> list[InputEventAddress]:
    addresses: list[InputEventAddress] = []
    for measure in document.measures:
        for content in measure.voices:
            if content.voice_identity != voice_identity:
                continue
            for event in content.events:
                if not is_rhythmic_event(event):
                    continue
                kind = (
                    "note"
                    if isinstance(event, InputNote)
                    else "rest"
                    if isinstance(event, InputRest)
                    else "mRest"
                )
                addresses.append(
                    InputEventAddress(
                        voice_identity=voice_identity,
                        measure_n=content.measure_n,
                        ordinal=event.ordinal,
                        event_kind=kind,
                    )
                )
    return addresses


def _cmn_duration_semibreves(dur: str, dots: int) -> Fraction:
    base = {
        "breve": Fraction(2),
        "1": Fraction(1),
        "2": Fraction(1, 2),
        "4": Fraction(1, 4),
        "8": Fraction(1, 8),
        "16": Fraction(1, 16),
        "32": Fraction(1, 32),
        "64": Fraction(1, 64),
    }.get(dur)
    if base is None:
        raise SemanticTransformError(f"unsupported CMN duration {dur!r}")
    if dots < 0:
        raise SemanticTransformError(f"invalid dots {dots}")
    if dots == 0:
        return base
    return base * (Fraction(2) - Fraction(1, 2**dots))


def _mrest_semibreves(voice: Voice) -> Fraction:
    if voice.meter_count is None or voice.meter_unit is None:
        raise SemanticTransformError(
            f"voice {voice.identity!r} missing meter for mRest duration"
        )
    # meter.unit=1 means whole note (= semibrevis); count wholes per measure.
    if voice.meter_unit != 1:
        raise SemanticTransformError(
            f"unsupported meter.unit={voice.meter_unit} for mRest duration"
        )
    return Fraction(voice.meter_count)


def _parse_rest_dur_token(token: str) -> tuple[str, int]:
    if not token.endswith("B"):
        raise SemanticTransformError(f"unsupported rest:dur token {token!r}")
    count_raw = token[:-1]
    if not count_raw.isdigit() or int(count_raw) < 1:
        raise SemanticTransformError(f"invalid rest:dur token {token!r}")
    return ("brevis", int(count_raw))


def _brevis_semibreves() -> Fraction:
    # Under tempus=3, a normal (perfect) brevis = 3 semibreves.
    return Fraction(3)


def _tied_address_keys(
    tie_chains: list[tuple[InputEventAddress, ...]],
) -> set[tuple[str, int, int]]:
    keys: set[tuple[str, int, int]] = set()
    for chain in tie_chains:
        if len(chain) < 2:
            continue
        for address in chain:
            keys.add(_address_key(address))
    return keys


def _caudata_anchor_keys(document: InputDocument) -> set[tuple[str, int, int]]:
    """Source addresses carrying explicit ``note:graphy=caudata``."""
    keys: set[tuple[str, int, int]] = set()
    for directive in document.directives:
        if (
            isinstance(directive, NoteGraphyDirective)
            and directive.graphy == "caudata"
        ):
            keys.add(_address_key(directive.anchor))
    return keys


def _collect_cop_altera_member2_keys(
    document: InputDocument,
    tie_chains: list[tuple[InputEventAddress, ...]],
) -> frozenset[tuple[str, int, int]]:
    """Addresses of ligature-initial member 2 notes reconstructed as SB altera.

    Predicates (all required):
    - effective tempus == 3
    - member 1 maps to written mensural semibrevis (undotted CMN whole)
    - member 2 source performed duration == exactly 2 SB (undotted CMN breve)
    - neither member participates in a multi-note tie fusion
    - member 2 has no explicit ``note:graphy=caudata`` (conflict guard)

    Only the INITIAL pair of each resolved ligature is considered.
    """
    meta = document.metadata
    assert meta is not None and meta.mensuration is not None
    if meta.mensuration.tempus != 3:
        return frozenset()

    tied = _tied_address_keys(tie_chains)
    caudata = _caudata_anchor_keys(document)
    targets: set[tuple[str, int, int]] = set()

    for lig in resolve_ligatures(document):
        if len(lig.member_addresses) < 2:
            continue
        a1, a2 = lig.member_addresses[0], lig.member_addresses[1]
        k1, k2 = _address_key(a1), _address_key(a2)
        if k1 in tied or k2 in tied:
            continue
        if k2 in caudata:
            # Explicit standalone-brevis graphy: do not reinterpret as altera.
            continue
        s1 = document.event_at(a1.voice_identity, a1.measure_n, a1.ordinal)
        s2 = document.event_at(a2.voice_identity, a2.measure_n, a2.ordinal)
        if not isinstance(s1, InputNote) or not isinstance(s2, InputNote):
            continue
        if _map_plain_duration(s1.dur, s1.dots) != ("semibrevis", None):
            continue
        # Exact performed duration of two normal semibreves (CMN undotted breve).
        if _cmn_duration_semibreves(s2.dur, s2.dots) != Fraction(2):
            continue
        if _map_plain_duration(s2.dur, s2.dots) != ("brevis", "imperfecta"):
            continue
        targets.add(k2)

    return frozenset(targets)


def _transform_voice_stream(
    document: InputDocument,
    voice: Voice,
    tuplet_members: dict[tuple[str, int, int], InputTuplet],
    tie_chains: list[tuple[InputEventAddress, ...]],
    cop_altera_member2: frozenset[tuple[str, int, int]] = frozenset(),
) -> tuple[list[MensuralEvent], dict[tuple[str, int, int], int]]:
    """Retourne les événements mensuraux et la carte adresse source -> ordinal."""
    chain_by_member: dict[tuple[str, int, int], tuple[InputEventAddress, ...]] = {}
    for chain in tie_chains:
        if chain[0].voice_identity != voice.identity:
            continue
        for address in chain:
            chain_by_member[_address_key(address)] = chain

    rest_by_anchor = _index_rest_directives(document, voice)
    consumed_directives: set[tuple[str, int, int]] = set()

    events: list[MensuralEvent] = []
    note_map: dict[tuple[str, int, int], int] = {}
    consumed: set[tuple[str, int, int]] = set()
    ordinal = 0

    stream = _iter_voice_events(document, voice.identity)
    i = 0
    while i < len(stream):
        address, event = stream[i]
        if isinstance(event, InputInlineClef):
            events.append(
                MensuralInlineClef(
                    shape=event.clef.shape,
                    line=event.clef.line,
                    provenance=EventProvenance(
                        source_addresses=(),
                        source_xml_ids=(event.source_xml_id,),
                    ),
                )
            )
            i += 1
            continue
        key = _address_key(address)
        if key in consumed:
            i += 1
            continue

        if isinstance(event, InputMeasureRest):
            run, run_end = _collect_mrest_run(stream, i)
            for run_address, _ in run:
                consumed.add(_address_key(run_address))
            segments, used_anchor = _resolve_mrest_run(
                document, voice, run, rest_by_anchor
            )
            if used_anchor is not None:
                consumed_directives.add(used_anchor)
            for unit, count, provenance in segments:
                ordinal += 1
                events.append(
                    MensuralRest(
                        ordinal=ordinal,
                        unit=unit,
                        count=count,
                        provenance=provenance,
                    )
                )
            i = run_end
            continue

        if isinstance(event, InputRest):
            ordinal += 1
            unit, count = _ordinary_rest(event)
            events.append(
                MensuralRest(
                    ordinal=ordinal,
                    unit=unit,
                    count=count,
                    provenance=EventProvenance(
                        source_addresses=(address,),
                        source_xml_ids=(event.source_xml_id,),
                    ),
                )
            )
            consumed.add(key)
            i += 1
            continue

        if isinstance(event, InputNote):
            if key in chain_by_member:
                chain = chain_by_member[key]
                if _address_key(chain[0]) != key:
                    raise SemanticTransformError(
                        "encountered tied note that is not chain head"
                    )
                for member in chain:
                    consumed.add(_address_key(member))
                ordinal += 1
                note = _fuse_tie_chain(document, chain)
                note = MensuralNote(
                    ordinal=ordinal,
                    pname=note.pname,
                    oct=note.oct,
                    dur=note.dur,
                    quality=note.quality,
                    lyrics=note.lyrics,
                    written_accidental=note.written_accidental,
                    provenance=note.provenance,
                )
                events.append(note)
                for member in chain:
                    note_map[_address_key(member)] = ordinal
                i += 1
                continue

            if key in tuplet_members:
                tuplet = tuplet_members[key]
                members = tuplet.member_addresses
                if _address_key(members[0]) != key:
                    raise SemanticTransformError(
                        "encountered tuplet member that is not group head"
                    )
                for member in members:
                    consumed.add(_address_key(member))
                resolved = _resolve_tuplet_members(document, tuplet)
                for member_address, mensural in zip(members, resolved, strict=True):
                    ordinal += 1
                    out = MensuralNote(
                        ordinal=ordinal,
                        pname=mensural.pname,
                        oct=mensural.oct,
                        dur=mensural.dur,
                        quality=mensural.quality,
                        lyrics=mensural.lyrics,
                        written_accidental=mensural.written_accidental,
                        provenance=mensural.provenance,
                    )
                    events.append(out)
                    note_map[_address_key(member_address)] = ordinal
                i += 1
                continue

            ordinal += 1
            mensural = _resolve_plain_note(
                event, address, as_semibrevis_altera=_address_key(address) in cop_altera_member2
            )
            out = MensuralNote(
                ordinal=ordinal,
                pname=mensural.pname,
                oct=mensural.oct,
                dur=mensural.dur,
                quality=mensural.quality,
                lyrics=mensural.lyrics,
                written_accidental=mensural.written_accidental,
                provenance=mensural.provenance,
            )
            events.append(out)
            note_map[key] = ordinal
            consumed.add(key)
            i += 1
            continue

        raise SemanticTransformError(f"unsupported event {type(event)!r}")

    unused = set(rest_by_anchor) - consumed_directives
    if unused:
        sample = next(iter(unused))
        raise SemanticTransformError(
            f"unused rest:dur directive for voice {voice.identity!r} "
            f"at measure={sample[1]} ordinal={sample[2]}"
        )

    return events, note_map


def _mrest_run_heads(
    stream: list[tuple[InputEventAddress, object]],
) -> set[tuple[str, int, int]]:
    heads: set[tuple[str, int, int]] = set()
    i = 0
    while i < len(stream):
        _, event = stream[i]
        if isinstance(event, InputMeasureRest):
            run, run_end = _collect_mrest_run(stream, i)
            heads.add(_address_key(run[0][0]))
            i = run_end
        else:
            i += 1
    return heads


def _index_rest_directives(
    document: InputDocument, voice: Voice
) -> dict[tuple[str, int, int], RestDurationDirective]:
    """Indexe et valide les directives ``rest:dur=`` d'une voix.

    Chaque directive doit être ancrée sur le premier ``mRest`` d'un run maximal,
    être unique pour cette ancre, et sera consommée exactement une fois.
    """
    directives = [
        directive
        for directive in document.directives
        if isinstance(directive, RestDurationDirective)
        and directive.anchor.voice_identity == voice.identity
    ]
    stream = _iter_voice_events(document, voice.identity)
    run_heads = _mrest_run_heads(stream)
    by_anchor: dict[tuple[str, int, int], RestDurationDirective] = {}

    for directive in directives:
        anchor = directive.anchor
        key = _address_key(anchor)
        try:
            event = document.event_at(
                anchor.voice_identity, anchor.measure_n, anchor.ordinal
            )
        except KeyError as exc:
            raise SemanticTransformError(
                f"rest:dur directive anchored on missing event {anchor!r}"
            ) from exc
        if not isinstance(event, InputMeasureRest):
            raise SemanticTransformError(
                f"rest:dur directive must be anchored on an mRest; "
                f"got {type(event).__name__} at {anchor!r}"
            )
        if key not in run_heads:
            raise SemanticTransformError(
                f"rest:dur directive must be anchored on the first mRest "
                f"of a maximal run; got {anchor!r}"
            )
        if key in by_anchor:
            raise SemanticTransformError(
                f"duplicate rest:dur directive at the same anchor {anchor!r}"
            )
        by_anchor[key] = directive

    return by_anchor


def _iter_voice_events(
    document: InputDocument, voice_identity: str
) -> list[tuple[InputEventAddress, object]]:
    items: list[tuple[InputEventAddress, object]] = []
    for measure in document.measures:
        for content in measure.voices:
            if content.voice_identity != voice_identity:
                continue
            for event in content.events:
                if isinstance(event, InputInlineClef):
                    items.append((None, event))
                    continue
                kind = (
                    "note"
                    if isinstance(event, InputNote)
                    else "rest"
                    if isinstance(event, InputRest)
                    else "mRest"
                )
                address = InputEventAddress(
                    voice_identity=voice_identity,
                    measure_n=content.measure_n,
                    ordinal=event.ordinal,
                    event_kind=kind,
                )
                items.append((address, event))
    return items


def _collect_mrest_run(stream, start: int):
    run = []
    i = start
    while i < len(stream):
        address, event = stream[i]
        if not isinstance(event, InputMeasureRest):
            break
        run.append((address, event))
        i += 1
    if not run:
        raise SemanticTransformError("empty mRest run")
    return run, i


def _fallback_segment_mrest_run(
    document: InputDocument,
    voice: Voice,
    run: list[tuple[InputEventAddress, InputMeasureRest]],
) -> list[tuple[str, int, EventProvenance]]:
    """Segmente un run (ou suffixe) de ``mRest`` par ``modusminor``.

    Même algorithme que l'historique sans ``rest:dur`` : groupes de
    ``modusminor`` breves, puis reste final si besoin.
    """
    if not run:
        raise SemanticTransformError("empty rest segmentation")
    addresses = tuple(address for address, _ in run)
    xml_ids = tuple(event.source_xml_id for _, event in run)
    provenance = EventProvenance(
        source_addresses=addresses,
        source_xml_ids=xml_ids,
    )
    total = _mrest_semibreves(voice) * len(run)
    meta = document.metadata
    assert meta is not None and meta.mensuration is not None
    group = meta.mensuration.modusminor
    if group not in {2, 3}:
        raise SemanticTransformError(
            f"cannot fallback-segment rests with modusminor={group}"
        )
    units = total / _brevis_semibreves()
    if units.denominator != 1:
        raise SemanticTransformError(
            f"mRest run duration {total} is not an integer number of breves"
        )
    remaining = int(units)
    segments: list[tuple[str, int, EventProvenance]] = []
    while remaining >= group:
        segments.append(("brevis", group, provenance))
        remaining -= group
    if remaining:
        segments.append(("brevis", remaining, provenance))
    if not segments:
        raise SemanticTransformError("empty rest segmentation")
    return segments


def _resolve_mrest_run(
    document: InputDocument,
    voice: Voice,
    run: list[tuple[InputEventAddress, InputMeasureRest]],
    rest_by_anchor: dict[tuple[str, int, int], RestDurationDirective],
) -> tuple[list[tuple[str, int, EventProvenance]], tuple[str, int, int] | None]:
    """Segmente un run maximal de ``mRest``.

    ``rest:dur`` ancré en tête définit un préfixe explicite contigu. S'il
    consomme moins que le run, le suffixe restant utilise le fallback
    ``modusminor`` existant. Un total explicite supérieur au run bloque.
    """
    addresses = tuple(address for address, _ in run)
    xml_ids = tuple(event.source_xml_id for _, event in run)
    total = _mrest_semibreves(voice) * len(run)
    mrest_sb = _mrest_semibreves(voice)
    anchor_key = _address_key(addresses[0])
    directive = rest_by_anchor.get(anchor_key)

    if directive is None:
        return _fallback_segment_mrest_run(document, voice, run), None

    segments = [_parse_rest_dur_token(token) for token in directive.values]
    declared = sum((_brevis_semibreves() * count) for _, count in segments)

    if declared > total:
        raise SemanticTransformError(
            f"rest:dur segmentation duration {declared} exceeds "
            f"mRest run duration {total} for voice {voice.identity!r}"
        )
    # Le préfixe doit s'arrêter sur une frontière d'événement mRest.
    if declared % mrest_sb != 0:
        raise SemanticTransformError(
            f"rest:dur segmentation duration {declared} does not align with "
            f"mRest boundaries of size {mrest_sb} for voice {voice.identity!r}"
        )

    consumed = int(declared / mrest_sb)
    prefix_run = run[:consumed]
    suffix_run = run[consumed:]

    if not suffix_run:
        provenance = EventProvenance(
            source_addresses=addresses,
            source_xml_ids=xml_ids,
        )
        return (
            [(unit, count, provenance) for unit, count in segments],
            anchor_key,
        )

    prefix_provenance = EventProvenance(
        source_addresses=tuple(address for address, _ in prefix_run),
        source_xml_ids=tuple(event.source_xml_id for _, event in prefix_run),
    )
    explicit = [
        (unit, count, prefix_provenance) for unit, count in segments
    ]
    trailing = _fallback_segment_mrest_run(document, voice, suffix_run)
    return explicit + trailing, anchor_key


def _ordinary_rest(event: InputRest) -> tuple[str, int]:
    if event.dots != 0:
        raise SemanticTransformError("dotted ordinary rest not supported in J7.2")
    if event.dur == "1":
        return ("semibrevis", 1)
    if event.dur == "2":
        return ("minima", 1)
    raise SemanticTransformError(
        f"unsupported ordinary rest duration {event.dur!r}"
    )


def _accidental(note: InputNote) -> OutputWrittenAccidental | None:
    written = note.written_accidental
    if written is None:
        return None
    if written.enclose == "paren":
        # Editorial parenthesized accidental: CMN-only visual; Mensural
        # pitch remains source pname/oct, not this written glyph.
        return None
    return OutputWrittenAccidental(
        accid=written.accid,
        source_xml_id=written.source_xml_id,
        enclose=written.enclose,
    )


def _resolve_plain_note(
    note: InputNote,
    address: InputEventAddress,
    *,
    as_semibrevis_altera: bool = False,
) -> MensuralNote:
    if as_semibrevis_altera:
        # COP reconstruction: CMN undotted breve (= 2 SB performed) → SB altera.
        # Exact duration conservation: imperfect brevis (2 SB) == altera SB (2 SB).
        if _cmn_duration_semibreves(note.dur, note.dots) != Fraction(2):
            raise SemanticTransformError(
                "COP altera target must have performed duration of exactly 2 SB"
            )
        dur, quality = "semibrevis", "altera"
    else:
        dur, quality = _map_plain_duration(note.dur, note.dots)
    return MensuralNote(
        ordinal=0,
        pname=note.pname,
        oct=note.oct,
        dur=dur,
        quality=quality,
        lyrics=note.lyrics,
        written_accidental=_accidental(note),
        provenance=EventProvenance(
            source_addresses=(address,),
            source_xml_ids=(note.source_xml_id,),
        ),
    )


def _map_plain_duration(dur: str, dots: int) -> tuple[str, str | None]:
    if dur == "breve" and dots == 1:
        return ("brevis", None)
    if dur == "breve" and dots == 0:
        return ("brevis", "imperfecta")
    if dur == "1" and dots == 0:
        return ("semibrevis", None)
    if dur == "1" and dots == 1:
        return ("semibrevis", "perfecta")
    if dur == "2" and dots == 0:
        return ("minima", None)
    raise SemanticTransformError(
        f"unsupported plain CMN duration dur={dur!r} dots={dots}"
    )


def _resolve_tuplet_members(
    document: InputDocument, tuplet: InputTuplet
) -> list[MensuralNote]:
    pattern = []
    notes: list[InputNote] = []
    for address in tuplet.member_addresses:
        event = document.event_at(
            address.voice_identity, address.measure_n, address.ordinal
        )
        if not isinstance(event, InputNote):
            raise SemanticTransformError("tuplet members must be notes in J7.2")
        if event.dots != 0:
            raise SemanticTransformError("dotted tuplet members not supported")
        notes.append(event)
        pattern.append(event.dur)

    if pattern == ["2", "2", "2"]:
        mapped = ["semiminima", "semiminima", "semiminima"]
    elif pattern == ["1", "2"]:
        mapped = ["minima", "semiminima"]
    else:
        raise SemanticTransformError(
            f"unsupported tuplet member pattern {tuple(pattern)!r}"
        )

    result: list[MensuralNote] = []
    for address, note, dur in zip(
        tuplet.member_addresses, notes, mapped, strict=True
    ):
        result.append(
            MensuralNote(
                ordinal=0,
                pname=note.pname,
                oct=note.oct,
                dur=dur,
                quality=None,
                lyrics=note.lyrics,
                written_accidental=_accidental(note),
                provenance=EventProvenance(
                    source_addresses=(address,),
                    source_xml_ids=(note.source_xml_id,),
                ),
            )
        )
    return result


def _fuse_tie_chain(
    document: InputDocument, chain: tuple[InputEventAddress, ...]
) -> MensuralNote:
    notes = [
        document.event_at(a.voice_identity, a.measure_n, a.ordinal)
        for a in chain
    ]
    assert all(isinstance(n, InputNote) for n in notes)
    typed = [n for n in notes if isinstance(n, InputNote)]
    meta = document.metadata
    if meta is None or meta.mensuration is None:
        raise SemanticTransformError("missing structured mensuration")
    dur = _require_supported_tie_figure(
        typed, _longa_semibreves(meta.mensuration)
    )

    lyrics = ()
    for note in typed:
        if note.lyrics:
            lyrics = note.lyrics
            break
    accidental = None
    for note in typed:
        if note.written_accidental is not None:
            accidental = _accidental(note)
            break

    first = typed[0]
    return MensuralNote(
        ordinal=0,
        pname=first.pname,
        oct=first.oct,
        dur=dur,
        quality=None,
        lyrics=lyrics,
        written_accidental=accidental,
        provenance=EventProvenance(
            source_addresses=chain,
            source_xml_ids=tuple(n.source_xml_id for n in typed),
        ),
    )


def _project_ligatures(
    document: InputDocument,
    voice_identity: str,
    note_map: dict[tuple[str, int, int], int],
) -> tuple[MensuralLigature, ...]:
    resolved = resolve_ligatures(document)
    projected: list[MensuralLigature] = []
    for lig in resolved:
        if lig.voice_identity != voice_identity:
            continue
        ordinal_forms: list[tuple[int, str]] = []
        for address, form in zip(
            lig.member_addresses, lig.effective_forms, strict=True
        ):
            key = _address_key(address)
            if key not in note_map:
                raise SemanticTransformError(
                    f"ligature member not found in mensural notes: {address!r}"
                )
            ordinal_forms.append((note_map[key], form))

        # Collapse members that fused into the same output note.
        collapsed: list[tuple[int, str]] = []
        for ordinal, form in ordinal_forms:
            if collapsed and collapsed[-1][0] == ordinal:
                if collapsed[-1][1] != form:
                    raise SemanticTransformError(
                        "conflicting ligature forms after tie fusion"
                    )
                continue
            collapsed.append((ordinal, form))

        ordinals = tuple(item[0] for item in collapsed)
        forms = tuple(item[1] for item in collapsed)
        if ordinals != tuple(sorted(ordinals)):
            raise SemanticTransformError("ligature members are not ordered")
        projected.append(
            MensuralLigature(
                voice_identity=voice_identity,
                member_ordinals=ordinals,
                effective_forms=forms,
                source_text=lig.source_text,
                provenance=EventProvenance(
                    source_addresses=lig.member_addresses,
                    source_xml_ids=(lig.staff_text_xml_id, lig.pedal_xml_id),
                ),
            )
        )
    return tuple(projected)
