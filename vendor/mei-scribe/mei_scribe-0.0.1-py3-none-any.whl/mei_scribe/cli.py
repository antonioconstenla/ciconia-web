"""Interface en ligne de commande de mei-scribe.

Entry point ``mei-scribe`` et sous-commande ``convert`` (J7.3) :
une entrée MEI Basic → deux sorties sibling CMN + mensural.
"""

from __future__ import annotations

import argparse
import sys
from collections.abc import Sequence
from pathlib import Path

from mei_scribe.api import convert_mei_bytes
from mei_scribe.contracts import VoicePolicy
from mei_scribe.io.errors import (
    ConventionSyntaxError,
    LigatureResolutionError,
    LigatureSyntaxError,
    MetadataError,
    MusicalEventsError,
    OutputValidationError,
    SourceSignalsError,
    VoiceTopologyError,
    WriterError,
)
from mei_scribe.io.writer import _atomic_write_pair
from mei_scribe.transform import SemanticTransformError
from mei_scribe.transform.model import OutputDiagnostic


_BUSINESS_ERRORS = (
    ConventionSyntaxError,
    LigatureResolutionError,
    LigatureSyntaxError,
    MetadataError,
    MusicalEventsError,
    OutputValidationError,
    SourceSignalsError,
    VoiceTopologyError,
    WriterError,
    SemanticTransformError,
    OSError,
    FileNotFoundError,
    ValueError,
    KeyError,
)


def build_parser() -> argparse.ArgumentParser:
    """Construit le parseur d'arguments de la CLI."""
    parser = argparse.ArgumentParser(
        prog="mei-scribe",
        description=(
            "Outillage de transcription et de transformation de partitions MEI."
        ),
    )
    subparsers = parser.add_subparsers(dest="command")

    convert = subparsers.add_parser(
        "convert",
        help="Convertir un MEI Basic en couple sibling CMN + mensural.",
        description=(
            "Lit un MEI Basic, applique le pipeline J7 "
            "(lecture → transformation → writers) et écrit exactement deux "
            "fichiers : <stem>.cmn.mei et <stem>.mensural.mei."
        ),
    )
    convert.add_argument(
        "input",
        help="Chemin du fichier MEI Basic d'entrée.",
    )
    convert.add_argument(
        "--out-dir",
        help=(
            "Répertoire de sortie (créé si besoin). "
            "Par défaut : répertoire parent du fichier d'entrée."
        ),
    )
    convert.set_defaults(func=_cmd_convert)

    return parser


def format_diagnostic_line(diagnostic: OutputDiagnostic) -> str:
    """Format stderr déterministe pour un diagnostic J7.2."""
    parts = [
        f"{diagnostic.severity} [{diagnostic.code}]",
        f"feature={diagnostic.feature}",
    ]
    if diagnostic.voice_identity is not None:
        parts.append(f"voice={diagnostic.voice_identity}")
    if diagnostic.measure_n is not None:
        parts.append(f"measure={diagnostic.measure_n}")
    if diagnostic.ordinal is not None:
        parts.append(f"ordinal={diagnostic.ordinal}")
    if diagnostic.surface is not None:
        parts.append(f"surface={diagnostic.surface}")
    if diagnostic.paratext_type is not None:
        parts.append(f"type={diagnostic.paratext_type}")
    if diagnostic.position is not None:
        parts.append(f"position={diagnostic.position}")
    if diagnostic.source_text is not None:
        parts.append(f"text={diagnostic.source_text}")
    if diagnostic.source_xml_id is not None:
        parts.append(f"xml:id={diagnostic.source_xml_id}")
    return " ".join(parts)


def _emit_diagnostics(diagnostics: tuple[OutputDiagnostic, ...], stream) -> None:
    for diagnostic in diagnostics:
        print(format_diagnostic_line(diagnostic), file=stream)


def _cmd_convert(args: argparse.Namespace) -> int:
    """Sous-commande ``convert`` : pipeline J7 complet."""
    input_path = Path(args.input)
    out_dir = Path(args.out_dir) if args.out_dir else None
    try:
        if not input_path.is_file():
            raise FileNotFoundError(f"input file not found: {input_path}")
        result = convert_mei_bytes(
            input_path.read_bytes(),
            source_name=input_path.name,
            policy=VoicePolicy.SOURCE_ORDER_V1,
        )
        target_dir = out_dir if out_dir is not None else input_path.parent
        target_dir.mkdir(parents=True, exist_ok=True)
        suggested = result.metadata.suggested_output_names
        if suggested is None:
            raise WriterError("missing suggested output names for CLI conversion")
        cmn_path = target_dir / suggested.cmn_name
        mensural_path = target_dir / suggested.mensural_name
        _atomic_write_pair(
            (cmn_path, result.cmn_mei),
            (mensural_path, result.mensural_mei),
        )
    except _BUSINESS_ERRORS as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1

    _emit_diagnostics(result.diagnostics, sys.stderr)
    print(f"CMN: {cmn_path}")
    print(f"Mensural: {mensural_path}")
    print(f"Warnings: {len(result.diagnostics)}")
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    """Point d'entrée de la CLI ``mei-scribe``."""
    parser = build_parser()
    args = parser.parse_args(argv)

    if not getattr(args, "command", None):
        parser.print_help()
        return 0

    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
