"""Grammaire SOURCE_GAPS_AND_TECHNICAL_SPACE_V1 (space:type=measure-fill)."""

from __future__ import annotations

from collections import defaultdict

from mei_scribe.io.errors import ConventionSyntaxError
from mei_scribe.model.document import (
    DamageDirective,
    GapDirective,
    InputEventAddress,
    InputRest,
    InputStaffTextSignal,
    SpaceDirective,
    StructuredDirective,
    UnclearDirective,
)

SPACE_PREFIX = "space:"
SPACE_EXACT = "space:type=measure-fill"
MEASURE_FILL = "measure-fill"


def parse_space(signal: InputStaffTextSignal) -> SpaceDirective:
    raw = signal.source_text
    if not raw.startswith(SPACE_PREFIX):
        raise ConventionSyntaxError(
            _ctx(signal, f"expected {SPACE_PREFIX!r}, got {raw!r}")
        )
    if raw != SPACE_EXACT:
        raise ConventionSyntaxError(
            _ctx(
                signal,
                f"invalid space directive {raw!r}; V1 allows only {SPACE_EXACT!r}",
            )
        )
    kind = signal.anchor.event_kind
    if kind != "rest":
        raise ConventionSyntaxError(
            _ctx(
                signal,
                f"space:type=measure-fill must be anchored on an ordinary rest, "
                f"got {kind!r}",
            )
        )
    return SpaceDirective(
        type=MEASURE_FILL,
        anchor=signal.anchor,
        source_text=raw,
        source_xml_id=signal.source_xml_id,
    )


def validate_space_composition(
    directives: tuple[StructuredDirective, ...] | list[StructuredDirective],
) -> None:
    """Reject same-anchor contradictions with space:type=measure-fill."""
    grouped: dict[tuple[str, int, int], list[StructuredDirective]] = defaultdict(list)
    for directive in directives:
        if isinstance(
            directive, (SpaceDirective, UnclearDirective, DamageDirective, GapDirective)
        ):
            grouped[_anchor_key(directive.anchor)].append(directive)

    for group in grouped.values():
        spaces = [item for item in group if isinstance(item, SpaceDirective)]
        if not spaces:
            continue
        if len(spaces) > 1:
            sample = spaces[1]
            raise ConventionSyntaxError(
                _anchor_ctx(
                    sample.anchor,
                    sample.source_xml_id,
                    "duplicate space:type=measure-fill on one rest "
                    f"in {sample.source_text!r}",
                )
            )
        space = spaces[0]
        for item in group:
            if isinstance(item, UnclearDirective) and item.target == "dur":
                raise ConventionSyntaxError(
                    _anchor_ctx(
                        space.anchor,
                        space.source_xml_id,
                        "space:type=measure-fill cannot combine with "
                        f"unclear:target=dur in {item.source_text!r}",
                    )
                )
            if isinstance(item, DamageDirective):
                raise ConventionSyntaxError(
                    _anchor_ctx(
                        space.anchor,
                        space.source_xml_id,
                        "space:type=measure-fill cannot combine with damage "
                        f"on the same rest in {item.source_text!r}",
                    )
                )
            if isinstance(item, GapDirective):
                raise ConventionSyntaxError(
                    _anchor_ctx(
                        space.anchor,
                        space.source_xml_id,
                        "space:type=measure-fill cannot combine with gap "
                        f"on the same rest in {item.source_text!r}",
                    )
                )


def index_space_directives(
    document,
) -> dict[tuple[str, int, int], SpaceDirective]:
    """Index space directives and reject dotted technical fillers."""
    from mei_scribe.transform.errors import SemanticTransformError

    found: dict[tuple[str, int, int], SpaceDirective] = {}
    for directive in document.directives:
        if not isinstance(directive, SpaceDirective):
            continue
        anchor = directive.anchor
        try:
            event = document.event_at(
                anchor.voice_identity, anchor.measure_n, anchor.ordinal
            )
        except KeyError as exc:
            raise SemanticTransformError(
                _anchor_ctx(
                    anchor,
                    directive.source_xml_id,
                    "space:type=measure-fill anchored on missing event",
                )
            ) from exc
        if not isinstance(event, InputRest):
            raise SemanticTransformError(
                _anchor_ctx(
                    anchor,
                    directive.source_xml_id,
                    "space:type=measure-fill must target an ordinary rest, "
                    f"got {type(event).__name__}",
                )
            )
        if event.dots != 0:
            raise SemanticTransformError(
                _anchor_ctx(
                    anchor,
                    directive.source_xml_id,
                    "dotted technical filler is not supported in V1; "
                    f"got dots={event.dots}",
                )
            )
        found[_anchor_key(anchor)] = directive
    return found


def _anchor_key(anchor: InputEventAddress) -> tuple[str, int, int]:
    return (anchor.voice_identity, anchor.measure_n, anchor.ordinal)


def _ctx(signal: InputStaffTextSignal, message: str) -> str:
    return _anchor_ctx(signal.anchor, signal.source_xml_id, message)


def _anchor_ctx(anchor: InputEventAddress, source_xml_id: str, message: str) -> str:
    return (
        f"voice={anchor.voice_identity!r} measure={anchor.measure_n} "
        f"ordinal={anchor.ordinal} xml:id={source_xml_id!r}: {message}"
    )
