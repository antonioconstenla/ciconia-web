"""Grammar for the exact diplomatic source-dot convention ``dot:form=aug``."""

from __future__ import annotations

from mei_scribe.io.errors import ConventionSyntaxError
from mei_scribe.model.document import InputEventAddress, InputStaffTextSignal, DotDirective

DOT_PREFIX = "dot:"
DOT_EXACT = "dot:form=aug"
AUG_FORM = "aug"


def parse_dot(signal: InputStaffTextSignal) -> DotDirective:
    raw = signal.source_text
    if not raw.startswith(DOT_PREFIX):
        raise ConventionSyntaxError(_ctx(signal, f"expected {DOT_PREFIX!r}, got {raw!r}"))
    if raw != DOT_EXACT:
        raise ConventionSyntaxError(
            _ctx(
                signal,
                f"unsupported dot directive {raw!r}; V1 allows only {DOT_EXACT!r}",
            )
        )
    kind = signal.anchor.event_kind
    if kind != "note":
        raise ConventionSyntaxError(
            _ctx(signal, f"dot:form=aug must be anchored on a note, got {kind!r}")
        )
    return DotDirective(
        form=AUG_FORM,
        anchor=signal.anchor,
        source_text=raw,
        source_xml_id=signal.source_xml_id,
    )


def index_dot_directives(document) -> dict[tuple[str, int, int], DotDirective]:
    """Map source addresses to consumed ``dot:form=aug`` directives."""
    index: dict[tuple[str, int, int], DotDirective] = {}
    for directive in document.directives:
        if not isinstance(directive, DotDirective):
            continue
        key = (
            directive.anchor.voice_identity,
            directive.anchor.measure_n,
            directive.anchor.ordinal,
        )
        if key in index:
            raise ConventionSyntaxError(
                _anchor_ctx(
                    directive.anchor,
                    directive.source_xml_id,
                    "duplicate dot:form=aug on one note",
                )
            )
        index[key] = directive
    return index


def _ctx(signal: InputStaffTextSignal, message: str) -> str:
    return _anchor_ctx(signal.anchor, signal.source_xml_id, message)


def _anchor_ctx(anchor: InputEventAddress, source_xml_id: str, message: str) -> str:
    return (
        f"voice={anchor.voice_identity!r} measure={anchor.measure_n} "
        f"ordinal={anchor.ordinal} xml:id={source_xml_id!r}: {message}"
    )
