"""Sémantique des ligatures source (J6 / J7.1).

Analyse structurée des textes ``lig:`` (historique) et
``ligature:form=`` (normatif), puis résolution des couples
Staff Text + span ``pedal`` vers des ligatures internes immuables.

Indépendant de ``ElementTree`` et du reader XML. Ne mute pas le document
J5 et ne produit aucun élément MEI cible.
"""

from __future__ import annotations

import re

from mei_scribe.io.errors import LigatureResolutionError, LigatureSyntaxError
from mei_scribe.model.document import (
    InputDocument,
    InputEventAddress,
    InputMeasureRest,
    InputNote,
    InputPedalSpan,
    InputRest,
    InputStaffTextSignal,
    LigatureFormChange,
    MusicalEvent,
    ParsedLigatureText,
    ResolvedLigature,
    is_rhythmic_event,
)

LIGATURE_PREFIX = "lig:"
LIGATURE_FORM_PREFIX = "ligature:form="
ALLOWED_FORMS: frozenset[str] = frozenset({"recta", "obliqua"})
LIGATURE_LEXICAL_PREFIXES: frozenset[str] = frozenset({"lig", "ligature"})
_POSITION_RE = re.compile(r"^[1-9][0-9]*$")


def parse_ligature_text(raw: str) -> ParsedLigatureText:
    """Parse ``lig:...`` (J6) ou ``ligature:form=...`` (J7.1).

    Les deux syntaxes produisent la même ``ParsedLigatureText``.
    """
    if not isinstance(raw, str) or raw.strip() == "":
        raise LigatureSyntaxError("ligature text must be non-empty")
    if raw.startswith(LIGATURE_FORM_PREFIX):
        return _parse_ligature_form_equals(raw)
    if raw.startswith(LIGATURE_PREFIX):
        return _parse_legacy_lig_pipe(raw)
    raise LigatureSyntaxError(
        "ligature text must start with "
        f"{LIGATURE_PREFIX!r} or {LIGATURE_FORM_PREFIX!r}, got {raw!r}"
    )


def _parse_legacy_lig_pipe(raw: str) -> ParsedLigatureText:
    """Grammaire historique ``lig:<forme>(|<forme>:<position>)*``."""
    body = raw[len(LIGATURE_PREFIX) :]
    if body == "":
        raise LigatureSyntaxError("ligature text has empty payload after 'lig:'")
    if "," in body:
        raise LigatureSyntaxError(
            f"unsupported ancillary payload in ligature text {raw!r}"
        )
    if ";" in body:
        raise LigatureSyntaxError(
            f"unsupported ';' separator in ligature text {raw!r}"
        )
    if body.endswith("|"):
        raise LigatureSyntaxError(
            f"trailing separator in ligature text {raw!r}"
        )

    segments = body.split("|")
    if any(segment == "" for segment in segments):
        raise LigatureSyntaxError(
            f"empty segment in ligature text {raw!r}"
        )
    return _parsed_from_segments(raw, segments, separator="|")


def _parse_ligature_form_equals(raw: str) -> ParsedLigatureText:
    """Grammaire normative ``ligature:form=<forme>(,<forme>:<position>)*``."""
    body = raw[len(LIGATURE_FORM_PREFIX) :]
    if body == "":
        raise LigatureSyntaxError(
            "ligature text has empty payload after 'ligature:form='"
        )
    if " " in body or "\t" in body:
        raise LigatureSyntaxError(
            f"spaces are not allowed in ligature:form payload {raw!r}"
        )
    if "|" in body:
        raise LigatureSyntaxError(
            f"unsupported '|' separator in ligature:form text {raw!r}"
        )
    if ";" in body:
        raise LigatureSyntaxError(
            f"unsupported ';' separator in ligature:form text {raw!r}"
        )
    if body.endswith(","):
        raise LigatureSyntaxError(
            f"trailing separator in ligature text {raw!r}"
        )

    segments = body.split(",")
    if any(segment == "" for segment in segments):
        raise LigatureSyntaxError(
            f"empty segment in ligature text {raw!r}"
        )
    return _parsed_from_segments(raw, segments, separator=",")


def _parsed_from_segments(
    raw: str, segments: list[str], *, separator: str
) -> ParsedLigatureText:
    del separator  # documented by caller; unused beyond split choice
    initial_form = _parse_form(segments[0], raw)
    changes: list[LigatureFormChange] = []
    previous_position = 1
    active_form = initial_form

    for segment in segments[1:]:
        if ":" not in segment:
            raise LigatureSyntaxError(
                f"missing position in ligature segment {segment!r} of {raw!r}"
            )
        form_part, position_part = segment.split(":", 1)
        if form_part == "" or position_part == "":
            raise LigatureSyntaxError(
                f"invalid ligature segment {segment!r} in {raw!r}"
            )
        if "-" in position_part:
            raise LigatureSyntaxError(
                f"unsupported range syntax in ligature text {raw!r}"
            )
        form = _parse_form(form_part, raw)
        position = _parse_position(position_part, raw)
        if position == 1:
            raise LigatureSyntaxError(
                f"position 1 cannot be repeated after the initial form in {raw!r}"
            )
        if position <= previous_position:
            raise LigatureSyntaxError(
                f"ligature positions must be strictly increasing in {raw!r} "
                f"(got {position} after {previous_position})"
            )
        if form == active_form:
            raise LigatureSyntaxError(
                f"redundant form change to {form!r} at position {position} "
                f"in {raw!r}"
            )
        changes.append(LigatureFormChange(position=position, form=form))
        previous_position = position
        active_form = form

    return ParsedLigatureText(
        source_text=raw,
        initial_form=initial_form,
        changes=tuple(changes),
    )


def expand_ligature_forms(
    parsed: ParsedLigatureText, length: int
) -> tuple[str, ...]:
    """Développe les changements en une forme effective par note (1-based)."""
    if length < 1:
        raise LigatureResolutionError(
            "ligature must contain at least one note position"
        )
    for change in parsed.changes:
        if change.position > length:
            raise LigatureResolutionError(
                f"form change at position {change.position} exceeds "
                f"ligature length {length} in {parsed.source_text!r}"
            )

    schedule: list[tuple[int, str]] = [(1, parsed.initial_form)]
    schedule.extend((change.position, change.form) for change in parsed.changes)

    forms: list[str] = []
    active = parsed.initial_form
    schedule_index = 0
    for position in range(1, length + 1):
        while (
            schedule_index < len(schedule)
            and schedule[schedule_index][0] == position
        ):
            active = schedule[schedule_index][1]
            schedule_index += 1
        forms.append(active)
    return tuple(forms)


def resolve_ligatures(document: InputDocument) -> tuple[ResolvedLigature, ...]:
    """Résout les couples ligature / ``pedal`` d'un ``InputDocument``.

    Accepte ``lig:`` (J6) et ``ligature:form=`` (J7.1). Parcourt les
    signaux dans l'ordre documentaire. Un ``pedal`` sans texte de
    ligature reste non interprété. Ne mute pas ``document``.
    """
    lig_signals = [
        signal
        for signal in document.signals
        if isinstance(signal, InputStaffTextSignal)
        and signal.lexical_prefix in LIGATURE_LEXICAL_PREFIXES
    ]
    pedals = [
        signal
        for signal in document.signals
        if isinstance(signal, InputPedalSpan)
    ]

    _reject_concurrent_lig_texts(lig_signals)

    streams = _voice_streams(document)
    resolved: list[ResolvedLigature] = []
    claimed_members: list[set[tuple[str, int, int]]] = []

    for lig in lig_signals:
        parsed = parse_ligature_text(lig.source_text)
        pedal = _match_pedal(lig, pedals)
        members = _inclusive_members(streams, lig.anchor, pedal.end, lig)
        forms = expand_ligature_forms(parsed, len(members))
        member_keys = {
            (address.voice_identity, address.measure_n, address.ordinal)
            for address in members
        }
        for claimed in claimed_members:
            overlap = member_keys & claimed
            if overlap:
                raise LigatureResolutionError(
                    f"overlapping ligatures for staff text "
                    f"xml:id={lig.source_xml_id!r}"
                )
        claimed_members.append(member_keys)

        resolved.append(
            ResolvedLigature(
                staff_text_xml_id=lig.source_xml_id,
                pedal_xml_id=pedal.source_xml_id,
                voice_identity=lig.anchor.voice_identity,
                start=lig.anchor,
                end=pedal.end,
                member_addresses=members,
                effective_forms=forms,
                source_text=lig.source_text,
                form_changes=parsed.changes,
            )
        )

    return tuple(resolved)


def _parse_form(raw: str, source_text: str) -> str:
    if raw not in ALLOWED_FORMS:
        raise LigatureSyntaxError(
            f"unknown or invalid ligature form {raw!r} in {source_text!r}"
        )
    return raw


def _parse_position(raw: str, source_text: str) -> int:
    if raw == "":
        raise LigatureSyntaxError(
            f"missing position in ligature text {source_text!r}"
        )
    if not _POSITION_RE.fullmatch(raw):
        # Distinguish non-numeric vs non-positive when possible.
        if raw.isdigit() or (raw.startswith("-") and raw[1:].isdigit()):
            raise LigatureSyntaxError(
                f"ligature position must be a positive integer, got {raw!r} "
                f"in {source_text!r}"
            )
        raise LigatureSyntaxError(
            f"ligature position must be numeric, got {raw!r} in {source_text!r}"
        )
    return int(raw)


def _reject_concurrent_lig_texts(
    lig_signals: list[InputStaffTextSignal],
) -> None:
    seen: dict[tuple[str, int, int], str] = {}
    for lig in lig_signals:
        key = (
            lig.anchor.voice_identity,
            lig.anchor.measure_n,
            lig.anchor.ordinal,
        )
        previous = seen.get(key)
        if previous is not None:
            raise LigatureResolutionError(
                f"concurrent lig: staff texts at the same start "
                f"(xml:id={previous!r} and xml:id={lig.source_xml_id!r})"
            )
        seen[key] = lig.source_xml_id


def _match_pedal(
    lig: InputStaffTextSignal, pedals: list[InputPedalSpan]
) -> InputPedalSpan:
    matches = [
        pedal
        for pedal in pedals
        if pedal.start == lig.anchor
    ]
    if not matches:
        raise LigatureResolutionError(
            f"ligature staff text xml:id={lig.source_xml_id!r} has no matching pedal"
        )
    if len(matches) > 1:
        ids = ", ".join(repr(pedal.source_xml_id) for pedal in matches)
        raise LigatureResolutionError(
            f"ligature staff text xml:id={lig.source_xml_id!r} matches multiple "
            f"pedals: {ids}"
        )
    pedal = matches[0]
    if lig.carrier_measure_n != pedal.carrier_measure_n:
        raise LigatureResolutionError(
            f"carrier measure mismatch for ligature xml:id={lig.source_xml_id!r} "
            f"and pedal xml:id={pedal.source_xml_id!r}"
        )
    if lig.anchor.voice_identity != pedal.end.voice_identity:
        raise LigatureResolutionError(
            f"pedal endpoints must stay in one voice for "
            f"xml:id={pedal.source_xml_id!r}"
        )
    return pedal


def _event_kind(event: MusicalEvent) -> str:
    if isinstance(event, InputNote):
        return "note"
    if isinstance(event, InputRest):
        return "rest"
    if isinstance(event, InputMeasureRest):
        return "mRest"
    raise LigatureResolutionError(f"unsupported event type {type(event)!r}")


def _voice_streams(
    document: InputDocument,
) -> dict[str, list[InputEventAddress]]:
    streams: dict[str, list[InputEventAddress]] = {}
    for measure in document.measures:
        for content in measure.voices:
            bucket = streams.setdefault(content.voice_identity, [])
            for event in content.events:
                if not is_rhythmic_event(event):
                    continue
                bucket.append(
                    InputEventAddress(
                        voice_identity=content.voice_identity,
                        measure_n=content.measure_n,
                        ordinal=event.ordinal,
                        event_kind=_event_kind(event),
                    )
                )
    return streams


def _address_key(address: InputEventAddress) -> tuple[str, int, int]:
    return (address.voice_identity, address.measure_n, address.ordinal)


def _inclusive_members(
    streams: dict[str, list[InputEventAddress]],
    start: InputEventAddress,
    end: InputEventAddress,
    lig: InputStaffTextSignal,
) -> tuple[InputEventAddress, ...]:
    voice = start.voice_identity
    if voice != end.voice_identity:
        raise LigatureResolutionError(
            f"ligature endpoints must belong to the same voice for "
            f"staff text xml:id={lig.source_xml_id!r}"
        )
    stream = streams.get(voice)
    if not stream:
        raise LigatureResolutionError(
            f"no events for voice {voice!r} while resolving "
            f"staff text xml:id={lig.source_xml_id!r}"
        )

    index = {_address_key(address): i for i, address in enumerate(stream)}
    start_key = _address_key(start)
    end_key = _address_key(end)
    if start_key not in index:
        raise LigatureResolutionError(
            f"missing start address for staff text xml:id={lig.source_xml_id!r}"
        )
    if end_key not in index:
        raise LigatureResolutionError(
            f"missing end address for staff text xml:id={lig.source_xml_id!r}"
        )

    i0 = index[start_key]
    i1 = index[end_key]
    if i1 < i0:
        raise LigatureResolutionError(
            f"ligature end precedes start for staff text "
            f"xml:id={lig.source_xml_id!r}"
        )

    members = tuple(stream[i0 : i1 + 1])
    if len(members) < 2:
        raise LigatureResolutionError(
            f"ligature must contain at least two notes for staff text "
            f"xml:id={lig.source_xml_id!r}"
        )
    for address in members:
        if address.event_kind != "note":
            raise LigatureResolutionError(
                f"ligature interval must contain only notes for staff text "
                f"xml:id={lig.source_xml_id!r} "
                f"(found {address.event_kind!r} at measure {address.measure_n} "
                f"ordinal {address.ordinal})"
            )
    return members
