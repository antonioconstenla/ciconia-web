"""Analyse des conventions transcripteur structurées (J7.1).

Produit des objets métier typés sans transformation musicale ni écriture MEI.
Conserve le texte source brut comme provenance.
"""

from __future__ import annotations

import re

from mei_scribe.io.errors import ConventionSyntaxError
from mei_scribe.model.document import (
    ClefGroupDirective,
    CustosDirective,
    InputClef,
    InputEventAddress,
    InputStaffTextSignal,
    NoteGraphyDirective,
    NoteStemDirective,
    ReadingDiagnostic,
    RestDurationDirective,
    StructuredDirective,
    SystemStartDirective,
)
from mei_scribe.signals.anchored_text import (
    parse_anchored_text,
    validate_anchored_text_alternatives,
    validate_lyric_blocks,
)
from mei_scribe.signals.editorial import (
    parse_damage,
    parse_gap,
    parse_supplied,
    parse_unclear,
    validate_editorial_composition,
)
from mei_scribe.signals.dot import parse_dot
from mei_scribe.signals.graphic_line import parse_graphic_line
from mei_scribe.signals.space import parse_space, validate_space_composition

REST_DUR_PREFIX = "rest:dur="
NOTE_STEM_PREFIX = "note:"
CLEFGRP_PREFIX = "clefGrp:"
ANCHORED_TEXT_PREFIX = "anchoredText:"
CUSTOS_TEXT = "custos"
SYSTEM_START_TEXT = "system:start"

KNOWN_DIR_PREFIXES: frozenset[str] = frozenset(
    {
        "lig",
        "ligature",
        "rest",
        "note",
        "clefGrp",
        "anchoredText",
        "unclear",
        "supplied",
        "damage",
        "gap",
        "space",
        "dot",
        "graphicLine",
    }
)

_CLEF_RE = re.compile(
    r"^clef\(shape=([A-Za-z]+),line=([1-9][0-9]*)\)$"
)
_STEM_KEY_RE = re.compile(r"^(stem\.dir|stem\.pos|stem\.form)=(.+)$")
_REST_VALUE_RE = re.compile(r"^[1-9][0-9]*B$")


def parse_structured_directives(
    signals: tuple[InputStaffTextSignal, ...] | list[InputStaffTextSignal],
) -> tuple[tuple[StructuredDirective, ...], tuple[ReadingDiagnostic, ...]]:
    """Analyse les Staff Texts structurés reconnus ; diagnostique le reste."""
    directives: list[StructuredDirective] = []
    diagnostics: list[ReadingDiagnostic] = []

    for signal in signals:
        text = signal.source_text
        anchor = signal.anchor
        if text == CUSTOS_TEXT:
            directives.append(
                CustosDirective(
                    anchor=anchor,
                    source_text=text,
                    source_xml_id=signal.source_xml_id,
                )
            )
            continue

        if text == SYSTEM_START_TEXT:
            directives.append(
                SystemStartDirective(
                    anchor=anchor,
                    source_text=text,
                    source_xml_id=signal.source_xml_id,
                )
            )
            continue

        prefix = signal.lexical_prefix
        if prefix is None:
            diagnostics.append(
                _diagnostic(
                    "unstructured-staff-text",
                    "staff text without structured prefix",
                    signal,
                )
            )
            continue

        if prefix == "rest":
            directives.append(_parse_rest_dur(signal))
        elif prefix == "note":
            directives.append(_parse_note_directive(signal))
        elif prefix == "clefGrp":
            directives.append(_parse_clef_group(signal))
        elif prefix == "anchoredText":
            directives.append(parse_anchored_text(signal))
        elif prefix == "unclear":
            directives.append(parse_unclear(signal))
        elif prefix == "supplied":
            directives.append(parse_supplied(signal))
        elif prefix == "damage":
            directives.append(parse_damage(signal))
        elif prefix == "gap":
            # Historical non-kv leftovers such as flour ``gap:abandoned``
            # remain unknown-structured-directive so closed read tests stay
            # readable. Key=value payloads are V1 and fail closed.
            if "=" not in signal.source_text:
                diagnostics.append(
                    _diagnostic(
                        "unknown-structured-directive",
                        f"unknown structured directive prefix {prefix!r}",
                        signal,
                    )
                )
            else:
                directives.append(parse_gap(signal))
        elif prefix == "space":
            directives.append(parse_space(signal))
        elif prefix == "dot":
            directives.append(parse_dot(signal))
        elif prefix == "graphicLine":
            directives.append(parse_graphic_line(signal))
        elif prefix in {"lig", "ligature"}:
            # Ligature semantics remain owned by signals.ligatures.
            continue
        else:
            diagnostics.append(
                _diagnostic(
                    "unknown-structured-directive",
                    f"unknown structured directive prefix {prefix!r}",
                    signal,
                )
            )

    validate_editorial_composition(directives)
    validate_lyric_blocks(directives)
    validate_anchored_text_alternatives(directives)
    validate_space_composition(directives)
    return tuple(directives), tuple(diagnostics)


def _diagnostic(
    code: str, message: str, signal: InputStaffTextSignal
) -> ReadingDiagnostic:
    return ReadingDiagnostic(
        code=code,
        message=message,
        source_text=signal.source_text,
        voice_identity=signal.anchor.voice_identity,
        measure_n=signal.anchor.measure_n,
        ordinal=signal.anchor.ordinal,
        source_xml_id=signal.source_xml_id,
    )


def _parse_rest_dur(signal: InputStaffTextSignal) -> RestDurationDirective:
    raw = signal.source_text
    if not raw.startswith(REST_DUR_PREFIX):
        raise ConventionSyntaxError(
            _ctx(signal, f"expected {REST_DUR_PREFIX!r}, got {raw!r}")
        )
    payload = raw[len(REST_DUR_PREFIX) :]
    if payload == "" or payload.endswith(",") or ",," in payload:
        raise ConventionSyntaxError(
            _ctx(signal, f"invalid rest:dur payload in {raw!r}")
        )
    values = tuple(payload.split(","))
    if any(value == "" for value in values):
        raise ConventionSyntaxError(
            _ctx(signal, f"empty rest:dur value in {raw!r}")
        )
    for value in values:
        if not _REST_VALUE_RE.fullmatch(value):
            raise ConventionSyntaxError(
                _ctx(signal, f"invalid rest:dur value {value!r} in {raw!r}")
            )
    return RestDurationDirective(
        values=values,
        anchor=signal.anchor,
        source_text=raw,
        source_xml_id=signal.source_xml_id,
    )


def _parse_note_directive(
    signal: InputStaffTextSignal,
) -> NoteStemDirective | NoteGraphyDirective:
    raw = signal.source_text
    if not raw.startswith(NOTE_STEM_PREFIX):
        raise ConventionSyntaxError(
            _ctx(signal, f"expected {NOTE_STEM_PREFIX!r}, got {raw!r}")
        )
    payload = raw[len(NOTE_STEM_PREFIX) :]
    if payload.startswith("graphy="):
        return _parse_note_graphy(signal, payload)
    return _parse_note_stem(signal, payload)


def _parse_note_graphy(
    signal: InputStaffTextSignal, payload: str
) -> NoteGraphyDirective:
    raw = signal.source_text
    if payload == "" or " " in payload:
        raise ConventionSyntaxError(
            _ctx(signal, f"invalid note:graphy payload in {raw!r}")
        )
    parts = payload.split(",")
    if any(part == "" for part in parts):
        raise ConventionSyntaxError(
            _ctx(signal, f"empty note:graphy attribute in {raw!r}")
        )
    if len(parts) != 1:
        raise ConventionSyntaxError(
            _ctx(signal, f"note:graphy must be a single key=value in {raw!r}")
        )
    key, sep, value = parts[0].partition("=")
    if sep != "=" or key != "graphy":
        raise ConventionSyntaxError(
            _ctx(signal, f"invalid note:graphy attribute {parts[0]!r} in {raw!r}")
        )
    if value == "" or "=" in value:
        raise ConventionSyntaxError(
            _ctx(signal, f"invalid note:graphy value in {raw!r}")
        )
    return NoteGraphyDirective(
        graphy=value,
        anchor=signal.anchor,
        source_text=raw,
        source_xml_id=signal.source_xml_id,
    )


def _parse_note_stem(
    signal: InputStaffTextSignal, payload: str | None = None
) -> NoteStemDirective:
    raw = signal.source_text
    if not raw.startswith(NOTE_STEM_PREFIX):
        raise ConventionSyntaxError(
            _ctx(signal, f"expected {NOTE_STEM_PREFIX!r}, got {raw!r}")
        )
    if payload is None:
        payload = raw[len(NOTE_STEM_PREFIX) :]
    if payload == "" or " " in payload:
        raise ConventionSyntaxError(
            _ctx(signal, f"invalid note:stem payload in {raw!r}")
        )
    stem_dir: str | None = None
    stem_pos: str | None = None
    stem_form: str | None = None
    seen: set[str] = set()
    for part in payload.split(","):
        match = _STEM_KEY_RE.fullmatch(part)
        if match is None:
            raise ConventionSyntaxError(
                _ctx(signal, f"invalid note:stem attribute {part!r} in {raw!r}")
            )
        key, value = match.group(1), match.group(2)
        if key in seen:
            raise ConventionSyntaxError(
                _ctx(signal, f"duplicate note:stem key {key!r} in {raw!r}")
            )
        if value == "":
            raise ConventionSyntaxError(
                _ctx(signal, f"empty note:stem value for {key!r} in {raw!r}")
            )
        seen.add(key)
        if key == "stem.dir":
            stem_dir = value
        elif key == "stem.pos":
            stem_pos = value
        else:
            stem_form = value
    if not seen:
        raise ConventionSyntaxError(
            _ctx(signal, f"note:stem directive has no attributes in {raw!r}")
        )
    return NoteStemDirective(
        stem_dir=stem_dir,
        stem_pos=stem_pos,
        stem_form=stem_form,
        anchor=signal.anchor,
        source_text=raw,
        source_xml_id=signal.source_xml_id,
    )


def _parse_clef_group(signal: InputStaffTextSignal) -> ClefGroupDirective:
    raw = signal.source_text
    if not raw.startswith(CLEFGRP_PREFIX):
        raise ConventionSyntaxError(
            _ctx(signal, f"expected {CLEFGRP_PREFIX!r}, got {raw!r}")
        )
    payload = raw[len(CLEFGRP_PREFIX) :]
    if payload == "" or " " in payload:
        raise ConventionSyntaxError(
            _ctx(signal, f"invalid clefGrp payload in {raw!r}")
        )
    parts = payload.split(";")
    if any(part == "" for part in parts):
        raise ConventionSyntaxError(
            _ctx(signal, f"empty clef segment in {raw!r}")
        )
    clefs: list[InputClef] = []
    for part in parts:
        match = _CLEF_RE.fullmatch(part)
        if match is None:
            raise ConventionSyntaxError(
                _ctx(signal, f"invalid clef segment {part!r} in {raw!r}")
            )
        clefs.append(InputClef(shape=match.group(1), line=int(match.group(2))))
    return ClefGroupDirective(
        clefs=tuple(clefs),
        anchor=signal.anchor,
        source_text=raw,
        source_xml_id=signal.source_xml_id,
    )


def _ctx(signal: InputStaffTextSignal, message: str) -> str:
    anchor: InputEventAddress = signal.anchor
    return (
        f"voice={anchor.voice_identity!r} measure={anchor.measure_n} "
        f"ordinal={anchor.ordinal} xml:id={signal.source_xml_id!r}: {message}"
    )
