"""Détection et interprétation des signaux/annotations de transcription."""

from mei_scribe.signals.conventions import parse_structured_directives
from mei_scribe.signals.ligatures import (
    expand_ligature_forms,
    parse_ligature_text,
    resolve_ligatures,
)
from mei_scribe.signals.parser import ParsedStaffText, parse_staff_text

__all__ = [
    "ParsedStaffText",
    "expand_ligature_forms",
    "parse_ligature_text",
    "parse_staff_text",
    "parse_structured_directives",
    "resolve_ligatures",
]
