"""Grammaire GRAPHIC_LINE_SEPARATOR_V1 (graphicLine:func=separator)."""

from __future__ import annotations

import re

from mei_scribe.io.errors import ConventionSyntaxError
from mei_scribe.model.document import GraphicLineDirective, InputStaffTextSignal

GRAPHIC_LINE_PREFIX = "graphicLine:"
SUPPORTED_FUNC = "separator"
SUPPORTED_COLOR = "red"
_ALLOWED_KEYS = frozenset({"func", "block", "line", "part", "color"})
_BLOCK_RE = re.compile(r"^[A-Za-z][A-Za-z0-9-]*$")
_POSINT_RE = re.compile(r"^[1-9][0-9]*$")


def parse_graphic_line(signal: InputStaffTextSignal) -> GraphicLineDirective:
    raw = signal.source_text
    if not raw.startswith(GRAPHIC_LINE_PREFIX):
        raise ConventionSyntaxError(
            _ctx(signal, f"expected {GRAPHIC_LINE_PREFIX!r}, got {raw!r}")
        )
    values = _parse_kv_payload(signal, raw[len(GRAPHIC_LINE_PREFIX) :])
    for key in ("func", "block", "line", "part", "color"):
        if key not in values:
            raise ConventionSyntaxError(
                _ctx(signal, f"graphicLine missing required {key}=")
            )

    func = values["func"]
    if func != SUPPORTED_FUNC:
        raise ConventionSyntaxError(
            _ctx(
                signal,
                f"unsupported graphicLine func {func!r}; "
                f"V1 allows only {SUPPORTED_FUNC!r}",
            )
        )

    block = values["block"]
    if not _BLOCK_RE.fullmatch(block):
        raise ConventionSyntaxError(
            _ctx(
                signal,
                f"invalid graphicLine block {block!r}; "
                "expected [A-Za-z][A-Za-z0-9-]*",
            )
        )

    line_raw = values["line"]
    if not _POSINT_RE.fullmatch(line_raw):
        raise ConventionSyntaxError(
            _ctx(
                signal,
                f"invalid graphicLine line {line_raw!r}; "
                "expected positive integer [1-9][0-9]*",
            )
        )
    part_raw = values["part"]
    if not _POSINT_RE.fullmatch(part_raw):
        raise ConventionSyntaxError(
            _ctx(
                signal,
                f"invalid graphicLine part {part_raw!r}; "
                "expected positive integer [1-9][0-9]*",
            )
        )

    color = values["color"]
    if color != SUPPORTED_COLOR:
        raise ConventionSyntaxError(
            _ctx(
                signal,
                f"unsupported graphicLine color {color!r}; "
                f"V1 allows only {SUPPORTED_COLOR!r}",
            )
        )

    kind = signal.anchor.event_kind
    if kind != "note":
        raise ConventionSyntaxError(
            _ctx(
                signal,
                f"graphicLine must be anchored on a note, got {kind!r}",
            )
        )

    return GraphicLineDirective(
        func=func,
        block=block,
        line=int(line_raw),
        part=int(part_raw),
        color=color,
        anchor=signal.anchor,
        source_text=raw,
        source_xml_id=signal.source_xml_id,
    )


def _parse_kv_payload(
    signal: InputStaffTextSignal, payload: str
) -> dict[str, str]:
    raw = signal.source_text
    if payload == "" or " " in payload:
        raise ConventionSyntaxError(
            _ctx(signal, f"invalid graphicLine payload in {raw!r}")
        )
    values: dict[str, str] = {}
    for part in payload.split(","):
        if part == "" or "=" not in part:
            raise ConventionSyntaxError(
                _ctx(signal, f"invalid graphicLine attribute {part!r} in {raw!r}")
            )
        key, sep, value = part.partition("=")
        if sep != "=" or key == "" or value == "" or "=" in value:
            raise ConventionSyntaxError(
                _ctx(signal, f"invalid graphicLine attribute {part!r} in {raw!r}")
            )
        if key in values:
            raise ConventionSyntaxError(
                _ctx(signal, f"duplicate graphicLine key {key!r} in {raw!r}")
            )
        if key not in _ALLOWED_KEYS:
            raise ConventionSyntaxError(
                _ctx(signal, f"unknown graphicLine key {key!r} in {raw!r}")
            )
        values[key] = value
    return values


def _ctx(signal: InputStaffTextSignal, message: str) -> str:
    anchor = signal.anchor
    return (
        f"voice={anchor.voice_identity!r} measure={anchor.measure_n} "
        f"ordinal={anchor.ordinal} xml:id={signal.source_xml_id!r}: {message}"
    )
