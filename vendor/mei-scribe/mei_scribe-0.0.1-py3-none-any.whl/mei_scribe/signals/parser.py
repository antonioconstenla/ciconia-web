"""Analyse lexicale des Staff Texts (indépendante du XML).

J5 : identification d'un préfixe lexical éventuel et conservation du texte
source opaque. Aucune charge structurée n'est interprétée.
"""

from __future__ import annotations

from dataclasses import dataclass

from mei_scribe.io.errors import SourceSignalsError


@dataclass(frozen=True)
class ParsedStaffText:
    """Résultat lexical d'un Staff Text source."""

    source_text: str
    lexical_prefix: str | None
    remainder: str


def parse_staff_text(raw: str) -> ParsedStaffText:
    """Analyse un Staff Text déjà extrait du XML.

    - préserve ``source_text`` sans normalisation ;
    - si un ``:`` est présent, le préfixe est la partie avant le premier ``:`` ;
    - un texte sans ``:`` a ``lexical_prefix=None`` et ``remainder=source_text`` ;
    - un préfixe inconnu reste représentable ;
    - un texte vide ou uniquement composé d'espaces est rejeté.
    """
    if not isinstance(raw, str) or raw.strip() == "":
        raise SourceSignalsError("staff text must be non-empty")

    if ":" not in raw:
        return ParsedStaffText(
            source_text=raw,
            lexical_prefix=None,
            remainder=raw,
        )

    prefix, remainder = raw.split(":", 1)
    return ParsedStaffText(
        source_text=raw,
        lexical_prefix=prefix,
        remainder=remainder,
    )
