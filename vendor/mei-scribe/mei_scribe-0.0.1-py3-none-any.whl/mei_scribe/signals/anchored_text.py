"""Grammaire ANCHORED_TEXT_EDITORIAL_V1 (lyricFragment / lyricBlock / DSL)."""

from __future__ import annotations

import re
from collections import defaultdict

from mei_scribe.io.errors import ConventionSyntaxError
from mei_scribe.model.document import (
    AnchoredTextAbbr,
    AnchoredTextDamage,
    AnchoredTextDirective,
    AnchoredTextGap,
    AnchoredTextPart,
    AnchoredTextPlain,
    AnchoredTextSupplied,
    AnchoredTextUnclear,
    InputEventAddress,
    InputStaffTextSignal,
    StructuredDirective,
)
from mei_scribe.signals.editorial import CERT_VALUES, EVIDENCE_VALUES

ANCHORED_TEXT_PREFIX = "anchoredText:"
LYRIC_FRAGMENT = "lyricFragment"
LYRIC_BLOCK = "lyricBlock"
EDITORIAL_WRAPPERS = frozenset({"unclear", "supplied"})
EDITORIAL_ALTERNATIVE = "alternative"
ALTERNATIVE_EVIDENCE = "internal"
_ALTERNATIVE_FORBIDDEN_ATTRS = frozenset({"reason", "agent", "cert", "source"})

_FRAGMENT_KEYS = frozenset(
    {
        "func",
        "editorial",
        "reason",
        "agent",
        "evidence",
        "cert",
        "source",
        "verse",
        "form",
        "expan",
    }
)
_BLOCK_KEYS = frozenset({"func", "block", "line", "part"})
_J81_KEYS = frozenset({"func"})
_WRAPPER_ATTR_KEYS = frozenset({"reason", "agent", "evidence", "cert", "source"})

_ABBR_KEYS = frozenset({"expan"})
_UNCLEAR_KEYS = frozenset({"reason", "agent", "evidence", "cert", "source"})
_GAP_KEYS = frozenset({"reason", "extent", "unit"})
_DAMAGE_KEYS = frozenset({"agent", "extent", "unit", "atleast", "atmost"})

_BLOCK_RE = re.compile(r"^[A-Za-z][A-Za-z0-9-]*$")
_POSINT_RE = re.compile(r"^[1-9][0-9]*$")
_KEY_RE = re.compile(r"^[A-Za-z][A-Za-z0-9]*$")
_DECIMAL_RE = re.compile(r"^[0-9]+(\.[0-9]+)?$")
_DSL_TYPES = frozenset({"abbr", "unclear", "supplied", "gap", "damage"})


def parse_anchored_text(signal: InputStaffTextSignal) -> AnchoredTextDirective:
    raw = signal.source_text
    if not raw.startswith(ANCHORED_TEXT_PREFIX):
        raise ConventionSyntaxError(
            _ctx(signal, f"expected {ANCHORED_TEXT_PREFIX!r}, got {raw!r}")
        )
    payload = raw[len(ANCHORED_TEXT_PREFIX) :]
    if "|" not in payload:
        raise ConventionSyntaxError(
            _ctx(signal, f"anchoredText missing '|' separator in {raw!r}")
        )
    props, text = payload.split("|", 1)
    values = _parse_top_level_props(signal, props)
    func = values["func"]

    n: str | None = None
    block: str | None = None
    line: int | None = None
    part: int | None = None
    parts: tuple[AnchoredTextPart, ...] = ()
    verse_n: int | None = None
    editorial: str | None = None
    evidence: str | None = None

    if func == LYRIC_FRAGMENT:
        parts, editorial, evidence = _parse_lyric_fragment(signal, values, text)
        verse_n = _optional_fragment_verse(signal, values)
    elif func == LYRIC_BLOCK:
        block, line, part, n = _parse_lyric_block_keys(signal, values)
        parts = _parse_mixed_content(signal, text)
    elif set(values) != _J81_KEYS:
        raise ConventionSyntaxError(
            _ctx(signal, f"invalid anchoredText func in {raw!r}")
        )
    elif "[[" in text:
        parts = _parse_mixed_content(signal, text)

    return AnchoredTextDirective(
        func=func,
        text=text,
        anchor=signal.anchor,
        source_text=raw,
        source_xml_id=signal.source_xml_id,
        n=n,
        block=block,
        line=line,
        part=part,
        parts=parts,
        verse_n=verse_n,
        editorial=editorial,
        evidence=evidence,
    )


def validate_lyric_blocks(
    directives: tuple[StructuredDirective, ...] | list[StructuredDirective],
) -> None:
    """Reject duplicate identities and split-anchor lyricBlock groups."""
    grouped: dict[str, list[AnchoredTextDirective]] = defaultdict(list)
    for directive in directives:
        if not isinstance(directive, AnchoredTextDirective):
            continue
        if directive.func != LYRIC_BLOCK or directive.block is None:
            continue
        grouped[directive.block].append(directive)

    for block, members in grouped.items():
        anchors = {member.anchor for member in members}
        if len(anchors) > 1:
            sample = members[0]
            raise ConventionSyntaxError(
                _anchor_ctx(
                    sample.anchor,
                    sample.source_xml_id,
                    f"lyricBlock {block!r} members must share one source "
                    f"anchor; got {len(anchors)} distinct addresses",
                )
            )
        seen: dict[tuple[str, int, int], AnchoredTextDirective] = {}
        for member in members:
            identity = (block, member.line or 0, member.part or 1)
            previous = seen.get(identity)
            if previous is not None:
                raise ConventionSyntaxError(
                    _anchor_ctx(
                        member.anchor,
                        member.source_xml_id,
                        f"duplicate lyricBlock identity "
                        f"(block={block!r}, line={identity[1]}, "
                        f"part={identity[2]}) in {member.source_text!r}",
                    )
                )
            seen[identity] = member


def validate_anchored_text_alternatives(
    directives: tuple[StructuredDirective, ...] | list[StructuredDirective],
) -> None:
    """Validate unordered editorial=alternative sets on shared anchors.

    V1: two or more compatible lyricFragment alternatives on the same source
    anchor form one unordered set. A singleton (including legacy ``|vr;br``)
    fails closed. At most one set per anchor is supported because grouping
    uses the anchor alone.
    """
    grouped: dict[InputEventAddress, list[AnchoredTextDirective]] = defaultdict(
        list
    )
    for directive in directives:
        if not isinstance(directive, AnchoredTextDirective):
            continue
        if directive.editorial != EDITORIAL_ALTERNATIVE:
            continue
        grouped[directive.anchor].append(directive)

    for members in grouped.values():
        sample = members[0]
        if len(members) < 2:
            raise ConventionSyntaxError(
                _anchor_ctx(
                    sample.anchor,
                    sample.source_xml_id,
                    "lyricFragment editorial=alternative requires at least "
                    "two readings on the same source anchor "
                    f"(got {len(members)}); legacy multi-reading payloads "
                    "are not split",
                )
            )
        funcs = {member.func for member in members}
        if funcs != {LYRIC_FRAGMENT}:
            raise ConventionSyntaxError(
                _anchor_ctx(
                    sample.anchor,
                    sample.source_xml_id,
                    "lyricFragment editorial=alternative members must share "
                    f"func={LYRIC_FRAGMENT!r}",
                )
            )
        verses = {member.verse_n for member in members}
        if len(verses) != 1:
            raise ConventionSyntaxError(
                _anchor_ctx(
                    sample.anchor,
                    sample.source_xml_id,
                    "lyricFragment editorial=alternative members must share "
                    "the same verse= (or all omit verse=)",
                )
            )
        evidences = {member.evidence for member in members}
        if evidences != {ALTERNATIVE_EVIDENCE}:
            raise ConventionSyntaxError(
                _anchor_ctx(
                    sample.anchor,
                    sample.source_xml_id,
                    "lyricFragment editorial=alternative members must share "
                    f"evidence={ALTERNATIVE_EVIDENCE!r}",
                )
            )
        texts = [member.text for member in members]
        if any(text == "" for text in texts):
            raise ConventionSyntaxError(
                _anchor_ctx(
                    sample.anchor,
                    sample.source_xml_id,
                    "lyricFragment editorial=alternative payload must be "
                    "non-empty",
                )
            )
        if len(set(texts)) != len(texts):
            raise ConventionSyntaxError(
                _anchor_ctx(
                    sample.anchor,
                    sample.source_xml_id,
                    "lyricFragment editorial=alternative rejects duplicate "
                    "readings on the same anchor",
                )
            )


def order_anchored_text_directives(
    directives: tuple[AnchoredTextDirective, ...],
) -> tuple[AnchoredTextDirective, ...]:
    """Order lyricBlock members by line, part, then source index."""
    by_block: dict[str, list[tuple[int, AnchoredTextDirective]]] = defaultdict(list)
    for index, directive in enumerate(directives):
        if directive.func == LYRIC_BLOCK and directive.block is not None:
            by_block[directive.block].append((index, directive))

    emitted: set[str] = set()
    ordered: list[AnchoredTextDirective] = []
    for index, directive in enumerate(directives):
        if directive.func == LYRIC_BLOCK and directive.block is not None:
            if directive.block in emitted:
                continue
            emitted.add(directive.block)
            members = sorted(
                by_block[directive.block],
                key=lambda item: (
                    item[1].line or 0,
                    item[1].part or 1,
                    item[0],
                ),
            )
            ordered.extend(member for _, member in members)
            continue
        ordered.append(directive)
    return tuple(ordered)


def iter_source_tokens(
    directive: AnchoredTextDirective,
) -> tuple[tuple[str, AnchoredTextPart], ...]:
    found: list[tuple[str, AnchoredTextPart]] = []
    for part in directive.parts:
        token = getattr(part, "source_token", None)
        if token:
            found.append((token, part))
    return tuple(found)


def _parse_top_level_props(
    signal: InputStaffTextSignal, props: str
) -> dict[str, str]:
    raw = signal.source_text
    if not props.startswith("func=") or props == "func=":
        raise ConventionSyntaxError(
            _ctx(signal, f"anchoredText missing func= in {raw!r}")
        )
    if " " in props:
        raise ConventionSyntaxError(
            _ctx(signal, f"invalid anchoredText properties in {raw!r}")
        )
    values: dict[str, str] = {}
    for part in props.split(","):
        if part == "" or "=" not in part:
            raise ConventionSyntaxError(
                _ctx(signal, f"invalid anchoredText attribute {part!r} in {raw!r}")
            )
        key, sep, value = part.partition("=")
        if sep != "=" or key == "" or value == "" or "=" in value:
            raise ConventionSyntaxError(
                _ctx(signal, f"invalid anchoredText attribute {part!r} in {raw!r}")
            )
        if key in values:
            raise ConventionSyntaxError(
                _ctx(signal, f"duplicate anchoredText key {key!r} in {raw!r}")
            )
        values[key] = value
    func = values["func"]
    if func == "":
        raise ConventionSyntaxError(
            _ctx(signal, f"invalid anchoredText func in {raw!r}")
        )
    if func == LYRIC_FRAGMENT:
        unknown = set(values) - _FRAGMENT_KEYS
    elif func == LYRIC_BLOCK:
        unknown = set(values) - _BLOCK_KEYS
    else:
        unknown = set(values) - _J81_KEYS
        if "," in func or "=" in func:
            unknown.add("func")
    if unknown:
        raise ConventionSyntaxError(
            _ctx(signal, f"invalid anchoredText func in {raw!r}")
        )
    return values


def _optional_fragment_verse(
    signal: InputStaffTextSignal, values: dict[str, str]
) -> int | None:
    value = values.get("verse")
    if value is None:
        return None
    if not _POSINT_RE.fullmatch(value):
        raise ConventionSyntaxError(
            _ctx(signal, f"invalid lyricFragment verse {value!r}")
        )
    return int(value)


def _parse_lyric_fragment(
    signal: InputStaffTextSignal,
    values: dict[str, str],
    text: str,
) -> tuple[tuple[AnchoredTextPart, ...], str | None, str | None]:
    editorial = values.get("editorial")
    wrapper_present = any(key in values for key in _WRAPPER_ATTR_KEYS)
    form_parts = _parse_fragment_abbreviation(signal, values, text, editorial)
    if form_parts is not None:
        return form_parts, None, None
    if editorial is None:
        if wrapper_present:
            raise ConventionSyntaxError(
                _ctx(
                    signal,
                    "lyricFragment editorial attributes require editorial=",
                )
            )
        if "[[" in text:
            return _parse_mixed_content(signal, text), None, None
        return (), None, None
    if editorial == EDITORIAL_ALTERNATIVE:
        return (), EDITORIAL_ALTERNATIVE, _parse_alternative_member(
            signal, values, text
        )
    if editorial not in EDITORIAL_WRAPPERS:
        raise ConventionSyntaxError(
            _ctx(
                signal,
                f"unsupported lyricFragment editorial={editorial!r}; "
                f"allowed {sorted(EDITORIAL_WRAPPERS | {EDITORIAL_ALTERNATIVE})}",
            )
        )
    if "[[" in text:
        raise ConventionSyntaxError(
            _ctx(
                signal,
                "lyricFragment editorial= wrapper cannot contain inline [[...]]",
            )
        )
    attrs = _wrapper_attrs(signal, values)
    if editorial == "unclear":
        return (AnchoredTextUnclear(text=text, **attrs),), None, None
    return (AnchoredTextSupplied(text=text, **attrs),), None, None


def _parse_alternative_member(
    signal: InputStaffTextSignal,
    values: dict[str, str],
    text: str,
) -> str:
    forbidden = sorted(
        key for key in _ALTERNATIVE_FORBIDDEN_ATTRS if key in values
    )
    if forbidden:
        raise ConventionSyntaxError(
            _ctx(
                signal,
                "lyricFragment editorial=alternative does not support "
                f"{', '.join(f'{key}=' for key in forbidden)} in V1",
            )
        )
    evidence = values.get("evidence")
    if evidence is None:
        raise ConventionSyntaxError(
            _ctx(
                signal,
                "lyricFragment editorial=alternative requires "
                f"evidence={ALTERNATIVE_EVIDENCE}",
            )
        )
    if evidence != ALTERNATIVE_EVIDENCE:
        raise ConventionSyntaxError(
            _ctx(
                signal,
                "lyricFragment editorial=alternative only supports "
                f"evidence={ALTERNATIVE_EVIDENCE!r} in V1; got {evidence!r}",
            )
        )
    if "[[" in text:
        raise ConventionSyntaxError(
            _ctx(
                signal,
                "lyricFragment editorial=alternative cannot contain "
                "inline [[...]]",
            )
        )
    if text == "":
        raise ConventionSyntaxError(
            _ctx(
                signal,
                "lyricFragment editorial=alternative payload must be non-empty",
            )
        )
    return evidence


def _parse_fragment_abbreviation(
    signal: InputStaffTextSignal,
    values: dict[str, str],
    text: str,
    editorial: str | None,
) -> tuple[AnchoredTextPart, ...] | None:
    form = values.get("form")
    expan = values.get("expan")
    if expan is not None and form is None:
        raise ConventionSyntaxError(
            _ctx(signal, "lyricFragment expan= requires form=abbr")
        )
    if form is None:
        return None
    if form != "abbr":
        raise ConventionSyntaxError(
            _ctx(signal, f"unsupported lyricFragment form={form!r}")
        )
    if expan is None:
        raise ConventionSyntaxError(
            _ctx(signal, "lyricFragment form=abbr requires expan=")
        )
    if editorial is not None:
        raise ConventionSyntaxError(
            _ctx(signal, "lyricFragment form=abbr cannot combine with editorial=")
        )
    if any(key in values for key in _WRAPPER_ATTR_KEYS):
        raise ConventionSyntaxError(
            _ctx(
                signal,
                "lyricFragment form=abbr cannot combine with editorial attributes",
            )
        )
    if "[[" in text:
        raise ConventionSyntaxError(
            _ctx(
                signal,
                "lyricFragment form=abbr cannot contain inline [[...]]",
            )
        )
    return (AnchoredTextAbbr(expan=expan, text=text),)


def _parse_lyric_block_keys(
    signal: InputStaffTextSignal, values: dict[str, str]
) -> tuple[str, int, int | None, str]:
    block = values.get("block")
    line_raw = values.get("line")
    if block is None:
        raise ConventionSyntaxError(
            _ctx(signal, "lyricBlock missing required block=")
        )
    if line_raw is None:
        raise ConventionSyntaxError(
            _ctx(signal, "lyricBlock missing required line=")
        )
    if not _BLOCK_RE.fullmatch(block):
        raise ConventionSyntaxError(
            _ctx(signal, f"invalid lyricBlock block {block!r}")
        )
    if not _POSINT_RE.fullmatch(line_raw):
        raise ConventionSyntaxError(
            _ctx(signal, f"invalid lyricBlock line {line_raw!r}")
        )
    line = int(line_raw)
    part_raw = values.get("part")
    part: int | None = None
    if part_raw is not None:
        if not _POSINT_RE.fullmatch(part_raw):
            raise ConventionSyntaxError(
                _ctx(signal, f"invalid lyricBlock part {part_raw!r}")
            )
        part = int(part_raw)
        n = f"{block}.{line}.{part}"
    else:
        n = f"{block}.{line}"
    return block, line, part, n


def _parse_mixed_content(
    signal: InputStaffTextSignal, text: str
) -> tuple[AnchoredTextPart, ...]:
    parts: list[AnchoredTextPart] = []
    index = 0
    while index < len(text):
        start = text.find("[[", index)
        if start == -1:
            parts.append(AnchoredTextPlain(text[index:]))
            break
        if start > index:
            parts.append(AnchoredTextPlain(text[index:start]))
        part, end = _parse_construct(signal, text, start)
        parts.append(part)
        index = end
    return tuple(parts)


def _parse_construct(
    signal: InputStaffTextSignal, text: str, start: int
) -> tuple[AnchoredTextPart, int]:
    raw = signal.source_text
    rest = text[start + 2 :]
    colon = rest.find(":")
    if colon == -1:
        raise ConventionSyntaxError(
            _ctx(signal, f"malformed [[ opener in {raw!r}")
        )
    type_name = rest[:colon]
    if type_name not in _DSL_TYPES:
        raise ConventionSyntaxError(
            _ctx(signal, f"unknown [[type:{type_name}]] in {raw!r}")
        )
    body = rest[colon + 1 :]
    close = body.find("]]")
    if close == -1:
        raise ConventionSyntaxError(
            _ctx(signal, f"malformed [[ opener in {raw!r}")
        )
    nested = body.find("[[")
    if nested != -1 and nested < close:
        raise ConventionSyntaxError(
            _ctx(signal, f"nested [[ is not allowed in {raw!r}")
        )
    payload = body[:close]
    end = start + 2 + colon + 1 + close + 2
    if "|" in payload:
        kv_str, content = payload.split("|", 1)
    else:
        kv_str, content = payload, None
    values = _parse_dsl_kv(signal, kv_str, type_name)
    part = _build_dsl_part(signal, type_name, values, content)
    return part, end


def _parse_dsl_kv(
    signal: InputStaffTextSignal, payload: str, kind: str
) -> dict[str, str]:
    raw = signal.source_text
    if payload == "":
        return {}
    if " " in payload:
        raise ConventionSyntaxError(
            _ctx(signal, f"invalid [[{kind}]] attributes in {raw!r}")
        )
    allowed = {
        "abbr": _ABBR_KEYS,
        "unclear": _UNCLEAR_KEYS,
        "supplied": _UNCLEAR_KEYS,
        "gap": _GAP_KEYS,
        "damage": _DAMAGE_KEYS,
    }[kind]
    values: dict[str, str] = {}
    for part in payload.split(","):
        if part == "" or "=" not in part:
            raise ConventionSyntaxError(
                _ctx(signal, f"invalid [[{kind}]] attribute {part!r} in {raw!r}")
            )
        key, sep, value = part.partition("=")
        if sep != "=" or not _KEY_RE.fullmatch(key) or value == "" or "=" in value:
            raise ConventionSyntaxError(
                _ctx(signal, f"invalid [[{kind}]] attribute {part!r} in {raw!r}")
            )
        if any(char in value for char in ",|]"):
            raise ConventionSyntaxError(
                _ctx(signal, f"invalid [[{kind}]] value for {key!r} in {raw!r}")
            )
        if key in values:
            raise ConventionSyntaxError(
                _ctx(signal, f"duplicate [[{kind}]] key {key!r} in {raw!r}")
            )
        if key not in allowed:
            raise ConventionSyntaxError(
                _ctx(signal, f"unknown [[{kind}]] key {key!r} in {raw!r}")
            )
        values[key] = value
    return values


def _build_dsl_part(
    signal: InputStaffTextSignal,
    type_name: str,
    values: dict[str, str],
    content: str | None,
) -> AnchoredTextPart:
    if type_name == "abbr":
        expan = values.get("expan")
        if expan is None:
            raise ConventionSyntaxError(
                _ctx(signal, "[[abbr]] missing required expan=")
            )
        return AnchoredTextAbbr(expan=expan, text=content or "")
    if type_name in {"unclear", "supplied"}:
        if content is None or content == "":
            raise ConventionSyntaxError(
                _ctx(signal, f"[[{type_name}]] requires content")
            )
        attrs = _closed_editorial_attrs(signal, values)
        if type_name == "unclear":
            return AnchoredTextUnclear(text=content, **attrs)
        return AnchoredTextSupplied(text=content, **attrs)
    if content is not None:
        raise ConventionSyntaxError(
            _ctx(signal, f"[[{type_name}]] does not accept content in V1")
        )
    if type_name == "gap":
        return AnchoredTextGap(
            reason=values.get("reason"),
            extent=values.get("extent"),
            unit=values.get("unit"),
        )
    atleast = values.get("atleast")
    atmost = values.get("atmost")
    _validate_bounds(signal, atleast, atmost)
    return AnchoredTextDamage(
        agent=values.get("agent"),
        extent=values.get("extent"),
        unit=values.get("unit"),
        atleast=atleast,
        atmost=atmost,
    )


def _wrapper_attrs(
    signal: InputStaffTextSignal, values: dict[str, str]
) -> dict[str, str | None]:
    return _closed_editorial_attrs(signal, values)


def _closed_editorial_attrs(
    signal: InputStaffTextSignal, values: dict[str, str]
) -> dict[str, str | None]:
    evidence = values.get("evidence")
    if evidence is not None and evidence not in EVIDENCE_VALUES:
        raise ConventionSyntaxError(
            _ctx(
                signal,
                f"invalid evidence {evidence!r}; allowed {sorted(EVIDENCE_VALUES)}",
            )
        )
    cert = values.get("cert")
    if cert is not None and cert not in CERT_VALUES:
        raise ConventionSyntaxError(
            _ctx(signal, f"invalid cert {cert!r}; allowed {sorted(CERT_VALUES)}")
        )
    return {
        "reason": values.get("reason"),
        "agent": values.get("agent"),
        "evidence": evidence,
        "cert": cert,
        "source_token": values.get("source"),
    }


def _validate_bounds(
    signal: InputStaffTextSignal, atleast: str | None, atmost: str | None
) -> None:
    if atleast is not None and not _DECIMAL_RE.fullmatch(atleast):
        raise ConventionSyntaxError(
            _ctx(signal, f"invalid atleast {atleast!r}; expected a decimal number")
        )
    if atmost is not None and not _DECIMAL_RE.fullmatch(atmost):
        raise ConventionSyntaxError(
            _ctx(signal, f"invalid atmost {atmost!r}; expected a decimal number")
        )
    if (
        atleast is not None
        and atmost is not None
        and float(atleast) > float(atmost)
    ):
        raise ConventionSyntaxError(
            _ctx(signal, f"damage atleast={atleast!r} exceeds atmost={atmost!r}")
        )


def _ctx(signal: InputStaffTextSignal, message: str) -> str:
    return _anchor_ctx(signal.anchor, signal.source_xml_id, message)


def _anchor_ctx(anchor: InputEventAddress, source_xml_id: str, message: str) -> str:
    return (
        f"voice={anchor.voice_identity!r} measure={anchor.measure_n} "
        f"ordinal={anchor.ordinal} xml:id={source_xml_id!r}: {message}"
    )
