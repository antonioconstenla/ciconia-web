"""Grammaire StaffText EDITORIAL_UNCERTAINTY_V1 (unclear / supplied / damage)."""

from __future__ import annotations

import re
from collections import defaultdict

from mei_scribe.io.errors import ConventionSyntaxError
from mei_scribe.model.document import (
    DamageDirective,
    GapDirective,
    InputEventAddress,
    InputStaffTextSignal,
    StructuredDirective,
    SuppliedDirective,
    UnclearDirective,
)

UNCLEAR_PREFIX = "unclear:"
SUPPLIED_PREFIX = "supplied:"
DAMAGE_PREFIX = "damage:"
GAP_PREFIX = "gap:"

CERT_VALUES = frozenset({"high", "medium", "low", "unknown"})
EVIDENCE_VALUES = frozenset({"internal", "external", "conjecture"})
UNCLEAR_TARGETS = frozenset(
    {
        "dur",
        "note",
        "lyric",
        "pitch",
        "ligature-membership",
        "ligature-start",
    }
)
SUPPLIED_TARGETS = frozenset({"note", "clef"})
UNSUPPORTED_TARGETS = frozenset({"stem"})
_WHOLE_EVENT_SLOTS = frozenset(
    {("unclear", "note"), ("supplied", "note")}
)
_ASPECT_EVENT_SLOTS = frozenset(
    {
        ("unclear", "dur"),
        ("unclear", "pitch"),
        ("unclear", "ligature-membership"),
        ("unclear", "ligature-start"),
    }
)

_UNCLEAR_BASE_KEYS = frozenset({"target", "reason", "agent", "evidence", "cert", "source"})
_UNCLEAR_LYRIC_ONLY_KEYS = frozenset({"extent", "unit", "verse"})
_UNCLEAR_KEYS = _UNCLEAR_BASE_KEYS | _UNCLEAR_LYRIC_ONLY_KEYS
_SUPPLIED_KEYS = _UNCLEAR_BASE_KEYS
_DAMAGE_KEYS = frozenset({"agent", "extent", "atleast", "atmost", "unit", "scope"})
_GAP_KEYS = frozenset({"reason", "extent", "scope", "unit", "evidence", "cert", "source"})
_GAP_SCOPES = frozenset({"before", "after"})
_DECIMAL_RE = re.compile(r"^[0-9]+(\.[0-9]+)?$")
_POSINT_RE = re.compile(r"^[1-9][0-9]*$")

def parse_unclear(signal: InputStaffTextSignal) -> UnclearDirective:
    raw = signal.source_text
    if not raw.startswith(UNCLEAR_PREFIX):
        raise ConventionSyntaxError(_ctx(signal, f"expected {UNCLEAR_PREFIX!r}, got {raw!r}"))
    values = _parse_kv_payload(signal, raw[len(UNCLEAR_PREFIX) :], _UNCLEAR_KEYS, "unclear")
    target = _require_target(signal, values, UNCLEAR_TARGETS, "unclear")
    extras = sorted(_UNCLEAR_LYRIC_ONLY_KEYS.intersection(values))
    if extras and target != "lyric":
        raise ConventionSyntaxError(
            _ctx(
                signal,
                f"unknown unclear key {extras[0]!r} in {raw!r}",
            )
        )
    _require_anchor_kind(signal, target)
    return UnclearDirective(
        target=target,
        reason=_optional_token(signal, values, "reason"),
        agent=_optional_token(signal, values, "agent"),
        evidence=_optional_closed(signal, values, "evidence", EVIDENCE_VALUES),
        cert=_optional_closed(signal, values, "cert", CERT_VALUES),
        source_token=_optional_token(signal, values, "source"),
        anchor=signal.anchor,
        source_text=raw,
        source_xml_id=signal.source_xml_id,
        extent=_optional_token(signal, values, "extent"),
        unit=_optional_token(signal, values, "unit"),
        verse_n=_optional_positive_int(signal, values, "verse"),
    )


def parse_supplied(signal: InputStaffTextSignal) -> SuppliedDirective:
    raw = signal.source_text
    if not raw.startswith(SUPPLIED_PREFIX):
        raise ConventionSyntaxError(
            _ctx(signal, f"expected {SUPPLIED_PREFIX!r}, got {raw!r}")
        )
    values = _parse_kv_payload(signal, raw[len(SUPPLIED_PREFIX) :], _SUPPLIED_KEYS, "supplied")
    target = _require_target(signal, values, SUPPLIED_TARGETS, "supplied")
    _require_anchor_kind(signal, target)
    return SuppliedDirective(
        target=target,
        reason=_optional_token(signal, values, "reason"),
        agent=_optional_token(signal, values, "agent"),
        evidence=_optional_closed(signal, values, "evidence", EVIDENCE_VALUES),
        cert=_optional_closed(signal, values, "cert", CERT_VALUES),
        source_token=_optional_token(signal, values, "source"),
        anchor=signal.anchor,
        source_text=raw,
        source_xml_id=signal.source_xml_id,
    )


def parse_damage(signal: InputStaffTextSignal) -> DamageDirective:
    raw = signal.source_text
    if not raw.startswith(DAMAGE_PREFIX):
        raise ConventionSyntaxError(_ctx(signal, f"expected {DAMAGE_PREFIX!r}, got {raw!r}"))
    values = _parse_kv_payload(signal, raw[len(DAMAGE_PREFIX) :], _DAMAGE_KEYS, "damage")
    if "target" in values:
        raise ConventionSyntaxError(
            _ctx(signal, "damage does not accept target= in V1")
        )
    scope = values.get("scope")
    if scope is None:
        raise ConventionSyntaxError(_ctx(signal, "damage missing required scope=before"))
    if scope != "before":
        raise ConventionSyntaxError(
            _ctx(signal, f"unsupported damage scope {scope!r}; V1 allows only scope=before")
        )
    atleast = _optional_decimal(signal, values, "atleast")
    atmost = _optional_decimal(signal, values, "atmost")
    if atleast is not None and atmost is not None and float(atleast) > float(atmost):
        raise ConventionSyntaxError(
            _ctx(signal, f"damage atleast={atleast!r} exceeds atmost={atmost!r}")
        )
    return DamageDirective(
        agent=_optional_token(signal, values, "agent"),
        extent=_optional_token(signal, values, "extent"),
        atleast=atleast,
        atmost=atmost,
        unit=_optional_token(signal, values, "unit"),
        scope=scope,
        anchor=signal.anchor,
        source_text=raw,
        source_xml_id=signal.source_xml_id,
    )


def parse_gap(signal: InputStaffTextSignal) -> GapDirective:
    raw = signal.source_text
    if not raw.startswith(GAP_PREFIX):
        raise ConventionSyntaxError(_ctx(signal, f"expected {GAP_PREFIX!r}, got {raw!r}"))
    values = _parse_kv_payload(signal, raw[len(GAP_PREFIX) :], _GAP_KEYS, "gap")
    kind = signal.anchor.event_kind
    if kind not in {"note", "rest"}:
        raise ConventionSyntaxError(
            _ctx(signal, f"gap must be anchored on a note or rest, got {kind!r}")
        )
    scope = values.get("scope")
    if scope is None:
        raise ConventionSyntaxError(_ctx(signal, "gap missing required scope=before|after"))
    if scope not in _GAP_SCOPES:
        raise ConventionSyntaxError(
            _ctx(
                signal,
                f"unsupported gap scope {scope!r}; V1 allows only scope=before|after",
            )
        )
    return GapDirective(
        reason=_require_token(signal, values, "reason"),
        extent=_require_token(signal, values, "extent"),
        scope=scope,
        unit=_optional_token(signal, values, "unit"),
        evidence=_optional_closed(signal, values, "evidence", EVIDENCE_VALUES),
        cert=_optional_closed(signal, values, "cert", CERT_VALUES),
        source_token=_optional_token(signal, values, "source"),
        anchor=signal.anchor,
        source_text=raw,
        source_xml_id=signal.source_xml_id,
    )


def validate_editorial_composition(
    directives: tuple[StructuredDirective, ...] | list[StructuredDirective],
) -> None:
    """Reject prohibited V1 stacking on the same source anchor."""
    grouped: dict[tuple[str, int, int], list[StructuredDirective]] = defaultdict(list)
    for directive in directives:
        if not isinstance(
            directive, (UnclearDirective, SuppliedDirective, DamageDirective, GapDirective)
        ):
            continue
        # supplied:target=clef addresses the clef, not the StaffText note.
        if isinstance(directive, SuppliedDirective) and directive.target == "clef":
            continue
        anchor = directive.anchor
        grouped[(anchor.voice_identity, anchor.measure_n, anchor.ordinal)].append(
            directive
        )
    for key, group in grouped.items():
        keys = [_composition_key(item) for item in group]
        seen: set[tuple[str, str | None, int | None]] = set()
        for item, comp in zip(group, keys, strict=True):
            if comp in seen:
                raise ConventionSyntaxError(
                    _anchor_ctx(
                        item.anchor,
                        item.source_xml_id,
                        f"duplicate editorial target {comp!r} in {item.source_text!r}",
                    )
                )
            seen.add(comp)
        if _composition_allowed(keys):
            continue
        texts = ", ".join(repr(item.source_text) for item in group)
        raise ConventionSyntaxError(
            _anchor_ctx(
                group[0].anchor,
                group[0].source_xml_id,
                f"unsupported editorial composition on one event: {texts}",
            )
        )


def _composition_key(
    directive: StructuredDirective,
) -> tuple[str, str | None, int | None]:
    if isinstance(directive, DamageDirective):
        return ("damage", None, None)
    if isinstance(directive, GapDirective):
        return ("gap", directive.scope, None)
    if isinstance(directive, UnclearDirective):
        verse_n = directive.verse_n if directive.target == "lyric" else None
        return ("unclear", directive.target, verse_n)
    if isinstance(directive, SuppliedDirective):
        return ("supplied", directive.target, None)
    raise TypeError(f"unsupported editorial directive {type(directive)!r}")


def _slot_key(key: tuple[str, str | None, int | None]) -> tuple[str, str | None]:
    return (key[0], key[1])


def _composition_allowed(
    keys: list[tuple[str, str | None, int | None]],
) -> bool:
    """Allow independent pitch/dur aspects; keep whole-event claims exclusive."""
    keys = [key for key in keys if key[0] != "gap"]
    if len(keys) <= 1:
        return True
    other = [
        _slot_key(key)
        for key in keys
        if not (key[0] == "unclear" and key[1] == "lyric")
    ]
    other_set = frozenset(other)
    if other_set & _WHOLE_EVENT_SLOTS and other_set & _ASPECT_EVENT_SLOTS:
        return False
    if len(other_set & _WHOLE_EVENT_SLOTS) > 1:
        return False
    rest = other_set - {("damage", None)}
    return rest <= _ASPECT_EVENT_SLOTS or rest <= _WHOLE_EVENT_SLOTS


def _parse_kv_payload(
    signal: InputStaffTextSignal,
    payload: str,
    allowed_keys: frozenset[str],
    kind: str,
) -> dict[str, str]:
    raw = signal.source_text
    if payload == "" or " " in payload:
        raise ConventionSyntaxError(_ctx(signal, f"invalid {kind} payload in {raw!r}"))
    values: dict[str, str] = {}
    for part in payload.split(","):
        if part == "" or "=" not in part:
            raise ConventionSyntaxError(
                _ctx(signal, f"invalid {kind} attribute {part!r} in {raw!r}")
            )
        key, sep, value = part.partition("=")
        if sep != "=" or key == "" or value == "" or "=" in value:
            raise ConventionSyntaxError(
                _ctx(signal, f"invalid {kind} attribute {part!r} in {raw!r}")
            )
        if key in values:
            raise ConventionSyntaxError(
                _ctx(signal, f"duplicate {kind} key {key!r} in {raw!r}")
            )
        if key not in allowed_keys:
            raise ConventionSyntaxError(
                _ctx(signal, f"unknown {kind} key {key!r} in {raw!r}")
            )
        values[key] = value
    return values


def _require_target(
    signal: InputStaffTextSignal,
    values: dict[str, str],
    allowed: frozenset[str],
    kind: str,
) -> str:
    target = values.get("target")
    if target is None:
        raise ConventionSyntaxError(
            _ctx(signal, f"{kind} missing required target=")
        )
    if target in UNSUPPORTED_TARGETS or target not in allowed:
        raise ConventionSyntaxError(
            _ctx(signal, f"unsupported {kind} target {target!r} in V1")
        )
    return target


def _require_anchor_kind(signal: InputStaffTextSignal, target: str) -> None:
    kind = signal.anchor.event_kind
    if (
        target
        in {"note", "lyric", "pitch", "ligature-membership", "ligature-start"}
        and kind != "note"
    ):
        raise ConventionSyntaxError(
            _ctx(
                signal,
                f"target={target} must be anchored on a note, got {kind!r}",
            )
        )
    if target == "dur" and kind not in {"note", "rest"}:
        raise ConventionSyntaxError(
            _ctx(
                signal,
                f"target=dur must be anchored on a note or rest, got {kind!r}",
            )
        )
    if target == "clef" and kind not in {"note", "rest", "mRest"}:
        raise ConventionSyntaxError(
            _ctx(
                signal,
                f"target=clef must be anchored on a rhythmic event, got {kind!r}",
            )
        )


def _require_token(
    signal: InputStaffTextSignal, values: dict[str, str], key: str
) -> str:
    value = _optional_token(signal, values, key)
    if value is None:
        raise ConventionSyntaxError(_ctx(signal, f"gap missing required {key}="))
    return value


def _optional_token(
    signal: InputStaffTextSignal, values: dict[str, str], key: str
) -> str | None:
    value = values.get(key)
    if value is None:
        return None
    if value == "":
        raise ConventionSyntaxError(_ctx(signal, f"empty {key}="))
    return value


def _optional_closed(
    signal: InputStaffTextSignal,
    values: dict[str, str],
    key: str,
    allowed: frozenset[str],
) -> str | None:
    value = _optional_token(signal, values, key)
    if value is None:
        return None
    if value not in allowed:
        raise ConventionSyntaxError(
            _ctx(signal, f"invalid {key} {value!r}; allowed {sorted(allowed)}")
        )
    return value


def _optional_positive_int(
    signal: InputStaffTextSignal, values: dict[str, str], key: str
) -> int | None:
    value = _optional_token(signal, values, key)
    if value is None:
        return None
    if not _POSINT_RE.fullmatch(value):
        raise ConventionSyntaxError(
            _ctx(signal, f"invalid {key} {value!r}; expected a positive integer")
        )
    return int(value)


def _optional_decimal(
    signal: InputStaffTextSignal, values: dict[str, str], key: str
) -> str | None:
    value = _optional_token(signal, values, key)
    if value is None:
        return None
    if not _DECIMAL_RE.fullmatch(value):
        raise ConventionSyntaxError(
            _ctx(signal, f"invalid {key} {value!r}; expected a decimal number")
        )
    return value


def _ctx(signal: InputStaffTextSignal, message: str) -> str:
    return _anchor_ctx(signal.anchor, signal.source_xml_id, message)


def _anchor_ctx(anchor: InputEventAddress, source_xml_id: str, message: str) -> str:
    return (
        f"voice={anchor.voice_identity!r} measure={anchor.measure_n} "
        f"ordinal={anchor.ordinal} xml:id={source_xml_id!r}: {message}"
    )
