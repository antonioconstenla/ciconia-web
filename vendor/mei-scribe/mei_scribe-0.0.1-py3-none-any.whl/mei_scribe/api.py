"""API publique de conversion en mémoire pour mei-scribe.

Cette couche fournit une frontière stable et agnostique vis-à-vis de
l'environnement d'exécution :

- bytes MEI Basic en entrée ;
- bytes sibling CMN + mensural en sortie ;
- diagnostics typés inchangés ;
- métadonnées légères utiles aux adaptateurs (CLI, navigateur, serveur).
"""

from __future__ import annotations

import xml.etree.ElementTree as ET
from dataclasses import dataclass
from pathlib import PurePath

from mei_scribe.contracts import VoicePolicy
from mei_scribe.io.reader import read_input_document
from mei_scribe.io.writer import (
    OutputFileNames,
    serialize_transformation_bundle,
    sibling_output_names,
)
from mei_scribe.transform import transform_document
from mei_scribe.transform.model import OutputDiagnostic


@dataclass(frozen=True)
class ConversionMetadata:
    """Métadonnées stables retournées avec la conversion."""

    source_name: str | None
    suggested_output_names: OutputFileNames | None
    diagnostic_count: int
    warning_count: int


@dataclass(frozen=True)
class ConversionResult:
    """Résultat in-memory : deux siblings sérialisés + diagnostics + métadonnées."""

    cmn_mei: bytes
    mensural_mei: bytes
    diagnostics: tuple[OutputDiagnostic, ...]
    metadata: ConversionMetadata


def convert_mei_bytes(
    source: bytes,
    *,
    source_name: str | PurePath | None = None,
    policy: VoicePolicy | str | None = VoicePolicy.SOURCE_ORDER_V1,
) -> ConversionResult:
    """Convertit un document MEI Basic en deux siblings MEI en mémoire.

    Le document source est parsé une seule fois, puis relu via l'architecture
    normale ``read_input_document()`` → ``transform_document()`` → writers.
    Les erreurs bloquantes sont propagées telles quelles par le pipeline
    existant.
    """

    root = _parse_source_root(source)
    document = read_input_document(root, policy=policy)
    bundle = transform_document(document)
    serialized = serialize_transformation_bundle(bundle)
    logical_name = _normalize_source_name(source_name)
    suggested = sibling_output_names(logical_name) if logical_name is not None else None
    diagnostics = bundle.diagnostics
    return ConversionResult(
        cmn_mei=serialized.cmn_mei,
        mensural_mei=serialized.mensural_mei,
        diagnostics=diagnostics,
        metadata=ConversionMetadata(
            source_name=logical_name,
            suggested_output_names=suggested,
            diagnostic_count=len(diagnostics),
            warning_count=sum(1 for diagnostic in diagnostics if diagnostic.severity == "WARNING"),
        ),
    )


def _parse_source_root(source: bytes) -> ET.Element:
    try:
        return ET.fromstring(source)
    except ET.ParseError as exc:
        # Keep the existing reader-facing exception family.
        from mei_scribe.io.errors import VoiceTopologyError

        raise VoiceTopologyError(f"malformed XML: {exc}") from exc


def _normalize_source_name(source_name: str | PurePath | None) -> str | None:
    if source_name is None:
        return None
    if isinstance(source_name, PurePath):
        return source_name.name
    return PurePath(str(source_name)).name


__all__ = [
    "ConversionMetadata",
    "ConversionResult",
    "convert_mei_bytes",
]
