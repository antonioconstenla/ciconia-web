"""Contrôles ciblés J7.3 sur les bytes MEI produits (pas RNG/Schematron)."""

from __future__ import annotations

import xml.etree.ElementTree as ET

from mei_scribe.io.errors import OutputValidationError
from mei_scribe.io.mei_builder import (
    CMN_MEIVERSION,
    CMN_RNG,
    MEI_NS,
    MENSURAL_MEIVERSION,
    MENSURAL_RNG,
    XML_NS,
)

_FORBIDDEN_TEXT_PATTERNS = (
    "ligature:",
    "rest:dur=",
    "note:stem",
    "note:graphy",
    "clefGrp:",
    "custos",
    "anchoredText:",
    "paratext:",
)


def validate_cmn_mei_bytes(data: bytes) -> None:
    """Valide structurellement une sortie CMN sérialisée."""
    root = _parse_root(data, expected_meiversion=CMN_MEIVERSION, expected_rng=CMN_RNG)
    _assert_unique_ids(root)
    _assert_idrefs_resolved(root)
    _assert_no_forbidden_residue(data, root, allow_mei_custos=False)
    if root.find(f".//{{{MEI_NS}}}measure") is None:
        raise OutputValidationError("CMN output must contain measures")
    if root.find(f".//{{{MEI_NS}}}mdiv/{{{MEI_NS}}}score") is None:
        raise OutputValidationError("CMN output must contain mdiv/score")
    for tag in ("pedal", "pb", "sb", "ligature", "custos"):
        if root.find(f".//{{{MEI_NS}}}{tag}") is not None:
            raise OutputValidationError(f"CMN output must not contain <{tag}>")
    for directive in root.findall(f".//{{{MEI_NS}}}dir"):
        if directive.get("type") == "mscore-staff-text":
            raise OutputValidationError("CMN output contains MuseScore staff text")


def validate_mensural_mei_bytes(data: bytes) -> None:
    """Valide structurellement une sortie mensurale sérialisée."""
    root = _parse_root(
        data, expected_meiversion=MENSURAL_MEIVERSION, expected_rng=MENSURAL_RNG
    )
    _assert_unique_ids(root)
    _assert_idrefs_resolved(root)
    _assert_no_forbidden_residue(data, root, allow_mei_custos=True)
    if root.find(f".//{{{MEI_NS}}}measure") is not None:
        raise OutputValidationError("mensural output must not contain <measure>")
    if root.find(f".//{{{MEI_NS}}}mdiv/{{{MEI_NS}}}score") is None:
        raise OutputValidationError("mensural output must contain mdiv/score")
    for tag in ("mRest", "tuplet", "tie", "pedal", "pb"):
        if root.find(f".//{{{MEI_NS}}}{tag}") is not None:
            raise OutputValidationError(
                f"mensural output must not contain <{tag}>"
            )
    _assert_mensural_sb_structure(root)
    for directive in root.findall(f".//{{{MEI_NS}}}dir"):
        if directive.get("type") == "mscore-staff-text":
            raise OutputValidationError(
                "mensural output contains MuseScore staff text"
            )
    for mensur in root.findall(f".//{{{MEI_NS}}}mensur"):
        raise OutputValidationError(
            "mensural output must not invent a graphic <mensur> sign"
        )
    for staff_def in root.findall(f".//{{{MEI_NS}}}staffDef"):
        for banned in (
            "mensur.sign",
            "mensur.dot",
            "mensur.slash",
            "mensur.orient",
            "modusmaior",
        ):
            if banned in staff_def.attrib:
                raise OutputValidationError(
                    f"mensural staffDef must not invent {banned}"
                )


def _parse_root(
    data: bytes, *, expected_meiversion: str, expected_rng: str
) -> ET.Element:
    if data.startswith(b"\xef\xbb\xbf"):
        raise OutputValidationError("MEI output must not include a UTF-8 BOM")
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise OutputValidationError("MEI output is not valid UTF-8") from exc
    if expected_rng not in text:
        raise OutputValidationError(
            f"missing expected xml-model href {expected_rng!r}"
        )
    try:
        root = ET.fromstring(data)
    except ET.ParseError as exc:
        raise OutputValidationError(f"MEI output is not well-formed XML: {exc}") from exc
    if root.tag != f"{{{MEI_NS}}}mei":
        raise OutputValidationError("root element must be MEI in the MEI namespace")
    if root.get("meiversion") != expected_meiversion:
        raise OutputValidationError(
            f"expected meiversion={expected_meiversion!r}, "
            f"got {root.get('meiversion')!r}"
        )
    return root


def _assert_mensural_sb_structure(root: ET.Element) -> None:
    """Allow score-level ``<sb>`` only; reject layer/staff/section-internal sb."""
    score_tag = f"{{{MEI_NS}}}score"
    section_tag = f"{{{MEI_NS}}}section"
    sb_tag = f"{{{MEI_NS}}}sb"
    staff_tag = f"{{{MEI_NS}}}staff"
    layer_tag = f"{{{MEI_NS}}}layer"

    for element in root.iter():
        if element.tag != sb_tag:
            continue
        parent = _parent_map(root).get(element)
        if parent is None or parent.tag != score_tag:
            raise OutputValidationError(
                "mensural <sb> must be a direct child of <score>"
            )

    for score in root.findall(f".//{score_tag}"):
        children = list(score)
        # Child sequence after scoreDef: optional (section*) (sb section)*
        # or voice-start: (sb section)+ optionally preceded by zero sections.
        saw_non_scoredef = False
        expecting_section_after_sb = False
        for child in children:
            tag = child.tag
            if tag == f"{{{MEI_NS}}}scoreDef":
                if saw_non_scoredef:
                    raise OutputValidationError(
                        "mensural <scoreDef> must precede score content"
                    )
                continue
            saw_non_scoredef = True
            if expecting_section_after_sb:
                if tag != section_tag:
                    raise OutputValidationError(
                        "mensural <sb> must be followed by <section>"
                    )
                expecting_section_after_sb = False
                continue
            if tag == sb_tag:
                expecting_section_after_sb = True
                continue
            if tag == section_tag:
                continue
            raise OutputValidationError(
                f"unsupported mensural score child <{tag.split('}')[-1]}>"
            )
        if expecting_section_after_sb:
            raise OutputValidationError(
                "mensural <sb> must be followed by <section>"
            )

        for section in score.findall(section_tag):
            for descendant in section.iter():
                if descendant.tag == sb_tag:
                    raise OutputValidationError(
                        "mensural <sb> must not appear inside <section>"
                    )
            for staff in section.findall(staff_tag):
                for layer in staff.findall(layer_tag):
                    for child in layer:
                        if child.tag == sb_tag:
                            raise OutputValidationError(
                                "mensural <sb> must not appear inside <layer>"
                            )


def _parent_map(root: ET.Element) -> dict[ET.Element, ET.Element]:
    return {child: parent for parent in root.iter() for child in parent}


def _assert_unique_ids(root: ET.Element) -> None:
    seen: set[str] = set()
    for element in root.iter():
        xml_id = element.get(f"{{{XML_NS}}}id")
        if xml_id is None:
            continue
        if xml_id in seen:
            raise OutputValidationError(f"duplicate xml:id {xml_id!r}")
        seen.add(xml_id)


def _assert_idrefs_resolved(root: ET.Element) -> None:
    ids = {
        element.get(f"{{{XML_NS}}}id")
        for element in root.iter()
        if element.get(f"{{{XML_NS}}}id") is not None
    }
    for element in root.iter():
        for attr, value in element.attrib.items():
            if attr not in {"startid", "endid"}:
                continue
            if not value.startswith("#"):
                raise OutputValidationError(
                    f"IDREF {attr}={value!r} must start with '#'"
                )
            target = value[1:]
            if target not in ids:
                raise OutputValidationError(
                    f"unresolved IDREF {attr}={value!r}"
                )


def _assert_no_forbidden_residue(
    data: bytes, root: ET.Element, *, allow_mei_custos: bool
) -> None:
    text = data.decode("utf-8")
    # Ignore meiHead metadata text when checking directive residues in music.
    music = root.find(f"{{{MEI_NS}}}music")
    music_text = ET.tostring(music, encoding="unicode") if music is not None else text
    residue_text = music_text
    for pattern in _FORBIDDEN_TEXT_PATTERNS:
        if pattern == "custos":
            if music is not None:
                _assert_no_custos_directive_residue(music)
            continue
        if pattern in residue_text:
            raise OutputValidationError(
                f"forbidden residue {pattern!r} found in MEI music"
            )


def _assert_no_custos_directive_residue(music: ET.Element) -> None:
    """Rejette les résidus StaffText ``custos`` non consommés, pas le mot en général."""
    dir_tag = f"{{{MEI_NS}}}dir"
    for element in music.iter():
        if element.tag != dir_tag:
            continue
        text = (element.text or "").strip()
        if text != "custos":
            continue
        if element.get("type") == "mscore-staff-text":
            raise OutputValidationError(
                "forbidden MuseScore staff text residue 'custos' found in MEI music"
            )
        if element.get("type") is None:
            raise OutputValidationError(
                "forbidden raw directive residue 'custos' found in MEI music"
            )
