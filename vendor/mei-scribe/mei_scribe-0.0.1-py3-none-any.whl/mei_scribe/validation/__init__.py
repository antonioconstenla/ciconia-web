"""Validation du modèle interne et des documents MEI produits."""
