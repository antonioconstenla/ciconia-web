"""Structures du modèle interne (J3–J7.1).

J3 : topologie des voix.
J4 : mesures et événements musicaux élémentaires.
J5 : porteurs de signaux source (``dir`` / ``pedal`` / ``tie``) résolus
vers des adresses métier.
J6 : ligatures structurées (``lig:`` + ``pedal``), sans mutation des
événements ni écriture MEI.
J7.1 : métadonnées, paroles, accidents écrits, tuplets, conventions
transcripteur et politique générale des voix.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Union


@dataclass(frozen=True)
class InputClef:
    """Clef source (shape + line), sans conversion éditoriale.

    Valeur partagée : ``Voice.initial_clef``, ``ClefGroupDirective.clefs``,
    et ``InputInlineClef.clef``. Le rôle (clef initiale vs changement
    cadencé) n'est pas porté par ce type.
    """

    shape: str
    line: int


@dataclass(frozen=True)
class Voice:
    """Voix éditoriale du modèle interne.

    Distingue :
    - ``identity`` : identité éditoriale stable (indépendante de MuseScore) ;
    - ``name`` : nom affiché normalisé ;
    - ``source_staff_n`` : numéro de portée dans l'entrée MEI Basic ;
    - ``rank`` : rang déterministe (1-based) ;
    - ``output_mdiv_id`` / ``output_order_n`` : identité de sortie J2 ``id-plus-n``
      (ou placeholders stables sous ``SOURCE_ORDER_V1``) ;
    - ``initial_clef`` / métrique CMN : données de ``staffDef`` utiles plus tard.
    """

    identity: str
    name: str
    source_staff_n: int
    rank: int
    output_mdiv_id: str
    output_order_n: str
    initial_clef: InputClef | None = None
    meter_count: int | None = None
    meter_unit: int | None = None


@dataclass(frozen=True)
class VoiceTopologyDocument:
    """Document interne limité à la topologie des voix (J3 / J7.1)."""

    voices: tuple[Voice, ...]
    meiversion: str | None = None
    source_format: str = "mei-basic"
    voice_policy: str = "three-voice-v1"

    def voices_in_order(self) -> tuple[Voice, ...]:
        """Retourne les voix dans l'ordre déterministe du document."""
        return self.voices

    def voice_names(self) -> tuple[str, ...]:
        """Noms affichés normalisés, dans l'ordre du document."""
        return tuple(voice.name for voice in self.voices)

    def voice_by_staff_n(self, staff_n: int) -> Voice:
        """Retourne la voix associée au numéro de portée source."""
        for voice in self.voices:
            if voice.source_staff_n == staff_n:
                return voice
        raise KeyError(staff_n)


@dataclass(frozen=True)
class InputLyricSyllable:
    """Syllabe liée à une note, sans normalisation automatique."""

    text: str
    verse_n: int | None = None
    wordpos: str | None = None
    con: str | None = None
    source_xml_id: str | None = None


@dataclass(frozen=True)
class InputWrittenAccidental:
    """Accident écrit de source (``<accid>``), distinct d'une hauteur calculée."""

    accid: str
    source_xml_id: str | None = None
    enclose: str | None = None


@dataclass(frozen=True)
class InputGesturalAccidental:
    """Accident gestuel source (``accid.ges``), distinct d'un accident écrit."""

    accid_ges: str
    source_xml_id: str | None = None


@dataclass(frozen=True)
class InputNote:
    """Note d'entrée : valeurs CMN source, sans conversion mensurale."""

    ordinal: int
    pname: str
    oct: int
    dur: str
    dots: int
    source_xml_id: str
    lyrics: tuple[InputLyricSyllable, ...] = ()
    written_accidental: InputWrittenAccidental | None = None
    gestural_accidental: InputGesturalAccidental | None = None


@dataclass(frozen=True)
class InputRest:
    """Silence d'entrée (``rest``) avec durée CMN source."""

    ordinal: int
    dur: str
    dots: int
    source_xml_id: str


@dataclass(frozen=True)
class InputMeasureRest:
    """Silence de mesure (``mRest``) : type distinct, sans durée inventée."""

    ordinal: int
    source_xml_id: str


@dataclass(frozen=True)
class InputInlineClef:
    """Changement de clef cadencé dans une layer.

    N'est pas un événement rythmique : pas d'ordinal J4. L'ordre de
    document est celui du tuple ``VoiceMeasureContent.events``.
    """

    clef: InputClef
    source_xml_id: str


MusicalEvent = Union[InputNote, InputRest, InputMeasureRest, InputInlineClef]


def is_rhythmic_event(event: object) -> bool:
    """True pour note / rest / mRest ; False pour un changement de clef."""
    return isinstance(event, (InputNote, InputRest, InputMeasureRest))


@dataclass(frozen=True)
class VoiceMeasureContent:
    """Séquence ordonnée d'événements d'une voix dans une mesure."""

    voice_identity: str
    source_staff_n: int
    layer_n: int
    measure_n: int
    events: tuple[MusicalEvent, ...]


@dataclass(frozen=True)
class Measure:
    """Mesure complète : une séquence par voix, ordre documentaire."""

    n: int
    voices: tuple[VoiceMeasureContent, ...]


@dataclass(frozen=True, order=True)
class InputEventAddress:
    """Adresse métier d'un événement J4.

    Coordonnées : identité de voix + numéro de mesure + ordinal.
    ``event_kind`` précise le type ciblé sans servir de clé d'ordre.
    """

    voice_identity: str
    measure_n: int
    ordinal: int
    event_kind: str = field(compare=False)


@dataclass(frozen=True)
class InputTuplet:
    """Groupe tuplet CMN : événements aplatis + références aux membres."""

    num: int
    numbase: int
    member_addresses: tuple[InputEventAddress, ...]
    source_xml_id: str


@dataclass(frozen=True)
class InputStaffTextSignal:
    """Staff Text MuseScore (``dir@type=mscore-staff-text``), non transformé."""

    source_xml_id: str
    carrier_measure_n: int
    anchor: InputEventAddress
    source_text: str
    lexical_prefix: str | None
    place: str | None = None


@dataclass(frozen=True)
class InputPedalSpan:
    """Span ``pedal`` source (porteur de plage), sans création de ligature."""

    source_xml_id: str
    carrier_measure_n: int
    start: InputEventAddress
    end: InputEventAddress
    pedal_dir: str | None = None
    form: str | None = None


@dataclass(frozen=True)
class InputTieSpan:
    """Span ``tie`` source, sans fusion ni inférence de longa."""

    source_xml_id: str
    carrier_measure_n: int
    start: InputEventAddress
    end: InputEventAddress


InputSignal = Union[InputStaffTextSignal, InputPedalSpan, InputTieSpan]


@dataclass(frozen=True)
class LigatureFormChange:
    """Changement de forme à une position 1-based dans une ligature."""

    position: int
    form: str


@dataclass(frozen=True)
class ParsedLigatureText:
    """Description syntaxique d'un Staff Text de ligature."""

    source_text: str
    initial_form: str
    changes: tuple[LigatureFormChange, ...]


@dataclass(frozen=True)
class ResolvedLigature:
    """Ligature source résolue : bornes pedal + formes effectives par note."""

    staff_text_xml_id: str
    pedal_xml_id: str
    voice_identity: str
    start: InputEventAddress
    end: InputEventAddress
    member_addresses: tuple[InputEventAddress, ...]
    effective_forms: tuple[str, ...]
    source_text: str
    form_changes: tuple[LigatureFormChange, ...]


@dataclass(frozen=True)
class StructuredMensuration:
    """Mensuration structurée lue une fois depuis les métadonnées source."""

    modusminor: int
    tempus: int
    prolatio: int
    modusmaior: int | None = None


@dataclass(frozen=True)
class InputParatext:
    """Paratexte de surface, distinct des paroles et des Staff Texts."""

    surface: str
    type: str
    position: str
    text: str
    source_line: str


@dataclass(frozen=True)
class InputDocumentMetadata:
    """Métadonnées documentaires analysées une seule fois à la lecture."""

    title: str | None
    composer: str | None
    source_siglum: str | None
    source_repo: str | None
    source_idno: str | None
    notation_type: str | None
    mensuration: StructuredMensuration | None
    mensur_in_source: bool | None
    availability_lines: tuple[str, ...]
    paratexts: tuple[InputParatext, ...]
    transcriber: str | None = None
    license: str | None = None


@dataclass(frozen=True)
class RestDurationDirective:
    """Segmentation explicite ``rest:dur=...`` (sans calcul de durée à J7.1)."""

    values: tuple[str, ...]
    anchor: InputEventAddress
    source_text: str
    source_xml_id: str


@dataclass(frozen=True)
class NoteStemDirective:
    """Graphie de hampe ``note:stem...`` (aucune interprétation rythmique)."""

    stem_dir: str | None
    stem_pos: str | None
    stem_form: str | None
    anchor: InputEventAddress
    source_text: str
    source_xml_id: str


@dataclass(frozen=True)
class NoteGraphyDirective:
    """Graphie paléographique ``note:graphy=...`` (durée logique inchangée)."""

    graphy: str
    anchor: InputEventAddress
    source_text: str
    source_xml_id: str


@dataclass(frozen=True)
class ClefGroupDirective:
    """Groupe de clefs simultanées ``clefGrp:...``."""

    clefs: tuple[InputClef, ...]
    anchor: InputEventAddress
    source_text: str
    source_xml_id: str


@dataclass(frozen=True)
class CustosDirective:
    """Marqueur ``custos`` ancré au premier événement du nouveau système."""

    anchor: InputEventAddress
    source_text: str
    source_xml_id: str


@dataclass(frozen=True)
class SystemStartDirective:
    """Marqueur ``system:start`` : rupture de système source sans custos."""

    anchor: InputEventAddress
    source_text: str
    source_xml_id: str


@dataclass(frozen=True)
class AnchoredTextPlain:
    """Texte brut dans un payload ``anchoredText``."""

    text: str


@dataclass(frozen=True)
class AnchoredTextAbbr:
    """Abréviation inline ``[[abbr:expan=…]]``."""

    expan: str
    text: str = ""


@dataclass(frozen=True)
class AnchoredTextUnclear:
    """Portée ``unclear`` inline ou wrapper lyricFragment."""

    text: str
    reason: str | None = None
    agent: str | None = None
    evidence: str | None = None
    cert: str | None = None
    source_token: str | None = None


@dataclass(frozen=True)
class AnchoredTextSupplied:
    """Portée ``supplied`` inline ou wrapper lyricFragment."""

    text: str
    reason: str | None = None
    agent: str | None = None
    evidence: str | None = None
    cert: str | None = None
    source_token: str | None = None


@dataclass(frozen=True)
class AnchoredTextGap:
    """Lacune inline ``[[gap:…]]`` sans contenu."""

    reason: str | None = None
    extent: str | None = None
    unit: str | None = None


@dataclass(frozen=True)
class AnchoredTextDamage:
    """Dommage textuel inline ``[[damage:…]]`` sans contenu."""

    agent: str | None = None
    extent: str | None = None
    unit: str | None = None
    atleast: str | None = None
    atmost: str | None = None


@dataclass(frozen=True)
class AnchoredTextChoice:
    """Unordered alternative readings for lyricFragment editorial=alternative.

    ``readings`` are ordered only for deterministic serialization; the set is
    semantically unordered. ``member_source_*`` preserve StaffText provenance
    in source order.
    """

    readings: tuple[AnchoredTextUnclear, ...]
    member_source_xml_ids: tuple[str, ...]
    member_source_texts: tuple[str, ...]


AnchoredTextPart = Union[
    AnchoredTextPlain,
    AnchoredTextAbbr,
    AnchoredTextUnclear,
    AnchoredTextSupplied,
    AnchoredTextGap,
    AnchoredTextDamage,
    AnchoredTextChoice,
]


@dataclass(frozen=True)
class AnchoredTextDirective:
    """Texte ancré non chanté ``anchoredText:...``."""

    func: str
    text: str
    anchor: InputEventAddress
    source_text: str
    source_xml_id: str
    n: str | None = None
    block: str | None = None
    line: int | None = None
    part: int | None = None
    parts: tuple[AnchoredTextPart, ...] = ()
    verse_n: int | None = None
    editorial: str | None = None
    evidence: str | None = None


@dataclass(frozen=True)
class UnclearDirective:
    """StaffText ``unclear:target=…`` (EDITORIAL_UNCERTAINTY_V1)."""

    target: str
    reason: str | None
    agent: str | None
    evidence: str | None
    cert: str | None
    source_token: str | None
    anchor: InputEventAddress
    source_text: str
    source_xml_id: str
    extent: str | None = None
    unit: str | None = None
    verse_n: int | None = None


@dataclass(frozen=True)
class SuppliedDirective:
    """StaffText ``supplied:target=note|clef``."""

    target: str
    reason: str | None
    agent: str | None
    evidence: str | None
    cert: str | None
    source_token: str | None
    anchor: InputEventAddress
    source_text: str
    source_xml_id: str


@dataclass(frozen=True)
class SpaceDirective:
    """StaffText ``space:type=measure-fill`` (technical MuseScore filler)."""

    type: str
    anchor: InputEventAddress
    source_text: str
    source_xml_id: str


@dataclass(frozen=True)
class DotDirective:
    """Exact diplomatic source-dot StaffText ``dot:form=aug``."""

    form: str
    anchor: InputEventAddress
    source_text: str
    source_xml_id: str


@dataclass(frozen=True)
class GraphicLineDirective:
    """StaffText ``graphicLine:func=separator,…`` (structural projection deferred)."""

    func: str
    block: str
    line: int
    part: int
    color: str
    anchor: InputEventAddress
    source_text: str
    source_xml_id: str


@dataclass(frozen=True)
class DamageDirective:
    """StaffText ``damage:…,scope=before`` (EDITORIAL_UNCERTAINTY_V1)."""

    agent: str | None
    extent: str | None
    atleast: str | None
    atmost: str | None
    unit: str | None
    scope: str
    anchor: InputEventAddress
    source_text: str
    source_xml_id: str


@dataclass(frozen=True)
class GapDirective:
    """Standalone StaffText ``gap:…,scope=before|after`` (GAP_EDITORIAL_V1)."""

    reason: str
    extent: str
    scope: str
    unit: str | None
    evidence: str | None
    cert: str | None
    source_token: str | None
    anchor: InputEventAddress
    source_text: str
    source_xml_id: str


StructuredDirective = Union[
    RestDurationDirective,
    NoteStemDirective,
    NoteGraphyDirective,
    ClefGroupDirective,
    CustosDirective,
    SystemStartDirective,
    AnchoredTextDirective,
    UnclearDirective,
    SuppliedDirective,
    DamageDirective,
    GapDirective,
    SpaceDirective,
    DotDirective,
    GraphicLineDirective,
]


@dataclass(frozen=True)
class ReadingDiagnostic:
    """Diagnostic déterministe de lecture (hors diagnostics de sortie J7)."""

    code: str
    message: str
    source_text: str | None = None
    voice_identity: str | None = None
    measure_n: int | None = None
    ordinal: int | None = None
    source_xml_id: str | None = None


@dataclass(frozen=True)
class InputDocument:
    """Document musical d'entrée (topologie + événements + signaux + J7.1)."""

    topology: VoiceTopologyDocument
    measures: tuple[Measure, ...]
    signals: tuple[InputSignal, ...] = ()
    metadata: InputDocumentMetadata | None = None
    tuplets: tuple[InputTuplet, ...] = ()
    directives: tuple[StructuredDirective, ...] = ()
    diagnostics: tuple[ReadingDiagnostic, ...] = ()

    def voices_in_order(self) -> tuple[Voice, ...]:
        return self.topology.voices_in_order()

    def voice_names(self) -> tuple[str, ...]:
        return self.topology.voice_names()

    def event_at(
        self, voice_identity: str, measure_n: int, ordinal: int
    ) -> MusicalEvent:
        """Adresse déterministe : identité de voix + mesure + ordinal."""
        for measure in self.measures:
            if measure.n != measure_n:
                continue
            for content in measure.voices:
                if content.voice_identity != voice_identity:
                    continue
                for event in content.events:
                    if is_rhythmic_event(event) and event.ordinal == ordinal:
                        return event
                raise KeyError(
                    f"no event ordinal={ordinal} for voice={voice_identity!r} "
                    f"measure={measure_n}"
                )
        raise KeyError(
            f"no measure n={measure_n} / voice={voice_identity!r}"
        )
