"""mei-scribe : outillage de transcription et de transformation de partitions MEI.

Ce paquet regroupe les composants du pipeline allant d'un export MEI Basic
(issu de MuseScore) jusqu'à une sortie MEI mensural ou CMN, en passant par un
modèle interne, des transformations et une validation.

J3–J6 fournissent la lecture source et la sémantique des ligatures
(MEI Basic → modèle interne). Autres sémantiques, transform, writer et
convert restent à venir.
"""

from mei_scribe.api import ConversionMetadata, ConversionResult, convert_mei_bytes

__version__ = "0.0.1"

__all__ = [
    "ConversionMetadata",
    "ConversionResult",
    "__version__",
    "convert_mei_bytes",
]
