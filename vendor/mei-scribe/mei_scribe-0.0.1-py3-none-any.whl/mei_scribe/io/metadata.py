"""Lecture des métadonnées documentaires depuis ``<availability>`` (J7.1)."""

from __future__ import annotations

import re
import xml.etree.ElementTree as ET

from mei_scribe.io.errors import MetadataError
from mei_scribe.model.document import (
    InputDocumentMetadata,
    InputParatext,
    StructuredMensuration,
)

MEI_NS = "http://www.music-encoding.org/ns/mei"
NS = {"mei": MEI_NS}

_PARATEXT_RE = re.compile(
    r"^paratext:surface=([^,]+),type=([^,]+),position=([^|]+)\|(.*)$"
)
_STRUCTURED_MENSURATION_RE = re.compile(
    r"^modusminor=([0-9]+),tempus=([0-9]+),prolatio=([0-9]+)$"
)
_STRUCTURED_MENSURATION_WITH_MODUSMAIOR_RE = re.compile(
    r"^modusmaior=([0-9]+),modusminor=([0-9]+),tempus=([0-9]+),prolatio=([0-9]+)$"
)
_STRUCTURED_MENSURATION_ATTEMPT_RE = re.compile(r"^(?:modusmaior|modusminor)=")


def read_document_metadata(root: ET.Element) -> InputDocumentMetadata:
    """Analyse une seule fois les lignes pertinentes de ``<availability>``."""
    availability = root.find(".//mei:availability", NS)
    raw = "" if availability is None else "".join(availability.itertext())
    lines = tuple(_iter_availability_lines(raw))

    fields: dict[str, str] = {}
    paratexts: list[InputParatext] = []
    mensuration: StructuredMensuration | None = None
    mensur_in_source: bool | None = None
    mensur_in_source_seen = False

    for line in lines:
        if line.startswith("paratext:"):
            paratexts.append(_parse_paratext(line))
            continue
        if line.startswith("mensuration:"):
            payload = line.split(":", 1)[1].strip()
            structured = _parse_mensuration_payload(payload, line)
            if structured is not None:
                if mensuration is not None:
                    raise MetadataError(
                        "duplicate mensuration line in <availability>"
                    )
                mensuration = structured
            continue
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        key = key.strip()
        value = value.strip()
        if key == "mensur_in_source":
            if mensur_in_source_seen:
                raise MetadataError(
                    "duplicate metadata key 'mensur_in_source' in <availability>"
                )
            mensur_in_source_seen = True
            mensur_in_source = _parse_bool(value, key)
            continue
        if key in fields:
            raise MetadataError(f"duplicate metadata key {key!r} in <availability>")
        fields[key] = value

    return InputDocumentMetadata(
        title=fields.get("work_title"),
        composer=fields.get("composer"),
        source_siglum=fields.get("source_siglum"),
        source_repo=fields.get("source_repo"),
        source_idno=fields.get("source_idno"),
        notation_type=fields.get("notation_type"),
        mensuration=mensuration,
        mensur_in_source=mensur_in_source,
        availability_lines=lines,
        paratexts=tuple(paratexts),
        transcriber=fields.get("transcriber"),
        license=fields.get("license"),
    )


def _iter_availability_lines(raw: str) -> list[str]:
    lines: list[str] = []
    for line in raw.splitlines():
        stripped = line.strip()
        if stripped:
            lines.append(stripped)
    return lines


def _parse_paratext(line: str) -> InputParatext:
    match = _PARATEXT_RE.fullmatch(line)
    if match is None:
        raise MetadataError(f"invalid paratext line {line!r}")
    return InputParatext(
        surface=match.group(1),
        type=match.group(2),
        position=match.group(3),
        text=match.group(4),
        source_line=line,
    )


def _parse_mensuration_payload(
    payload: str, source_line: str
) -> StructuredMensuration | None:
    """Parse une mensuration structurée ou accepte une valeur legacy libre."""
    three = _STRUCTURED_MENSURATION_RE.fullmatch(payload)
    if three is not None:
        return _structured_mensuration(
            source_line,
            modusminor=int(three.group(1)),
            tempus=int(three.group(2)),
            prolatio=int(three.group(3)),
            modusmaior=None,
        )
    four = _STRUCTURED_MENSURATION_WITH_MODUSMAIOR_RE.fullmatch(payload)
    if four is not None:
        return _structured_mensuration(
            source_line,
            modusminor=int(four.group(2)),
            tempus=int(four.group(3)),
            prolatio=int(four.group(4)),
            modusmaior=int(four.group(1)),
        )
    if _STRUCTURED_MENSURATION_ATTEMPT_RE.match(payload):
        raise MetadataError(
            f"invalid structured mensuration line {source_line!r}"
        )
    return None


def _structured_mensuration(
    source_line: str,
    *,
    modusminor: int,
    tempus: int,
    prolatio: int,
    modusmaior: int | None,
) -> StructuredMensuration:
    if modusminor < 1 or tempus < 1 or prolatio < 1:
        raise MetadataError(
            f"invalid structured mensuration line {source_line!r}"
        )
    if modusmaior is not None and modusmaior < 1:
        raise MetadataError(
            f"invalid structured mensuration line {source_line!r}"
        )
    return StructuredMensuration(
        modusminor=modusminor,
        tempus=tempus,
        prolatio=prolatio,
        modusmaior=modusmaior,
    )


def _parse_bool(raw: str, key: str) -> bool:
    if raw == "true":
        return True
    if raw == "false":
        return False
    raise MetadataError(f"metadata {key!r} must be true/false, got {raw!r}")
