"""Lecture de documents MEI Basic (issus d'un export MuseScore).

Tranches :
- J3 : topologie des voix (``staffDef`` / ``staff@n``) ;
- J4 : mesures et événements musicaux élémentaires (``note`` / ``rest`` /
  ``mRest``), avec aplatissement ordonné des ``beam`` ;
- J5 : porteurs de signaux source (``dir`` / ``pedal`` / ``tie``) résolus
  vers des adresses métier, sans transformation musicale ;
- J7.1 : politique générale des voix, métadonnées, paroles, accidents,
  tuplets et conventions structurées.
"""

from __future__ import annotations

import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Union

from mei_scribe.contracts.three_voice_v1 import (
    EXPECTED_VOICE_ORDER,
    THREE_VOICE_V1,
    VOICE_BY_NAME,
)
from mei_scribe.contracts.voice_policy import VoicePolicy, coerce_voice_policy
from mei_scribe.io.errors import (
    MusicalEventsError,
    SourceSignalsError,
    VoiceTopologyError,
)
from mei_scribe.io.metadata import read_document_metadata
from mei_scribe.model.document import (
    InputClef,
    InputDocument,
    InputEventAddress,
    InputGesturalAccidental,
    InputInlineClef,
    InputLyricSyllable,
    InputMeasureRest,
    InputNote,
    InputPedalSpan,
    InputRest,
    InputSignal,
    InputStaffTextSignal,
    InputTieSpan,
    InputTuplet,
    InputWrittenAccidental,
    Measure,
    MusicalEvent,
    Voice,
    VoiceMeasureContent,
    VoiceTopologyDocument,
    is_rhythmic_event,
)
from mei_scribe.signals.conventions import parse_structured_directives
from mei_scribe.signals.parser import parse_staff_text

MEI_NS = "http://www.music-encoding.org/ns/mei"
XML_ID = "{http://www.w3.org/XML/1998/namespace}id"
NS = {"mei": MEI_NS}

Source = Union[str, Path, ET.Element]

# Sous-ensemble CMN accepté (valeurs numériques MuseScore / MEI Basic + breve).
ACCEPTED_CMN_DURS: frozenset[str] = frozenset(
    {"1", "2", "4", "8", "16", "32", "64", "breve"}
)
ACCEPTED_PNAMES: frozenset[str] = frozenset("abcdefg")
EXPECTED_LAYER_N = 1
STAFF_TEXT_TYPE = "mscore-staff-text"
SIGNAL_TAGS = frozenset({"dir", "pedal", "tie"})


def normalize_voice_label(raw: str | None) -> str:
    """Normalise un label de voix : espaces périphériques uniquement."""
    if raw is None:
        return ""
    return raw.strip()


def read_voice_topology(
    source: Source,
    policy: VoicePolicy | str | None = VoicePolicy.THREE_VOICE_V1,
) -> VoiceTopologyDocument:
    """Lit la topologie des voix depuis un chemin ou un élément MEI racine."""
    root = _load_root(source)
    return _read_voice_topology_from_root(root, coerce_voice_policy(policy))


def read_input_document(
    source: Source,
    policy: VoicePolicy | str | None = VoicePolicy.THREE_VOICE_V1,
) -> InputDocument:
    """Lit topologie, événements, signaux, métadonnées et conventions.

    Sans argument ``policy``, le comportement historique ``THREE_VOICE_V1``
    est conservé. ``SOURCE_ORDER_V1`` accepte une ou plusieurs voix, labels
    source préservés, ordre documentaire.
    """
    voice_policy = coerce_voice_policy(policy)
    root = _load_root(source)
    topology = _read_voice_topology_from_root(root, voice_policy)
    measures, tuplets = _read_measures(root, topology)
    signals = _read_signals(root, measures)
    metadata = read_document_metadata(root)
    staff_texts = [
        signal
        for signal in signals
        if isinstance(signal, InputStaffTextSignal)
    ]
    directives, diagnostics = parse_structured_directives(staff_texts)
    return InputDocument(
        topology=topology,
        measures=measures,
        signals=signals,
        metadata=metadata,
        tuplets=tuplets,
        directives=directives,
        diagnostics=diagnostics,
    )


def _read_voice_topology_from_root(
    root: ET.Element, policy: VoicePolicy
) -> VoiceTopologyDocument:
    if _local(root.tag) != "mei":
        raise VoiceTopologyError(
            "document root must be <mei> in the MEI namespace"
        )

    _validate_global_source_xml_ids(root)

    staff_defs = _collect_staff_defs(root)
    if policy is VoicePolicy.THREE_VOICE_V1:
        voices = _voices_from_staff_defs_three_voice_v1(staff_defs)
        _validate_expected_set_and_order(voices)
    else:
        voices = _voices_from_staff_defs_source_order(staff_defs)
    known_n = {voice.source_staff_n for voice in voices}
    _validate_measure_staff_refs(root, known_n)

    return VoiceTopologyDocument(
        voices=voices,
        meiversion=root.attrib.get("meiversion"),
        source_format="mei-basic",
        voice_policy=policy.value,
    )


def _load_root(source: Source) -> ET.Element:
    if isinstance(source, ET.Element):
        return source
    path = Path(source)
    try:
        return ET.parse(path).getroot()
    except ET.ParseError as exc:
        raise VoiceTopologyError(f"malformed XML: {exc}") from exc
    except OSError as exc:
        raise VoiceTopologyError(f"cannot read MEI input: {exc.strerror}") from exc


def _local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def _validate_global_source_xml_ids(root: ET.Element) -> None:
    """Vérifie une seule fois l'unicité globale des ``xml:id`` source."""
    seen: set[str] = set()
    for element in root.iter():
        raw = element.attrib.get(XML_ID)
        if raw is None or raw.strip() == "":
            continue
        if raw in seen:
            raise MusicalEventsError(f"duplicate source xml:id {raw!r}")
        seen.add(raw)


def _collect_staff_defs(root: ET.Element) -> list[ET.Element]:
    # Prefer staffDef under scoreDef/staffGrp (score topology).
    defs = root.findall(".//mei:scoreDef//mei:staffDef", NS)
    if not defs:
        defs = root.findall(".//mei:staffDef", NS)
    if not defs:
        raise VoiceTopologyError("no <staffDef> found under MEI score structure")
    return defs


def _parse_staff_n(raw: str | None, context: str) -> int:
    if raw is None or raw.strip() == "":
        raise VoiceTopologyError(f"missing staffDef@n ({context})")
    try:
        value = int(raw)
    except ValueError as exc:
        raise VoiceTopologyError(
            f"staffDef@n must be a positive integer, got {raw!r} ({context})"
        ) from exc
    if value < 1:
        raise VoiceTopologyError(
            f"staffDef@n must be a positive integer, got {value} ({context})"
        )
    return value


def _staff_def_clef_and_meter(
    staff_def: ET.Element, context: str
) -> tuple[InputClef | None, int | None, int | None]:
    clef_el = staff_def.find("mei:clef", NS)
    initial_clef: InputClef | None = None
    if clef_el is not None:
        shape = clef_el.attrib.get("shape")
        line_raw = clef_el.attrib.get("line")
        if shape is None or shape.strip() == "":
            raise VoiceTopologyError(f"{context}: clef missing @shape")
        if line_raw is None or line_raw.strip() == "":
            raise VoiceTopologyError(f"{context}: clef missing @line")
        try:
            line = int(line_raw)
        except ValueError as exc:
            raise VoiceTopologyError(
                f"{context}: clef@line must be an integer, got {line_raw!r}"
            ) from exc
        initial_clef = InputClef(shape=shape, line=line)

    meter_count = _optional_positive_int(
        staff_def.attrib.get("meter.count"), f"{context}: meter.count"
    )
    meter_unit = _optional_positive_int(
        staff_def.attrib.get("meter.unit"), f"{context}: meter.unit"
    )
    return initial_clef, meter_count, meter_unit


def _optional_positive_int(raw: str | None, context: str) -> int | None:
    if raw is None or raw.strip() == "":
        return None
    try:
        value = int(raw)
    except ValueError as exc:
        raise VoiceTopologyError(
            f"{context} must be a positive integer, got {raw!r}"
        ) from exc
    if value < 1:
        raise VoiceTopologyError(
            f"{context} must be a positive integer, got {value}"
        )
    return value


def _voices_from_staff_defs_three_voice_v1(
    staff_defs: list[ET.Element],
) -> tuple[Voice, ...]:
    seen_n: dict[int, str] = {}
    seen_names: dict[str, int] = {}
    voices: list[Voice] = []

    for index, staff_def in enumerate(staff_defs, start=1):
        context = f"staffDef #{index}"
        n = _parse_staff_n(staff_def.attrib.get("n"), context)
        if n in seen_n:
            raise VoiceTopologyError(
                f"duplicate staffDef@n={n} (already used by {seen_n[n]})"
            )

        label_el = staff_def.find("mei:label", NS)
        raw_label = label_el.text if label_el is not None else None
        name = normalize_voice_label(raw_label)
        if not name:
            raise VoiceTopologyError(f"missing or empty staffDef/label ({context})")
        if name not in VOICE_BY_NAME:
            raise VoiceTopologyError(f"unknown voice label {name!r}")
        if name in seen_names:
            raise VoiceTopologyError(
                f"duplicate voice label {name!r} (staffDef@n={seen_names[name]} and {n})"
            )

        spec = VOICE_BY_NAME[name]
        seen_n[n] = name
        seen_names[name] = n
        initial_clef, meter_count, meter_unit = _staff_def_clef_and_meter(
            staff_def, context
        )
        voices.append(
            Voice(
                identity=spec.identity,
                name=spec.name,
                source_staff_n=n,
                rank=spec.rank,
                output_mdiv_id=spec.output_mdiv_id,
                output_order_n=spec.output_order_n,
                initial_clef=initial_clef,
                meter_count=meter_count,
                meter_unit=meter_unit,
            )
        )

    return tuple(voices)


def _voices_from_staff_defs_source_order(
    staff_defs: list[ET.Element],
) -> tuple[Voice, ...]:
    if not staff_defs:
        raise VoiceTopologyError(
            f"SOURCE_ORDER_V1 expects at least 1 voice, got {len(staff_defs)}"
        )

    seen_n: dict[int, str] = {}
    seen_names: dict[str, int] = {}
    voices: list[Voice] = []

    for index, staff_def in enumerate(staff_defs, start=1):
        context = f"staffDef #{index}"
        n = _parse_staff_n(staff_def.attrib.get("n"), context)
        if n in seen_n:
            raise VoiceTopologyError(
                f"duplicate staffDef@n={n} (already used by {seen_n[n]})"
            )

        label_el = staff_def.find("mei:label", NS)
        raw_label = label_el.text if label_el is not None else None
        name = normalize_voice_label(raw_label)
        if not name:
            raise VoiceTopologyError(f"missing or empty staffDef/label ({context})")
        if name in seen_names:
            raise VoiceTopologyError(
                f"duplicate voice label {name!r} (staffDef@n={seen_names[name]} and {n})"
            )

        identity = f"voice-{index}"
        seen_n[n] = name
        seen_names[name] = n
        initial_clef, meter_count, meter_unit = _staff_def_clef_and_meter(
            staff_def, context
        )
        voices.append(
            Voice(
                identity=identity,
                name=name,
                source_staff_n=n,
                rank=index,
                output_mdiv_id=identity,
                output_order_n=str(index),
                initial_clef=initial_clef,
                meter_count=meter_count,
                meter_unit=meter_unit,
            )
        )

    return tuple(voices)


def _validate_expected_set_and_order(voices: tuple[Voice, ...]) -> None:
    names = tuple(voice.name for voice in voices)
    expected = EXPECTED_VOICE_ORDER

    missing = [name for name in expected if name not in names]
    if missing:
        raise VoiceTopologyError(
            f"missing required voice(s): {', '.join(missing)}"
        )

    extras = [name for name in names if name not in expected]
    if extras:
        raise VoiceTopologyError(
            f"unexpected voice(s): {', '.join(extras)}"
        )

    if len(voices) != len(expected):
        raise VoiceTopologyError(
            f"expected exactly {len(expected)} voices, got {len(voices)}"
        )

    if names != expected:
        raise VoiceTopologyError(
            "incorrect voice order: "
            f"got {' → '.join(names)}, expected {' → '.join(expected)}"
        )

    for voice, spec in zip(voices, THREE_VOICE_V1, strict=True):
        if voice.source_staff_n != spec.source_staff_n:
            raise VoiceTopologyError(
                f"staffDef@n for {voice.name!r} must be {spec.source_staff_n}, "
                f"got {voice.source_staff_n}"
            )


def _validate_measure_staff_refs(root: ET.Element, known_n: set[int]) -> None:
    for measure in root.findall(".//mei:measure", NS):
        measure_n = measure.attrib.get("n", "?")
        for staff in measure.findall("mei:staff", NS):
            raw = staff.attrib.get("n")
            if raw is None or raw.strip() == "":
                raise VoiceTopologyError(
                    f"measure n={measure_n}: staff without @n"
                )
            try:
                staff_n = int(raw)
            except ValueError as exc:
                raise VoiceTopologyError(
                    f"measure n={measure_n}: staff@n must be an integer, got {raw!r}"
                ) from exc
            if staff_n not in known_n:
                raise VoiceTopologyError(
                    f"measure n={measure_n}: staff@n={staff_n} has no matching staffDef"
                )


# ── J4 : mesures et événements ───────────────────────────────────────────────


def _read_measures(
    root: ET.Element, topology: VoiceTopologyDocument
) -> tuple[tuple[Measure, ...], tuple[InputTuplet, ...]]:
    measure_els = root.findall(".//mei:measure", NS)
    if not measure_els:
        raise MusicalEventsError("no <measure> found under MEI score structure")

    seen_n: set[int] = set()
    previous_n: int | None = None
    measures: list[Measure] = []
    tuplets: list[InputTuplet] = []
    seen_xml_ids: set[str] = set()

    for measure_el in measure_els:
        measure_n = _parse_measure_n(measure_el.attrib.get("n"))
        if measure_n in seen_n:
            raise MusicalEventsError(f"duplicate measure@n={measure_n}")
        if previous_n is not None and measure_n <= previous_n:
            raise MusicalEventsError(
                f"measure numbers must be strictly increasing: "
                f"got {measure_n} after {previous_n}"
            )
        # Contiguity is not required (gaps allowed); only uniqueness + order.
        seen_n.add(measure_n)
        previous_n = measure_n

        voices, measure_tuplets = _read_measure_voices(
            measure_el, measure_n, topology, seen_xml_ids
        )
        measures.append(Measure(n=measure_n, voices=voices))
        tuplets.extend(measure_tuplets)

    return tuple(measures), tuple(tuplets)


def _parse_measure_n(raw: str | None) -> int:
    if raw is None or raw.strip() == "":
        raise MusicalEventsError("missing measure@n")
    try:
        value = int(raw)
    except ValueError as exc:
        raise MusicalEventsError(
            f"measure@n must be a positive integer, got {raw!r}"
        ) from exc
    if value < 1:
        raise MusicalEventsError(
            f"measure@n must be a positive integer, got {value}"
        )
    return value


def _read_measure_voices(
    measure_el: ET.Element,
    measure_n: int,
    topology: VoiceTopologyDocument,
    seen_xml_ids: set[str],
) -> tuple[tuple[VoiceMeasureContent, ...], list[InputTuplet]]:
    staff_els = measure_el.findall("mei:staff", NS)
    by_n: dict[int, ET.Element] = {}
    for staff_el in staff_els:
        raw = staff_el.attrib.get("n")
        if raw is None or raw.strip() == "":
            raise MusicalEventsError(f"measure n={measure_n}: staff without @n")
        try:
            staff_n = int(raw)
        except ValueError as exc:
            raise MusicalEventsError(
                f"measure n={measure_n}: staff@n must be an integer, got {raw!r}"
            ) from exc
        if staff_n in by_n:
            raise MusicalEventsError(
                f"measure n={measure_n}: duplicate staff@n={staff_n}"
            )
        by_n[staff_n] = staff_el

    expected = {voice.source_staff_n for voice in topology.voices}
    missing = sorted(expected - set(by_n))
    if missing:
        raise MusicalEventsError(
            f"measure n={measure_n}: missing staff@n={', '.join(map(str, missing))}"
        )
    unknown = sorted(set(by_n) - expected)
    if unknown:
        raise MusicalEventsError(
            f"measure n={measure_n}: unknown staff@n={', '.join(map(str, unknown))}"
        )

    contents: list[VoiceMeasureContent] = []
    tuplets: list[InputTuplet] = []
    for voice in topology.voices_in_order():
        staff_el = by_n[voice.source_staff_n]
        content, voice_tuplets = _read_voice_measure_content(
            staff_el, voice, measure_n, seen_xml_ids
        )
        contents.append(content)
        tuplets.extend(voice_tuplets)
    return tuple(contents), tuplets


def _read_voice_measure_content(
    staff_el: ET.Element,
    voice: Voice,
    measure_n: int,
    seen_xml_ids: set[str],
) -> tuple[VoiceMeasureContent, list[InputTuplet]]:
    layers = staff_el.findall("mei:layer", NS)
    context = (
        f"measure n={measure_n}, staff@n={voice.source_staff_n}, "
        f"voice={voice.identity}"
    )
    if not layers:
        raise MusicalEventsError(f"{context}: missing <layer>")
    if len(layers) > 1:
        raise MusicalEventsError(
            f"{context}: expected exactly one <layer>, got {len(layers)}"
        )

    layer_el = layers[0]
    layer_n = _parse_layer_n(layer_el.attrib.get("n"), context)
    if layer_n != EXPECTED_LAYER_N:
        raise MusicalEventsError(
            f"{context}: layer@n must be {EXPECTED_LAYER_N}, got {layer_n}"
        )

    events, tuplets = _read_layer_events(
        layer_el, context, seen_xml_ids, voice.identity, measure_n
    )
    content = VoiceMeasureContent(
        voice_identity=voice.identity,
        source_staff_n=voice.source_staff_n,
        layer_n=layer_n,
        measure_n=measure_n,
        events=events,
    )
    return content, tuplets


def _parse_layer_n(raw: str | None, context: str) -> int:
    if raw is None or raw.strip() == "":
        raise MusicalEventsError(f"{context}: missing layer@n")
    try:
        value = int(raw)
    except ValueError as exc:
        raise MusicalEventsError(
            f"{context}: layer@n must be a positive integer, got {raw!r}"
        ) from exc
    if value < 1:
        raise MusicalEventsError(
            f"{context}: layer@n must be a positive integer, got {value}"
        )
    return value


def _read_layer_events(
    layer_el: ET.Element,
    context: str,
    seen_xml_ids: set[str],
    voice_identity: str,
    measure_n: int,
) -> tuple[tuple[MusicalEvent, ...], list[InputTuplet]]:
    events: list[MusicalEvent] = []
    tuplets: list[InputTuplet] = []
    ordinal = 0

    for child in list(layer_el):
        name = _local(child.tag)
        if name == "beam":
            for nested in _flatten_beam(child, context):
                ordinal += 1
                events.append(
                    _event_from_element(nested, ordinal, context, seen_xml_ids)
                )
        elif name == "tuplet":
            nested_events = _flatten_tuplet(child, context)
            if not nested_events:
                raise MusicalEventsError(f"{context}: empty <tuplet>")
            member_addresses: list[InputEventAddress] = []
            first_ordinal = ordinal + 1
            for nested in nested_events:
                ordinal += 1
                event = _event_from_element(
                    nested, ordinal, context, seen_xml_ids
                )
                events.append(event)
                member_addresses.append(
                    InputEventAddress(
                        voice_identity=voice_identity,
                        measure_n=measure_n,
                        ordinal=ordinal,
                        event_kind=_event_kind(event),
                    )
                )
            del first_ordinal
            tuplets.append(
                _tuplet_from_element(child, tuple(member_addresses), context)
            )
        elif name in ("note", "rest", "mRest"):
            ordinal += 1
            events.append(
                _event_from_element(child, ordinal, context, seen_xml_ids)
            )
        elif name == "clef":
            events.append(_read_inline_clef(child, context, seen_xml_ids))
        else:
            raise MusicalEventsError(
                f"{context}: unsupported rhythmic element <{name}>"
            )

    _validate_mrest_exclusivity(events, context)
    return tuple(events), tuplets


def _flatten_beam(beam_el: ET.Element, context: str) -> list[ET.Element]:
    flattened: list[ET.Element] = []
    for child in list(beam_el):
        name = _local(child.tag)
        if name in ("note", "rest", "mRest"):
            flattened.append(child)
        else:
            raise MusicalEventsError(
                f"{context}: unsupported content inside <beam>: <{name}>"
            )
    if not flattened:
        raise MusicalEventsError(f"{context}: empty <beam>")
    return flattened


def _flatten_tuplet(tuplet_el: ET.Element, context: str) -> list[ET.Element]:
    flattened: list[ET.Element] = []
    for child in list(tuplet_el):
        name = _local(child.tag)
        if name in ("note", "rest", "mRest"):
            flattened.append(child)
        elif name == "beam":
            flattened.extend(_flatten_beam(child, context))
        else:
            raise MusicalEventsError(
                f"{context}: unsupported content inside <tuplet>: <{name}>"
            )
    return flattened


def _tuplet_from_element(
    el: ET.Element,
    member_addresses: tuple[InputEventAddress, ...],
    context: str,
) -> InputTuplet:
    source_xml_id = el.attrib.get(XML_ID)
    if source_xml_id is None or source_xml_id.strip() == "":
        raise MusicalEventsError(f"{context}: <tuplet> missing xml:id")
    num = _require_positive_int_attr(el.attrib.get("num"), context, "num")
    numbase = _require_positive_int_attr(
        el.attrib.get("numbase"), context, "numbase"
    )
    return InputTuplet(
        num=num,
        numbase=numbase,
        member_addresses=member_addresses,
        source_xml_id=source_xml_id,
    )


def _require_positive_int_attr(
    raw: str | None, context: str, attr: str
) -> int:
    if raw is None or raw.strip() == "":
        raise MusicalEventsError(f"{context}: <tuplet> missing @{attr}")
    try:
        value = int(raw)
    except ValueError as exc:
        raise MusicalEventsError(
            f"{context}: tuplet@{attr} must be a positive integer, got {raw!r}"
        ) from exc
    if value < 1:
        raise MusicalEventsError(
            f"{context}: tuplet@{attr} must be a positive integer, got {value}"
        )
    return value


def _validate_mrest_exclusivity(
    events: list[MusicalEvent], context: str
) -> None:
    rhythmic = [event for event in events if is_rhythmic_event(event)]
    mrest_count = sum(1 for event in rhythmic if isinstance(event, InputMeasureRest))
    if mrest_count == 0:
        return
    if mrest_count > 1 or len(rhythmic) != 1:
        raise MusicalEventsError(
            f"{context}: <mRest> must be the sole rhythmic event of its layer"
        )


def _event_from_element(
    el: ET.Element,
    ordinal: int,
    context: str,
    seen_xml_ids: set[str],
) -> MusicalEvent:
    name = _local(el.tag)
    source_xml_id = _require_source_xml_id(el, context, name, seen_xml_ids)

    if name == "note":
        written, gestural = _read_note_accidentals(el, context)
        return InputNote(
            ordinal=ordinal,
            pname=_parse_pname(el.attrib.get("pname"), context),
            oct=_parse_oct(el.attrib.get("oct"), context),
            dur=_parse_dur(el.attrib.get("dur"), context, kind="note"),
            dots=_parse_dots(el.attrib.get("dots"), context),
            source_xml_id=source_xml_id,
            lyrics=_read_lyrics(el, context),
            written_accidental=written,
            gestural_accidental=gestural,
        )
    if name == "rest":
        # type="mscore-beam-none" is a MuseScore technical marker: ignored.
        return InputRest(
            ordinal=ordinal,
            dur=_parse_dur(el.attrib.get("dur"), context, kind="rest"),
            dots=_parse_dots(el.attrib.get("dots"), context),
            source_xml_id=source_xml_id,
        )
    if name == "mRest":
        return InputMeasureRest(ordinal=ordinal, source_xml_id=source_xml_id)

    raise MusicalEventsError(
        f"{context}: unsupported rhythmic element <{name}>"
    )


def _read_inline_clef(
    el: ET.Element,
    context: str,
    seen_xml_ids: set[str],
) -> InputInlineClef:
    source_xml_id = _require_source_xml_id(el, context, "clef", seen_xml_ids)
    extra = [key for key in el.attrib if key not in {XML_ID, "shape", "line"}]
    if extra:
        raise MusicalEventsError(
            f"{context}: unsupported <clef> attribute {extra[0]!r}"
        )
    if list(el):
        raise MusicalEventsError(f"{context}: <clef> must be empty")
    shape = el.attrib.get("shape")
    line_raw = el.attrib.get("line")
    if shape is None or shape.strip() == "":
        raise MusicalEventsError(f"{context}: <clef> missing @shape")
    if line_raw is None or line_raw.strip() == "":
        raise MusicalEventsError(f"{context}: <clef> missing @line")
    try:
        line = int(line_raw)
    except ValueError as exc:
        raise MusicalEventsError(
            f"{context}: clef@line must be an integer, got {line_raw!r}"
        ) from exc
    if line < 1:
        raise MusicalEventsError(
            f"{context}: clef@line must be a positive integer, got {line}"
        )
    return InputInlineClef(
        clef=InputClef(shape=shape, line=line),
        source_xml_id=source_xml_id,
    )


def _read_lyrics(
    note_el: ET.Element, context: str
) -> tuple[InputLyricSyllable, ...]:
    syllables: list[InputLyricSyllable] = []
    for verse in note_el.findall("mei:verse", NS):
        verse_n = _optional_int_attr(verse.attrib.get("n"), context, "verse@n")
        verse_xml_id = verse.attrib.get(XML_ID)
        for syl in verse.findall("mei:syl", NS):
            syllables.append(
                InputLyricSyllable(
                    text="".join(syl.itertext()),
                    verse_n=verse_n,
                    wordpos=syl.attrib.get("wordpos"),
                    con=syl.attrib.get("con"),
                    source_xml_id=syl.attrib.get(XML_ID) or verse_xml_id,
                )
            )
    # Also accept direct <syl> under note if present.
    for syl in note_el.findall("mei:syl", NS):
        syllables.append(
            InputLyricSyllable(
                text="".join(syl.itertext()),
                verse_n=None,
                wordpos=syl.attrib.get("wordpos"),
                con=syl.attrib.get("con"),
                source_xml_id=syl.attrib.get(XML_ID),
            )
        )
    return tuple(syllables)


def _read_note_accidentals(
    note_el: ET.Element, context: str
) -> tuple[InputWrittenAccidental | None, InputGesturalAccidental | None]:
    accids = note_el.findall("mei:accid", NS)
    if not accids:
        return None, None
    if len(accids) > 1:
        raise MusicalEventsError(
            f"{context}: note has multiple <accid> children"
        )
    accid_el = accids[0]
    written_raw = accid_el.attrib.get("accid")
    ges_raw = accid_el.attrib.get("accid.ges")
    enclose = accid_el.attrib.get("enclose")
    written_value = written_raw.strip() if written_raw and written_raw.strip() else None
    ges_value = ges_raw.strip() if ges_raw and ges_raw.strip() else None
    if written_value is None and ges_value is None:
        raise MusicalEventsError(f"{context}: <accid> missing @accid")
    if enclose is not None and enclose != "paren":
        raise MusicalEventsError(
            f"{context}: unsupported accid@enclose {enclose!r}"
        )
    xml_id = accid_el.attrib.get(XML_ID)
    written: InputWrittenAccidental | None = None
    gestural: InputGesturalAccidental | None = None
    if written_value is not None:
        written = InputWrittenAccidental(
            accid=written_value,
            source_xml_id=xml_id,
            enclose=enclose,
        )
    elif enclose is not None:
        raise MusicalEventsError(
            f"{context}: accid@enclose requires written @accid"
        )
    if ges_value is not None:
        gestural = InputGesturalAccidental(
            accid_ges=ges_value,
            source_xml_id=xml_id,
        )
    return written, gestural


def _optional_int_attr(
    raw: str | None, context: str, label: str
) -> int | None:
    if raw is None or raw.strip() == "":
        return None
    try:
        return int(raw)
    except ValueError as exc:
        raise MusicalEventsError(
            f"{context}: {label} must be an integer, got {raw!r}"
        ) from exc


def _require_source_xml_id(
    el: ET.Element, context: str, kind: str, seen_xml_ids: set[str]
) -> str:
    raw = el.attrib.get(XML_ID)
    if raw is None or raw.strip() == "":
        raise MusicalEventsError(
            f"{context}: <{kind}> missing xml:id source reference"
        )
    if raw in seen_xml_ids:
        raise MusicalEventsError(
            f"{context}: duplicate source xml:id {raw!r}"
        )
    seen_xml_ids.add(raw)
    return raw


def _parse_pname(raw: str | None, context: str) -> str:
    if raw is None or raw.strip() == "":
        raise MusicalEventsError(f"{context}: note missing @pname")
    if raw not in ACCEPTED_PNAMES:
        raise MusicalEventsError(
            f"{context}: invalid note@pname {raw!r} (expected a–g)"
        )
    return raw


def _parse_oct(raw: str | None, context: str) -> int:
    if raw is None or raw.strip() == "":
        raise MusicalEventsError(f"{context}: note missing @oct")
    try:
        return int(raw)
    except ValueError as exc:
        raise MusicalEventsError(
            f"{context}: note@oct must be an integer, got {raw!r}"
        ) from exc


def _parse_dur(raw: str | None, context: str, *, kind: str) -> str:
    if raw is None or raw.strip() == "":
        raise MusicalEventsError(f"{context}: {kind} missing @dur")
    if raw not in ACCEPTED_CMN_DURS:
        accepted = ", ".join(
            sorted(
                ACCEPTED_CMN_DURS,
                key=lambda item: (0, int(item)) if item.isdigit() else (1, item),
            )
        )
        raise MusicalEventsError(
            f"{context}: invalid {kind}@dur {raw!r} "
            f"(accepted CMN: {accepted})"
        )
    return raw


def _parse_dots(raw: str | None, context: str) -> int:
    if raw is None or raw.strip() == "":
        return 0
    try:
        value = int(raw)
    except ValueError as exc:
        raise MusicalEventsError(
            f"{context}: @dots must be a non-negative integer, got {raw!r}"
        ) from exc
    if value < 0:
        raise MusicalEventsError(
            f"{context}: @dots must be a non-negative integer, got {value}"
        )
    return value


# ── J5 : signaux source ───────────────────────────────────────────────────────


def _event_kind(event: MusicalEvent) -> str:
    if isinstance(event, InputNote):
        return "note"
    if isinstance(event, InputRest):
        return "rest"
    if isinstance(event, InputMeasureRest):
        return "mRest"
    raise SourceSignalsError(f"unsupported event type {type(event)!r}")


def _build_event_index(
    measures: tuple[Measure, ...]
) -> dict[str, InputEventAddress]:
    index: dict[str, InputEventAddress] = {}
    for measure in measures:
        for content in measure.voices:
            for event in content.events:
                if not is_rhythmic_event(event):
                    continue
                address = InputEventAddress(
                    voice_identity=content.voice_identity,
                    measure_n=content.measure_n,
                    ordinal=event.ordinal,
                    event_kind=_event_kind(event),
                )
                index[event.source_xml_id] = address
    return index


def _read_signals(
    root: ET.Element, measures: tuple[Measure, ...]
) -> tuple[InputSignal, ...]:
    event_index = _build_event_index(measures)
    carrier_ids: set[str] = set()
    signals: list[InputSignal] = []

    for measure_el in root.findall(".//mei:measure", NS):
        measure_n = _parse_measure_n(measure_el.attrib.get("n"))
        for child in list(measure_el):
            name = _local(child.tag)
            if name not in SIGNAL_TAGS:
                continue
            context = f"measure n={measure_n}, <{name}>"
            source_xml_id = _require_carrier_xml_id(
                child, context, carrier_ids, event_index
            )
            if name == "dir":
                signals.append(
                    _read_dir_signal(
                        child, measure_n, source_xml_id, event_index
                    )
                )
            elif name == "pedal":
                signals.append(
                    _read_pedal_span(
                        child, measure_n, source_xml_id, event_index
                    )
                )
            else:
                signals.append(
                    _read_tie_span(
                        child, measure_n, source_xml_id, event_index
                    )
                )

    return tuple(signals)


def _require_carrier_xml_id(
    el: ET.Element,
    context: str,
    carrier_ids: set[str],
    event_index: dict[str, InputEventAddress],
) -> str:
    raw = el.attrib.get(XML_ID)
    if raw is None or raw.strip() == "":
        raise SourceSignalsError(f"{context}: missing xml:id")
    if raw in carrier_ids:
        raise SourceSignalsError(
            f"{context}: duplicate signal xml:id {raw!r}"
        )
    if raw in event_index:
        raise SourceSignalsError(
            f"{context}: signal xml:id {raw!r} collides with an event "
            "source reference"
        )
    carrier_ids.add(raw)
    return raw


def _parse_idref(raw: str | None, context: str, *, attr: str) -> str:
    if raw is None or raw.strip() == "":
        raise SourceSignalsError(f"{context}: missing or empty @{attr}")
    if any(ch.isspace() for ch in raw):
        raise SourceSignalsError(
            f"{context}: @{attr} must be a single local IDREF, got {raw!r}"
        )
    if "://" in raw:
        raise SourceSignalsError(
            f"{context}: @{attr} must not be an external URI, got {raw!r}"
        )
    if not raw.startswith("#"):
        raise SourceSignalsError(
            f"{context}: @{attr} must start with '#', got {raw!r}"
        )
    target = raw[1:]
    if target == "":
        raise SourceSignalsError(f"{context}: @{attr} has empty target after '#'")
    if "://" in target:
        raise SourceSignalsError(
            f"{context}: @{attr} must not be an external URI, got {raw!r}"
        )
    return target


def _resolve_event_address(
    target_id: str,
    context: str,
    event_index: dict[str, InputEventAddress],
) -> InputEventAddress:
    address = event_index.get(target_id)
    if address is None:
        raise SourceSignalsError(
            f"{context}: unresolved IDREF target {target_id!r} "
            "(expected a rhythmic event)"
        )
    return address


def _read_dir_signal(
    el: ET.Element,
    carrier_measure_n: int,
    source_xml_id: str,
    event_index: dict[str, InputEventAddress],
) -> InputStaffTextSignal:
    context = f"measure n={carrier_measure_n}, <dir> xml:id={source_xml_id!r}"
    dir_type = el.attrib.get("type")
    if dir_type != STAFF_TEXT_TYPE:
        raise SourceSignalsError(
            f"{context}: unsupported dir@type {dir_type!r} "
            f"(expected {STAFF_TEXT_TYPE!r})"
        )
    if "endid" in el.attrib:
        raise SourceSignalsError(
            f"{context}: unexpected @endid on <dir>"
        )

    start_id = _parse_idref(el.attrib.get("startid"), context, attr="startid")
    anchor = _resolve_event_address(start_id, context, event_index)
    if anchor.measure_n != carrier_measure_n:
        raise SourceSignalsError(
            f"{context}: carrier measure {carrier_measure_n} differs from "
            f"anchor measure {anchor.measure_n}"
        )

    source_text = "".join(el.itertext())
    parsed = parse_staff_text(source_text)
    return InputStaffTextSignal(
        source_xml_id=source_xml_id,
        carrier_measure_n=carrier_measure_n,
        anchor=anchor,
        source_text=parsed.source_text,
        lexical_prefix=parsed.lexical_prefix,
        place=el.attrib.get("place"),
    )


def _read_span_endpoints(
    el: ET.Element,
    carrier_measure_n: int,
    source_xml_id: str,
    tag: str,
    event_index: dict[str, InputEventAddress],
) -> tuple[InputEventAddress, InputEventAddress]:
    context = (
        f"measure n={carrier_measure_n}, <{tag}> xml:id={source_xml_id!r}"
    )
    start_id = _parse_idref(el.attrib.get("startid"), context, attr="startid")
    end_id = _parse_idref(el.attrib.get("endid"), context, attr="endid")
    start = _resolve_event_address(start_id, context, event_index)
    end = _resolve_event_address(end_id, context, event_index)

    if start_id == end_id:
        raise SourceSignalsError(
            f"{context}: start and end must be distinct"
        )
    if start.voice_identity != end.voice_identity:
        raise SourceSignalsError(
            f"{context}: span endpoints must belong to the same voice "
            f"(got {start.voice_identity!r} and {end.voice_identity!r})"
        )
    if not (
        (start.measure_n, start.ordinal) < (end.measure_n, end.ordinal)
    ):
        raise SourceSignalsError(
            f"{context}: span start must strictly precede end"
        )
    if start.measure_n != carrier_measure_n:
        raise SourceSignalsError(
            f"{context}: carrier measure {carrier_measure_n} differs from "
            f"start measure {start.measure_n}"
        )
    return start, end


def _read_pedal_span(
    el: ET.Element,
    carrier_measure_n: int,
    source_xml_id: str,
    event_index: dict[str, InputEventAddress],
) -> InputPedalSpan:
    start, end = _read_span_endpoints(
        el, carrier_measure_n, source_xml_id, "pedal", event_index
    )
    return InputPedalSpan(
        source_xml_id=source_xml_id,
        carrier_measure_n=carrier_measure_n,
        start=start,
        end=end,
        pedal_dir=el.attrib.get("dir"),
        form=el.attrib.get("form"),
    )


def _read_tie_span(
    el: ET.Element,
    carrier_measure_n: int,
    source_xml_id: str,
    event_index: dict[str, InputEventAddress],
) -> InputTieSpan:
    start, end = _read_span_endpoints(
        el, carrier_measure_n, source_xml_id, "tie", event_index
    )
    return InputTieSpan(
        source_xml_id=source_xml_id,
        carrier_measure_n=carrier_measure_n,
        start=start,
        end=end,
    )
