"""Écriture sibling MEI CMN + mensural depuis les modèles J7.2."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from mei_scribe.io.errors import WriterError
from mei_scribe.io.writer_cmn import serialize_cmn_document
from mei_scribe.io.writer_mensural import serialize_mensural_document
from mei_scribe.transform.model import TransformationBundle
from mei_scribe.validation.checks import (
    validate_cmn_mei_bytes,
    validate_mensural_mei_bytes,
)


@dataclass(frozen=True)
class OutputFileNames:
    """Noms déterministes ``*.cmn.mei`` / ``*.mensural.mei``."""

    cmn_name: str
    mensural_name: str


@dataclass(frozen=True)
class WrittenOutputs:
    """Chemins des deux sorties sibling écrites sur disque."""

    cmn_path: Path
    mensural_path: Path


@dataclass(frozen=True)
class SerializedOutputs:
    """Bytes MEI sibling sérialisés et validés."""

    cmn_mei: bytes
    mensural_mei: bytes


def sibling_output_names(source_name: str) -> OutputFileNames:
    """Noms déterministes suggérés pour les deux sorties sibling."""
    stem = source_name
    if stem.lower().endswith(".mei"):
        stem = stem[:-4]
    return OutputFileNames(
        cmn_name=f"{stem}.cmn.mei",
        mensural_name=f"{stem}.mensural.mei",
    )


def default_output_paths(input_path: Path, out_dir: Path) -> WrittenOutputs:
    """Chemins déterministes ``*.cmn.mei`` / ``*.mensural.mei``."""
    names = sibling_output_names(input_path.name)
    return WrittenOutputs(
        cmn_path=out_dir / names.cmn_name,
        mensural_path=out_dir / names.mensural_name,
    )


def serialize_transformation_bundle(bundle: TransformationBundle) -> SerializedOutputs:
    """Sérialise et valide les deux sorties sibling en mémoire."""
    cmn_bytes = serialize_cmn_document(bundle.cmn)
    mensural_bytes = serialize_mensural_document(bundle.mensural)
    validate_cmn_mei_bytes(cmn_bytes)
    validate_mensural_mei_bytes(mensural_bytes)
    return SerializedOutputs(cmn_mei=cmn_bytes, mensural_mei=mensural_bytes)


def write_transformation_bundle(
    bundle: TransformationBundle,
    *,
    input_path: Path | str,
    out_dir: Path | str | None = None,
) -> WrittenOutputs:
    """Sérialise, valide, puis écrit les deux sorties sibling.

    Aucune création de répertoire ni écriture disque n'a lieu avant
    validation réussie des deux bytes.
    """
    source = Path(input_path)
    target_dir = Path(out_dir) if out_dir is not None else source.parent
    outputs = default_output_paths(source, target_dir)
    serialized = serialize_transformation_bundle(bundle)

    target_dir.mkdir(parents=True, exist_ok=True)
    _atomic_write_pair(
        (outputs.cmn_path, serialized.cmn_mei),
        (outputs.mensural_path, serialized.mensural_mei),
    )
    return outputs


def _atomic_write_pair(
    first: tuple[Path, bytes],
    second: tuple[Path, bytes],
) -> None:
    temps: list[Path] = []
    try:
        for path, payload in (first, second):
            temp = path.with_name(path.name + ".partial")
            temps.append(temp)
            temp.write_bytes(payload)
        for temp, (path, _) in zip(temps, (first, second), strict=True):
            os.replace(temp, path)
    except Exception as exc:
        for temp in temps:
            if temp.exists():
                temp.unlink()
        raise WriterError(f"failed to write MEI outputs: {exc}") from exc
