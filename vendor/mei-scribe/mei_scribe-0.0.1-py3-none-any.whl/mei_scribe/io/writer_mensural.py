"""Sérialisation MEI mensurale depuis ``MensuralDocument`` (J7.3 / Phase 6C1)."""

from __future__ import annotations

import xml.etree.ElementTree as ET
from dataclasses import dataclass

from mei_scribe.io.errors import WriterError
from mei_scribe.io.mei_builder import (
    MENSURAL_MEIVERSION,
    MENSURAL_RNG,
    append_anchored_text,
    append_lyrics,
    append_written_accidental,
    build_mei_head,
    build_mei_root,
    format_anchored_text_anchor,
    serialize_mei_document,
    set_xml_id,
    sub,
)
from mei_scribe.transform.model import (
    MensuralClef,
    MensuralClefGroup,
    MensuralDocument,
    MensuralInlineClef,
    MensuralLigature,
    MensuralNote,
    MensuralRest,
    MensuralVoice,
    OutputAnchoredText,
    SourceSystemBoundary,
)
from mei_scribe.transform.source_systems import (
    CUSTOS_KIND,
    section_start_index_for_boundary,
)


@dataclass(frozen=True)
class _ResolvedMensuralAnchoredText:
    """Cible mensurale résolue par provenance pour un ``OutputAnchoredText``."""

    anchored: OutputAnchoredText
    note: MensuralNote
    voice: MensuralVoice
    startid: str
    xml_id: str


@dataclass(frozen=True)
class _VoiceSegment:
    """Slice of ``voice.events`` for one score-level ``<section>``."""

    start_index: int
    end_index: int
    boundary: SourceSystemBoundary | None
    """Boundary that opens this segment (None for the leading pre-boundary slice)."""


def serialize_mensural_document(document: MensuralDocument) -> bytes:
    """Sérialise un ``MensuralDocument`` en MEI mensural déterministe."""
    root = build_mei_root(MENSURAL_MEIVERSION, "mensural-document")
    build_mei_head(root, document.metadata)
    music = sub(root, "music")
    body = sub(music, "body")

    resolved_anchored = _resolve_anchored_texts(document)
    emitted_anchored: set[str] = set()
    for voice in document.voices:
        _validate_voice_ligatures(voice)
        mdiv = sub(body, "mdiv", n=str(voice.rank))
        set_xml_id(mdiv, f"mensural-mdiv-v{voice.rank}")
        score = sub(mdiv, "score")
        _build_score_def(score, document, voice)
        emitted_anchored.update(
            _emit_voice_score(score, voice, document, resolved_anchored)
        )

    missing = [
        item
        for item in resolved_anchored
        if item.xml_id not in emitted_anchored
    ]
    if missing:
        raise WriterError(
            "anchored text resolved but not emitted: "
            f"{format_anchored_text_anchor(missing[0].anchored)}"
        )

    return serialize_mei_document(root, MENSURAL_RNG)


def _resolve_anchored_texts(
    document: MensuralDocument,
) -> tuple[_ResolvedMensuralAnchoredText, ...]:
    used_ids: dict[str, int] = {}
    resolved: list[_ResolvedMensuralAnchoredText] = []
    for anchored in document.anchored_texts:
        located: list[tuple[MensuralVoice, object]] = []
        for voice in document.voices:
            for event in voice.events:
                if anchored.anchor in event.provenance.source_addresses:
                    located.append((voice, event))

        if not located:
            raise WriterError(
                "anchored text target unresolved: "
                f"{format_anchored_text_anchor(anchored)}"
            )
        if len(located) > 1:
            raise WriterError(
                "anchored text target ambiguous: "
                f"{format_anchored_text_anchor(anchored)} "
                f"matches={len(located)}"
            )

        voice, event = located[0]
        if anchored.func == "voiceIncipit" and not isinstance(event, MensuralNote):
            raise WriterError(
                "voiceIncipit target must be a mensural note: "
                f"{format_anchored_text_anchor(anchored)}"
            )
        if not isinstance(event, MensuralNote):
            raise WriterError(
                "anchored text target must be a mensural note: "
                f"{format_anchored_text_anchor(anchored)}"
            )

        base_id = f"mensural-anchored-v{voice.rank}-e{event.ordinal}"
        used_ids[base_id] = used_ids.get(base_id, 0) + 1
        xml_id = (
            base_id
            if used_ids[base_id] == 1
            else f"{base_id}-{used_ids[base_id]}"
        )
        resolved.append(
            _ResolvedMensuralAnchoredText(
                anchored=anchored,
                note=event,
                voice=voice,
                startid=f"mensural-v{voice.rank}-e{event.ordinal}",
                xml_id=xml_id,
            )
        )
    return tuple(resolved)


def _build_score_def(
    score: ET.Element, document: MensuralDocument, voice: MensuralVoice
) -> None:
    meta = document.metadata
    if meta.notation_type is None:
        raise WriterError("missing notation_type for mensural scoreDef")
    if meta.modusminor is None or meta.tempus is None or meta.prolatio is None:
        raise WriterError("missing mensuration for mensural scoreDef")
    if meta.mensur_in_source is not False:
        raise WriterError(
            "J7.3 refuses to invent visible mensuration signs when "
            "mensur_in_source is not false"
        )
    staff_def = sub(score, "scoreDef")
    staff_grp = sub(staff_def, "staffGrp")
    staff = sub(
        staff_grp,
        "staffDef",
        n="1",
        lines="5",
        notationtype=meta.notation_type,
        modusminor=str(meta.modusminor),
        tempus=str(meta.tempus),
        prolatio=str(meta.prolatio),
    )
    set_xml_id(staff, f"mensural-staffdef-v{voice.rank}")
    label = sub(staff, "label")
    label.text = voice.name
    if isinstance(voice.clefs, MensuralClef):
        sub(staff, "clef", shape=voice.clefs.shape, line=str(voice.clefs.line))
    elif not isinstance(voice.clefs, MensuralClefGroup):
        raise WriterError(f"voice {voice.identity!r} has no mensural clefs")


def _emit_clef_group_in_layer(layer: ET.Element, voice: MensuralVoice) -> None:
    """Serialize a semantic clefGrp as one native layer ``<clefGrp>``."""
    group = voice.clefs
    if not isinstance(group, MensuralClefGroup):
        raise WriterError(
            f"voice {voice.identity!r} has no mensural clef group to emit"
        )
    grp_el = sub(layer, "clefGrp")
    set_xml_id(grp_el, f"mensural-clefgrp-v{voice.rank}")
    for clef in group.members:
        clef_el = sub(grp_el, "clef", shape=clef.shape, line=str(clef.line))
        set_xml_id(
            clef_el,
            f"mensural-clef-v{voice.rank}-{clef.shape.lower()}{clef.line}",
        )


def _validate_voice_ligatures(voice: MensuralVoice) -> None:
    note_ordinals = {
        event.ordinal
        for event in voice.events
        if isinstance(event, MensuralNote)
    }
    occupied: set[int] = set()
    for ligature in voice.ligatures:
        if len(ligature.member_ordinals) < 2:
            raise WriterError("ligature must contain at least two members")
        if len(ligature.member_ordinals) != len(ligature.effective_forms):
            raise WriterError(
                "ligature member count does not match effective forms"
            )
        if ligature.member_ordinals != tuple(sorted(ligature.member_ordinals)):
            raise WriterError("ligature members are not strictly ordered")
        if len(set(ligature.member_ordinals)) != len(ligature.member_ordinals):
            raise WriterError("ligature has duplicated members")
        for ordinal in ligature.member_ordinals:
            if ordinal not in note_ordinals:
                raise WriterError(
                    f"ligature member ordinal {ordinal} absent in voice "
                    f"{voice.identity!r}"
                )
            if ordinal in occupied:
                raise WriterError(
                    f"overlapping ligatures at ordinal {ordinal} in voice "
                    f"{voice.identity!r}"
                )
            occupied.add(ordinal)
        event_positions = {
            event.ordinal: index
            for index, event in enumerate(voice.events)
            if not isinstance(event, MensuralInlineClef)
        }
        positions = [event_positions[ordinal] for ordinal in ligature.member_ordinals]
        for left, right in zip(positions, positions[1:]):
            if right != left + 1:
                raise WriterError(
                    f"ligature members are not contiguous in voice "
                    f"{voice.identity!r}"
                )


def _section_start_index_for_writer(
    boundary: SourceSystemBoundary,
    mensural: MensuralDocument,
) -> int:
    """Locate section start for an already-validated boundary (writer path)."""
    from mei_scribe.transform.errors import SemanticTransformError

    try:
        return section_start_index_for_boundary(boundary, mensural)
    except SemanticTransformError as exc:
        raise WriterError(
            f"source-system-boundary not representable at write time: {exc}"
        ) from exc


def _build_voice_segments(
    voice: MensuralVoice,
    mensural: MensuralDocument,
) -> list[_VoiceSegment]:
    """Partition ``voice.events`` into score-level section slices."""
    voice_bounds = [
        b
        for b in mensural.source_system_boundaries
        if b.anchor.voice_identity == voice.identity
    ]
    n_events = len(voice.events)
    if not voice_bounds:
        return [_VoiceSegment(0, n_events, None)]

    starts: list[tuple[int, SourceSystemBoundary]] = []
    for boundary in voice_bounds:
        start = _section_start_index_for_writer(boundary, mensural)
        starts.append((start, boundary))

    starts.sort(key=lambda item: item[0])
    for left, right in zip(starts, starts[1:]):
        if left[0] == right[0]:
            raise WriterError(
                "source-system-boundary-section-start-collision: "
                f"voice={voice.identity!r} start_index={left[0]}"
            )
        if left[1].document_order > right[1].document_order:
            raise WriterError(
                "source-system-boundary-order-conflict: "
                f"voice={voice.identity!r} "
                f"document_order={left[1].document_order}->{right[1].document_order} "
                f"conflicts with event order"
            )

    segments: list[_VoiceSegment] = []
    first_start = starts[0][0]
    if first_start > 0:
        segments.append(_VoiceSegment(0, first_start, None))
    for index, (start, boundary) in enumerate(starts):
        end = starts[index + 1][0] if index + 1 < len(starts) else n_events
        segments.append(_VoiceSegment(start, end, boundary))
    return segments


def _boundary_emits_custos(boundary: SourceSystemBoundary) -> bool:
    return CUSTOS_KIND in boundary.kinds and boundary.custos_pitch is not None


def _emit_custos_for_boundary(
    layer: ET.Element,
    voice: MensuralVoice,
    boundary: SourceSystemBoundary,
    emitted_custos_anchors: set[tuple[str, int, int]],
) -> None:
    """Emit ``<custos>`` for a boundary into the given layer (pre-SB projection)."""
    if not _boundary_emits_custos(boundary):
        return
    if boundary.anchor.voice_identity != voice.identity:
        return
    anchor = boundary.anchor
    anchor_key = (anchor.voice_identity, anchor.measure_n, anchor.ordinal)
    if anchor_key in emitted_custos_anchors:
        return
    assert boundary.custos_pitch is not None
    pname, oct_val = boundary.custos_pitch
    custos_el = sub(layer, "custos", pname=pname, oct=str(oct_val))
    set_xml_id(
        custos_el,
        f"mensural-custos-v{voice.rank}-m{anchor.measure_n}-o{anchor.ordinal}",
    )
    emitted_custos_anchors.add(anchor_key)


def _emit_voice_score(
    score: ET.Element,
    voice: MensuralVoice,
    mensural: MensuralDocument,
    resolved_anchored: tuple[_ResolvedMensuralAnchoredText, ...],
) -> set[str]:
    """Emit score-level ``section`` / ``sb`` / ``section`` structure for one voice.

    Source-system ``<custos>`` is projected at the end of the *preceding*
    section's layer (schema parent: ``layer``). Score-level ``<sb/>`` remains
    between sibling sections at the same musical boundary. Inline clefs that
    belong to the new system stay in the post-``sb`` section.
    """
    segments = _build_voice_segments(voice, mensural)
    emitted: set[str] = set()
    emitted_custos_anchors: set[tuple[str, int, int]] = set()
    inline_index = 0
    section_serial = 0
    clef_group_emitted = False

    for index, segment in enumerate(segments):
        if segment.boundary is not None:
            if index == 0 and _boundary_emits_custos(segment.boundary):
                # No preceding layer/system to host the custos (voice-start).
                raise WriterError(
                    "source-system-custos-no-preceding-system: "
                    f"voice={voice.identity!r} "
                    f"measure={segment.boundary.anchor.measure_n} "
                    f"ordinal={segment.boundary.anchor.ordinal}"
                )
            sb_el = sub(score, "sb")
            anchor = segment.boundary.anchor
            set_xml_id(
                sb_el,
                f"mensural-sb-v{voice.rank}-m{anchor.measure_n}-o{anchor.ordinal}",
            )

        section_serial += 1
        section = sub(score, "section")
        set_xml_id(section, f"mensural-section-v{voice.rank}-s{section_serial}")
        staff = sub(section, "staff", n="1")
        layer = sub(staff, "layer", n="1")

        emit_clef_group = False
        if isinstance(voice.clefs, MensuralClefGroup) and not clef_group_emitted:
            # Clef group belongs to the first section that contains voice start.
            if segment.start_index == 0:
                emit_clef_group = True
                clef_group_emitted = True

        section_emitted, inline_index = _emit_voice_layer_slice(
            layer,
            voice,
            resolved_anchored,
            start_index=segment.start_index,
            end_index=segment.end_index,
            inline_index=inline_index,
            emit_clef_group=emit_clef_group,
        )
        emitted.update(section_emitted)

        # Project next boundary's custos onto this (preceding) layer, before sb.
        if index + 1 < len(segments):
            next_segment = segments[index + 1]
            if next_segment.boundary is not None:
                _emit_custos_for_boundary(
                    layer,
                    voice,
                    next_segment.boundary,
                    emitted_custos_anchors,
                )

    # MENSURAL_MDIV_FINAL_BAR_V1: exactly one terminal end bar per mdiv.
    _emit_final_end_bar(layer, voice)

    return emitted


def _emit_final_end_bar(layer: ET.Element, voice: MensuralVoice) -> None:
    """Append the acquired mdiv-final ``<barLine form=\"end\"/>`` as last layer child."""
    bar = sub(layer, "barLine", form="end")
    set_xml_id(bar, f"mensural-final-bar-v{voice.rank}")


def _emit_voice_layer_slice(
    layer: ET.Element,
    voice: MensuralVoice,
    resolved_anchored: tuple[_ResolvedMensuralAnchoredText, ...],
    *,
    start_index: int,
    end_index: int,
    inline_index: int,
    emit_clef_group: bool,
) -> tuple[set[str], int]:
    if emit_clef_group:
        _emit_clef_group_in_layer(layer, voice)

    ligature_by_start = {
        ligature.member_ordinals[0]: ligature for ligature in voice.ligatures
    }
    covered = {
        ordinal
        for ligature in voice.ligatures
        for ordinal in ligature.member_ordinals[1:]
    }
    notes_by_ordinal = {
        event.ordinal: event
        for event in voice.events
        if isinstance(event, MensuralNote)
    }
    emitted: set[str] = set()

    for event in voice.events[start_index:end_index]:
        if isinstance(event, MensuralInlineClef):
            inline_index += 1
            _emit_inline_clef(layer, voice, event, inline_index)
            continue
        if isinstance(event, MensuralNote) and event.ordinal in covered:
            continue
        if isinstance(event, MensuralNote) and event.ordinal in ligature_by_start:
            ligature = ligature_by_start[event.ordinal]
            emitted.update(
                _emit_ligature(
                    layer, voice, ligature, notes_by_ordinal, resolved_anchored
                )
            )
            continue
        if isinstance(event, MensuralNote):
            emitted.update(
                _emit_note(layer, voice, event, resolved_anchored=resolved_anchored)
            )
            continue
        if isinstance(event, MensuralRest):
            _emit_rest(layer, voice, event)
            continue
        raise WriterError(f"unsupported mensural event type {type(event)!r}")
    return emitted, inline_index


def _emit_inline_clef(
    layer: ET.Element,
    voice: MensuralVoice,
    event: MensuralInlineClef,
    inline_index: int,
) -> None:
    clef_el = sub(layer, "clef", shape=event.shape, line=str(event.line))
    set_xml_id(
        clef_el,
        f"mensural-inline-clef-v{voice.rank}-i{inline_index}",
    )


def _emit_ligature(
    layer: ET.Element,
    voice: MensuralVoice,
    ligature: MensuralLigature,
    notes_by_ordinal: dict[int, MensuralNote],
    resolved_anchored: tuple[_ResolvedMensuralAnchoredText, ...],
) -> set[str]:
    """Emit ``<ligature>`` notes, then layer-level anchoredText siblings.

    MEI 5.1 forbids ``anchoredText`` as a ligature child. Business anchors
    (``startid`` → member note) stay unchanged; deferred texts are appended to
    ``layer`` immediately after the complete ligature, in document order.
    """
    first_form = ligature.effective_forms[0]
    lig_el = sub(layer, "ligature", form=first_form)
    set_xml_id(
        lig_el,
        f"mensural-lig-v{voice.rank}-o{ligature.member_ordinals[0]}",
    )
    member_notes: list[MensuralNote] = []
    for ordinal, form in zip(
        ligature.member_ordinals, ligature.effective_forms, strict=True
    ):
        note = notes_by_ordinal[ordinal]
        member_notes.append(note)
        # Notes only inside the ligature — never emit anchoredText here.
        _emit_note(lig_el, voice, note, lig_form=form, resolved_anchored=())
    return _emit_deferred_ligature_anchored_texts(
        layer, voice, member_notes, resolved_anchored
    )


def _emit_deferred_ligature_anchored_texts(
    layer: ET.Element,
    voice: MensuralVoice,
    member_notes: list[MensuralNote],
    resolved_anchored: tuple[_ResolvedMensuralAnchoredText, ...],
) -> set[str]:
    """Append anchoredTexts for ligature members onto ``layer`` after ``<ligature>``."""
    emitted: set[str] = set()
    for item in resolved_anchored:
        if item.voice.identity != voice.identity:
            continue
        if not any(item.note is note for note in member_notes):
            continue
        append_anchored_text(
            layer,
            item.anchored,
            startid=item.startid,
            xml_id=item.xml_id,
        )
        emitted.add(item.xml_id)
    return emitted


def _emit_note(
    parent: ET.Element,
    voice: MensuralVoice,
    note: MensuralNote,
    lig_form: str | None = None,
    *,
    resolved_anchored: tuple[_ResolvedMensuralAnchoredText, ...] = (),
) -> set[str]:
    attrs: dict[str, str | None] = {
        "pname": note.pname,
        "oct": str(note.oct),
        "dur": note.dur,
    }
    if note.quality is not None:
        attrs["dur_quality"] = note.quality
    if (
        note.stem_dir is not None
        and note.stem_pos is not None
        and note.stem_form is not None
    ):
        attrs["stem_dir"] = note.stem_dir
        attrs["stem_pos"] = note.stem_pos
        attrs["stem_form"] = note.stem_form
    elif note.stem_dir is not None:
        attrs["stem_dir"] = note.stem_dir
    elif note.dur in ("minima", "semiminima"):
        attrs["stem_dir"] = "up"
    if note.glyph_auth is not None:
        attrs["glyph_auth"] = note.glyph_auth
    if note.glyph_name is not None:
        attrs["glyph_name"] = note.glyph_name
    if lig_form is not None:
        attrs["lig"] = lig_form
    note_el = sub(parent, "note", **attrs)
    set_xml_id(note_el, f"mensural-v{voice.rank}-e{note.ordinal}")
    append_written_accidental(note_el, note.written_accidental)
    append_lyrics(note_el, note.lyrics)
    return _maybe_emit_anchored_text(parent, voice, note, resolved_anchored)


def _maybe_emit_anchored_text(
    parent: ET.Element,
    voice: MensuralVoice,
    note: MensuralNote,
    resolved_anchored: tuple[_ResolvedMensuralAnchoredText, ...],
) -> set[str]:
    emitted: set[str] = set()
    for item in resolved_anchored:
        if item.voice.identity != voice.identity:
            continue
        if item.note is not note:
            continue
        append_anchored_text(
            parent,
            item.anchored,
            startid=item.startid,
            xml_id=item.xml_id,
        )
        emitted.add(item.xml_id)
    return emitted


def _emit_rest(parent: ET.Element, voice: MensuralVoice, rest: MensuralRest) -> None:
    """Serialize mensural rests from the semantic model."""
    attrs = _rest_attrs(rest.unit, rest.count)
    rest_el = sub(parent, "rest", **attrs)
    set_xml_id(rest_el, f"mensural-v{voice.rank}-e{rest.ordinal}")


def _rest_attrs(unit: str, count: int) -> dict[str, str]:
    """Return deterministic rest attribute mapping for the writer builder."""
    if unit == "brevis" and count == 2:
        return {
            "dur": "longa",
            "spaces": "2",
            "glyph_auth": "smufl",
            "glyph_name": "mensuralRestLongaImperfecta",
        }
    if unit == "brevis" and count == 3:
        return {"dur": "3B"}
    if unit == "brevis" and count == 1:
        return {"dur": "brevis"}
    if unit == "semibrevis" and count == 1:
        return {"dur": "semibrevis"}
    if unit == "minima" and count == 1:
        return {"dur": "minima"}
    raise WriterError(
        f"unsupported mensural rest serialization unit={unit!r} count={count}"
    )
