"""Erreurs métier de lecture MEI Basic."""

from __future__ import annotations


class VoiceTopologyError(ValueError):
    """La topologie des voix ne peut pas être lue depuis le MEI Basic."""


class MusicalEventsError(ValueError):
    """Les mesures ou événements musicaux ne peuvent pas être lus."""


class SourceSignalsError(ValueError):
    """Les porteurs de signaux source ne peuvent pas être lus ou résolus."""


class LigatureSyntaxError(ValueError):
    """La syntaxe d'un texte ``lig:`` est invalide."""


class LigatureResolutionError(ValueError):
    """Une ligature source ne peut pas être résolue dans le document."""


class ConventionSyntaxError(ValueError):
    """Une convention transcripteur structurée est syntaxiquement invalide."""


class MetadataError(ValueError):
    """Les métadonnées documentaires ne peuvent pas être lues."""


class WriterError(ValueError):
    """La sérialisation MEI ne peut pas être produite depuis le modèle J7.2."""


class OutputValidationError(ValueError):
    """La sortie MEI sérialisée échoue aux contrôles ciblés J7.3."""
