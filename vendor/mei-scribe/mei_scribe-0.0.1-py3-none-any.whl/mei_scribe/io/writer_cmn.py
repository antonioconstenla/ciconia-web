"""Sérialisation MEI CMN depuis ``CmnDocument`` (J7.3)."""

from __future__ import annotations

import xml.etree.ElementTree as ET
from dataclasses import dataclass

from mei_scribe.io.errors import WriterError
from mei_scribe.io.mei_builder import (
    CMN_MEIVERSION,
    CMN_RNG,
    append_anchored_text,
    append_lyrics,
    append_written_accidental,
    build_mei_head,
    build_mei_root,
    format_anchored_text_anchor,
    serialize_mei_document,
    set_xml_id,
    sub,
)
from mei_scribe.transform.model import (
    CmnDocument,
    CmnLigature,
    CmnMeasureRest,
    CmnNote,
    CmnRest,
    CmnTie,
    CmnTuplet,
    CmnVoice,
    OutputAnchoredText,
)


@dataclass(frozen=True)
class _ResolvedCmnAnchoredText:
    """Cible CMN résolue par provenance pour un ``OutputAnchoredText``."""

    anchored: OutputAnchoredText
    note: CmnNote
    voice: CmnVoice
    measure_n: int
    startid: str
    xml_id: str


def serialize_cmn_document(document: CmnDocument) -> bytes:
    """Sérialise un ``CmnDocument`` en MEI CMN déterministe (bytes UTF-8)."""
    root = build_mei_root(CMN_MEIVERSION, "cmn-document")
    build_mei_head(root, document.metadata)
    music = sub(root, "music")
    body = sub(music, "body")
    mdiv = sub(body, "mdiv")
    set_xml_id(mdiv, "cmn-mdiv-1")
    score = sub(mdiv, "score")
    _build_score_def(score, document)
    section = sub(score, "section")
    set_xml_id(section, "cmn-section-1")

    voice_by_identity = {voice.identity: voice for voice in document.voices}
    event_ids = _assign_event_ids(document, voice_by_identity)
    _validate_tuplets(document, voice_by_identity)
    _validate_ties(document, voice_by_identity, event_ids)

    tuplet_index = _tuplet_index(document)
    _validate_ligatures(document, voice_by_identity, event_ids)
    resolved_anchored = _resolve_anchored_texts(
        document, voice_by_identity, event_ids
    )
    emitted_anchored: set[str] = set()
    for measure in document.measures:
        measure_el = sub(section, "measure", n=str(measure.n))
        set_xml_id(measure_el, f"cmn-measure-{measure.n}")
        content_by_voice = {
            content.voice_identity: content for content in measure.voices
        }
        for voice in document.voices:
            content = content_by_voice.get(voice.identity)
            if content is None:
                raise WriterError(
                    f"missing voice {voice.identity!r} in measure {measure.n}"
                )
            staff = sub(measure_el, "staff", n=str(voice.rank))
            layer = sub(staff, "layer", n="1")
            emitted_anchored.update(
                _emit_layer_events(
                    layer,
                    voice,
                    measure.n,
                    content.events,
                    tuplet_index,
                    event_ids,
                    resolved_anchored,
                )
            )
        for tie_index, tie in enumerate(document.ties, start=1):
            if tie.start_measure_n != measure.n:
                continue
            _emit_tie(measure_el, tie, tie_index, voice_by_identity, event_ids)
        for lig_index, ligature in enumerate(document.ligatures, start=1):
            if ligature.start_measure_n != measure.n:
                continue
            _emit_bracket_span(
                measure_el,
                ligature,
                lig_index,
                voice_by_identity,
                event_ids,
            )

    missing = [
        item
        for item in resolved_anchored
        if item.xml_id not in emitted_anchored
    ]
    if missing:
        raise WriterError(
            "anchored text resolved but not emitted: "
            f"{format_anchored_text_anchor(missing[0].anchored)}"
        )

    return serialize_mei_document(root, CMN_RNG)


def _resolve_anchored_texts(
    document: CmnDocument,
    voice_by_identity: dict[str, CmnVoice],
    event_ids: dict[tuple[str, int, int], str],
) -> tuple[_ResolvedCmnAnchoredText, ...]:
    used_ids: dict[str, int] = {}
    resolved: list[_ResolvedCmnAnchoredText] = []
    for anchored in document.anchored_texts:
        located: list[tuple[object, str, int]] = []
        for measure in document.measures:
            for content in measure.voices:
                for event in content.events:
                    if anchored.anchor in event.provenance.source_addresses:
                        located.append((event, content.voice_identity, measure.n))

        if not located:
            raise WriterError(
                "anchored text target unresolved: "
                f"{format_anchored_text_anchor(anchored)}"
            )
        if len(located) > 1:
            raise WriterError(
                "anchored text target ambiguous: "
                f"{format_anchored_text_anchor(anchored)} "
                f"matches={len(located)}"
            )

        event, voice_identity, measure_n = located[0]
        if anchored.func == "voiceIncipit" and not isinstance(event, CmnNote):
            raise WriterError(
                "voiceIncipit target must be a CMN note: "
                f"{format_anchored_text_anchor(anchored)}"
            )
        if not isinstance(event, CmnNote):
            raise WriterError(
                "anchored text target must be a CMN note: "
                f"{format_anchored_text_anchor(anchored)}"
            )

        voice = voice_by_identity[voice_identity]
        startid = event_ids[(voice_identity, measure_n, event.ordinal)]
        base_id = f"cmn-anchored-v{voice.rank}-m{measure_n}-e{event.ordinal}"
        used_ids[base_id] = used_ids.get(base_id, 0) + 1
        xml_id = (
            base_id
            if used_ids[base_id] == 1
            else f"{base_id}-{used_ids[base_id]}"
        )
        resolved.append(
            _ResolvedCmnAnchoredText(
                anchored=anchored,
                note=event,
                voice=voice,
                measure_n=measure_n,
                startid=startid,
                xml_id=xml_id,
            )
        )
    return tuple(resolved)


def _build_score_def(score: ET.Element, document: CmnDocument) -> None:
    if document.meter_count is None or document.meter_unit is None:
        raise WriterError("missing CMN meter for scoreDef")
    score_def = sub(
        score,
        "scoreDef",
        meter_count=str(document.meter_count),
        meter_unit=str(document.meter_unit),
    )
    staff_grp = sub(score_def, "staffGrp")
    for voice in document.voices:
        staff_def = sub(staff_grp, "staffDef", n=str(voice.rank), lines="5")
        set_xml_id(staff_def, f"cmn-staffdef-{voice.rank}")
        label = sub(staff_def, "label")
        label.text = voice.name
        clef_attrs: dict[str, str | None] = {
            "shape": voice.clef.shape,
            "line": str(voice.clef.line),
        }
        if voice.clef.dis is not None:
            clef_attrs["dis"] = str(voice.clef.dis)
        if voice.clef.dis_place is not None:
            clef_attrs["dis_place"] = voice.clef.dis_place
        sub(staff_def, "clef", **clef_attrs)


def _event_id(voice: CmnVoice, measure_n: int, ordinal: int) -> str:
    return f"cmn-v{voice.rank}-m{measure_n}-e{ordinal}"


def _assign_event_ids(
    document: CmnDocument, voice_by_identity: dict[str, CmnVoice]
) -> dict[tuple[str, int, int], str]:
    ids: dict[tuple[str, int, int], str] = {}
    seen: set[str] = set()
    for measure in document.measures:
        for content in measure.voices:
            voice = voice_by_identity[content.voice_identity]
            for event in content.events:
                key = (content.voice_identity, measure.n, event.ordinal)
                xml_id = _event_id(voice, measure.n, event.ordinal)
                if xml_id in seen:
                    raise WriterError(f"duplicate generated xml:id {xml_id!r}")
                seen.add(xml_id)
                ids[key] = xml_id
    return ids


def _tuplet_index(
    document: CmnDocument,
) -> dict[tuple[str, int], list[CmnTuplet]]:
    index: dict[tuple[str, int], list[CmnTuplet]] = {}
    for tuplet in document.tuplets:
        key = (tuplet.voice_identity, tuplet.measure_n)
        index.setdefault(key, []).append(tuplet)
    return index


def _validate_tuplets(
    document: CmnDocument, voice_by_identity: dict[str, CmnVoice]
) -> None:
    occupied: set[tuple[str, int, int]] = set()
    for tuplet in document.tuplets:
        if tuplet.voice_identity not in voice_by_identity:
            raise WriterError(
                f"tuplet references unknown voice {tuplet.voice_identity!r}"
            )
        if not tuplet.member_ordinals:
            raise WriterError("empty tuplet")
        measure = next(
            (item for item in document.measures if item.n == tuplet.measure_n),
            None,
        )
        if measure is None:
            raise WriterError(f"tuplet measure {tuplet.measure_n} not found")
        content = next(
            (
                item
                for item in measure.voices
                if item.voice_identity == tuplet.voice_identity
            ),
            None,
        )
        if content is None:
            raise WriterError(
                f"tuplet voice {tuplet.voice_identity!r} missing in measure "
                f"{tuplet.measure_n}"
            )
        ordinals = [event.ordinal for event in content.events]
        for member in tuplet.member_ordinals:
            if member not in ordinals:
                raise WriterError(
                    f"tuplet member ordinal {member} absent in measure "
                    f"{tuplet.measure_n}"
                )
            key = (tuplet.voice_identity, tuplet.measure_n, member)
            if key in occupied:
                raise WriterError(
                    f"overlapping tuplets at {tuplet.voice_identity!r} "
                    f"measure {tuplet.measure_n} ordinal {member}"
                )
            occupied.add(key)
        positions = [ordinals.index(member) for member in tuplet.member_ordinals]
        for left, right in zip(positions, positions[1:]):
            if right != left + 1:
                raise WriterError(
                    f"tuplet members are not contiguous in measure "
                    f"{tuplet.measure_n}"
                )


def _validate_ties(
    document: CmnDocument,
    voice_by_identity: dict[str, CmnVoice],
    event_ids: dict[tuple[str, int, int], str],
) -> None:
    for tie in document.ties:
        if tie.voice_identity not in voice_by_identity:
            raise WriterError(f"tie references unknown voice {tie.voice_identity!r}")
        start_key = (tie.voice_identity, tie.start_measure_n, tie.start_ordinal)
        end_key = (tie.voice_identity, tie.end_measure_n, tie.end_ordinal)
        if start_key not in event_ids:
            raise WriterError(
                f"tie start endpoint absent: measure={tie.start_measure_n} "
                f"ordinal={tie.start_ordinal}"
            )
        if end_key not in event_ids:
            raise WriterError(
                f"tie end endpoint absent: measure={tie.end_measure_n} "
                f"ordinal={tie.end_ordinal}"
            )
        start_event = _event_at(
            document, tie.voice_identity, tie.start_measure_n, tie.start_ordinal
        )
        end_event = _event_at(
            document, tie.voice_identity, tie.end_measure_n, tie.end_ordinal
        )
        if not isinstance(start_event, CmnNote) or not isinstance(end_event, CmnNote):
            raise WriterError("tie endpoints must be notes")


def _event_at(document: CmnDocument, voice_identity: str, measure_n: int, ordinal: int):
    for measure in document.measures:
        if measure.n != measure_n:
            continue
        for content in measure.voices:
            if content.voice_identity != voice_identity:
                continue
            for event in content.events:
                if event.ordinal == ordinal:
                    return event
    raise WriterError(
        f"event not found voice={voice_identity!r} measure={measure_n} "
        f"ordinal={ordinal}"
    )


def _emit_layer_events(
    layer: ET.Element,
    voice: CmnVoice,
    measure_n: int,
    events: tuple,
    tuplet_index: dict[tuple[str, int], list[CmnTuplet]],
    event_ids: dict[tuple[str, int, int], str],
    resolved_anchored: tuple[_ResolvedCmnAnchoredText, ...],
) -> set[str]:
    tuplets = tuplet_index.get((voice.identity, measure_n), [])
    tuplet_by_start = {tuplet.member_ordinals[0]: tuplet for tuplet in tuplets}
    covered = {
        ordinal
        for tuplet in tuplets
        for ordinal in tuplet.member_ordinals[1:]
    }
    events_by_ordinal = {event.ordinal: event for event in events}
    emitted: set[str] = set()

    for event in events:
        if event.ordinal in covered:
            continue
        if event.ordinal in tuplet_by_start:
            tuplet = tuplet_by_start[event.ordinal]
            tuplet_el = sub(
                layer,
                "tuplet",
                num=str(tuplet.num),
                numbase=str(tuplet.numbase),
            )
            set_xml_id(
                tuplet_el,
                f"cmn-tuplet-v{voice.rank}-m{measure_n}-o{event.ordinal}",
            )
            for member_ordinal in tuplet.member_ordinals:
                member = events_by_ordinal[member_ordinal]
                _emit_event(
                    tuplet_el,
                    member,
                    event_ids[(voice.identity, measure_n, member_ordinal)],
                )
                emitted.update(
                    _maybe_emit_anchored_text(
                        tuplet_el,
                        resolved_anchored,
                        voice,
                        measure_n,
                        member,
                    )
                )
            continue
        _emit_event(
            layer,
            event,
            event_ids[(voice.identity, measure_n, event.ordinal)],
        )
        emitted.update(
            _maybe_emit_anchored_text(
                layer,
                resolved_anchored,
                voice,
                measure_n,
                event,
            )
        )
    return emitted


def _emit_event(parent: ET.Element, event, xml_id: str) -> None:
    if isinstance(event, CmnNote):
        attrs: dict[str, str | None] = {
            "pname": event.pname,
            "oct": str(event.oct),
            "dur": event.dur,
        }
        if event.dots > 0:
            attrs["dots"] = str(event.dots)
        note_el = sub(parent, "note", **attrs)
        set_xml_id(note_el, xml_id)
        append_written_accidental(note_el, event.written_accidental)
        append_lyrics(note_el, event.lyrics)
        return
    if isinstance(event, CmnRest):
        attrs = {"dur": event.dur}
        if event.dots > 0:
            attrs["dots"] = str(event.dots)
        rest_el = sub(parent, "rest", **attrs)
        set_xml_id(rest_el, xml_id)
        return
    if isinstance(event, CmnMeasureRest):
        rest_el = sub(parent, "mRest")
        set_xml_id(rest_el, xml_id)
        return
    raise WriterError(f"unsupported CMN event type {type(event)!r}")


def _maybe_emit_anchored_text(
    parent: ET.Element,
    resolved_anchored: tuple[_ResolvedCmnAnchoredText, ...],
    voice: CmnVoice,
    measure_n: int,
    event,
) -> set[str]:
    emitted: set[str] = set()
    for item in resolved_anchored:
        if (
            item.voice.identity != voice.identity
            or item.measure_n != measure_n
            or item.note is not event
        ):
            continue
        append_anchored_text(
            parent,
            item.anchored,
            startid=item.startid,
            xml_id=item.xml_id,
        )
        emitted.add(item.xml_id)
    return emitted


def _emit_tie(
    measure_el: ET.Element,
    tie: CmnTie,
    tie_index: int,
    voice_by_identity: dict[str, CmnVoice],
    event_ids: dict[tuple[str, int, int], str],
) -> None:
    start_id = event_ids[
        (tie.voice_identity, tie.start_measure_n, tie.start_ordinal)
    ]
    end_id = event_ids[(tie.voice_identity, tie.end_measure_n, tie.end_ordinal)]
    tie_el = sub(
        measure_el,
        "tie",
        startid=f"#{start_id}",
        endid=f"#{end_id}",
    )
    set_xml_id(tie_el, f"cmn-tie-{tie_index}")


def _validate_ligatures(
    document: CmnDocument,
    voice_by_identity: dict[str, CmnVoice],
    event_ids: dict[tuple[str, int, int], str],
) -> None:
    for ligature in document.ligatures:
        if ligature.voice_identity not in voice_by_identity:
            raise WriterError(
                f"ligature references unknown voice {ligature.voice_identity!r}"
            )
        if len(ligature.member_addresses) < 2:
            raise WriterError("ligature must contain at least two members")
        start_key = (
            ligature.voice_identity,
            ligature.start_measure_n,
            ligature.start_ordinal,
        )
        end_key = (
            ligature.voice_identity,
            ligature.end_measure_n,
            ligature.end_ordinal,
        )
        if start_key not in event_ids:
            raise WriterError(
                f"ligature start endpoint absent: measure="
                f"{ligature.start_measure_n} ordinal={ligature.start_ordinal}"
            )
        if end_key not in event_ids:
            raise WriterError(
                f"ligature end endpoint absent: measure="
                f"{ligature.end_measure_n} ordinal={ligature.end_ordinal}"
            )
        start_event = _event_at(
            document,
            ligature.voice_identity,
            ligature.start_measure_n,
            ligature.start_ordinal,
        )
        end_event = _event_at(
            document,
            ligature.voice_identity,
            ligature.end_measure_n,
            ligature.end_ordinal,
        )
        if not isinstance(start_event, CmnNote) or not isinstance(end_event, CmnNote):
            raise WriterError("ligature endpoints must be notes")
        start_addr = ligature.member_addresses[0]
        end_addr = ligature.member_addresses[-1]
        if (
            start_addr.measure_n != ligature.start_measure_n
            or start_addr.ordinal != ligature.start_ordinal
            or end_addr.measure_n != ligature.end_measure_n
            or end_addr.ordinal != ligature.end_ordinal
        ):
            raise WriterError("ligature endpoints disagree with member addresses")
        if (ligature.start_measure_n, ligature.start_ordinal) >= (
            ligature.end_measure_n,
            ligature.end_ordinal,
        ):
            raise WriterError("ligature start must precede end")


def _emit_bracket_span(
    measure_el: ET.Element,
    ligature: CmnLigature,
    lig_index: int,
    voice_by_identity: dict[str, CmnVoice],
    event_ids: dict[tuple[str, int, int], str],
) -> None:
    if ligature.voice_identity not in voice_by_identity:
        raise WriterError(
            f"ligature references unknown voice {ligature.voice_identity!r}"
        )
    start_id = event_ids[
        (
            ligature.voice_identity,
            ligature.start_measure_n,
            ligature.start_ordinal,
        )
    ]
    end_id = event_ids[
        (
            ligature.voice_identity,
            ligature.end_measure_n,
            ligature.end_ordinal,
        )
    ]
    # Deterministic attribute order via builder kwargs then xml:id:
    # func, lform, lstartsym, lendsym, startid, endid, xml:id.
    span_el = sub(
        measure_el,
        "bracketSpan",
        func="ligature",
        lform="solid",
        lstartsym="angledown",
        lendsym="angledown",
        startid=f"#{start_id}",
        endid=f"#{end_id}",
    )
    set_xml_id(span_el, f"cmn-ligature-{lig_index}")
