"""Entrées/sorties : lecture et écriture de documents MEI."""

from __future__ import annotations

from typing import Any

from mei_scribe.contracts.voice_policy import VoicePolicy
from mei_scribe.io.errors import (
    ConventionSyntaxError,
    LigatureResolutionError,
    LigatureSyntaxError,
    MetadataError,
    MusicalEventsError,
    SourceSignalsError,
    VoiceTopologyError,
)

# Reader symbols are loaded lazily so that ``mei_scribe.io.errors`` (and
# callers such as ``signals.conventions``) can be imported without pulling
# ``reader`` → ``signals.conventions`` again (circular import).

__all__ = [
    "ACCEPTED_CMN_DURS",
    "ConventionSyntaxError",
    "LigatureResolutionError",
    "LigatureSyntaxError",
    "MetadataError",
    "MusicalEventsError",
    "OutputValidationError",
    "OutputFileNames",
    "SourceSignalsError",
    "SerializedOutputs",
    "VoicePolicy",
    "VoiceTopologyError",
    "WriterError",
    "WrittenOutputs",
    "normalize_voice_label",
    "read_input_document",
    "read_voice_topology",
    "serialize_transformation_bundle",
    "serialize_cmn_document",
    "serialize_mensural_document",
    "sibling_output_names",
    "write_transformation_bundle",
]

_READER_EXPORTS = frozenset(
    {
        "ACCEPTED_CMN_DURS",
        "normalize_voice_label",
        "read_input_document",
        "read_voice_topology",
    }
)

_WRITER_EXPORTS = frozenset(
    {
        "WrittenOutputs",
        "OutputFileNames",
        "SerializedOutputs",
        "serialize_cmn_document",
        "serialize_mensural_document",
        "serialize_transformation_bundle",
        "sibling_output_names",
        "write_transformation_bundle",
    }
)


def __getattr__(name: str) -> Any:
    if name in _READER_EXPORTS:
        from mei_scribe.io import reader as _reader

        return getattr(_reader, name)
    if name in {"WriterError", "OutputValidationError"}:
        from mei_scribe.io import errors as _errors

        return getattr(_errors, name)
    if name in _WRITER_EXPORTS:
        from mei_scribe.io import writer as _writer
        from mei_scribe.io.writer_cmn import serialize_cmn_document
        from mei_scribe.io.writer_mensural import serialize_mensural_document

        mapping = {
            "WrittenOutputs": _writer.WrittenOutputs,
            "OutputFileNames": _writer.OutputFileNames,
            "SerializedOutputs": _writer.SerializedOutputs,
            "serialize_cmn_document": serialize_cmn_document,
            "serialize_mensural_document": serialize_mensural_document,
            "serialize_transformation_bundle": _writer.serialize_transformation_bundle,
            "sibling_output_names": _writer.sibling_output_names,
            "write_transformation_bundle": _writer.write_transformation_bundle,
        }
        return mapping[name]
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__() -> list[str]:
    return sorted(
        set(__all__) | set(globals()) | set(_READER_EXPORTS) | set(_WRITER_EXPORTS)
    )
