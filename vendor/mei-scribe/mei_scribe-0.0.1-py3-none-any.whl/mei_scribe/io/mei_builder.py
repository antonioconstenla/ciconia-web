"""Construction XML MEI déterministe partagée (J7.3)."""

from __future__ import annotations

import xml.etree.ElementTree as ET
from typing import Iterable

from mei_scribe.io.errors import WriterError
from mei_scribe.model.document import InputLyricSyllable
from mei_scribe.transform.model import (
    OutputAnchoredText,
    OutputDocumentMetadata,
    OutputWrittenAccidental,
)

MEI_NS = "http://www.music-encoding.org/ns/mei"
XML_NS = "http://www.w3.org/XML/1998/namespace"

CMN_MEIVERSION = "5.1+CMN"
MENSURAL_MEIVERSION = "5.1+Mensural"
CMN_RNG = "https://music-encoding.org/schema/5.1/mei-CMN.rng"
MENSURAL_RNG = "https://music-encoding.org/schema/5.1/mei-Mensural.rng"

ET.register_namespace("", MEI_NS)
ET.register_namespace("xml", XML_NS)


def qname(tag: str) -> str:
    return f"{{{MEI_NS}}}{tag}"


def sub(parent: ET.Element, tag: str, **attrs: str | None) -> ET.Element:
    element = ET.SubElement(parent, qname(tag))
    for key, value in attrs.items():
        if value is None:
            continue
        if key == "xml_id":
            element.set(f"{{{XML_NS}}}id", value)
        else:
            element.set(key.replace("_", "."), value)
    return element


def set_xml_id(element: ET.Element, value: str) -> None:
    element.set(f"{{{XML_NS}}}id", value)


def build_mei_root(meiversion: str, xml_id: str) -> ET.Element:
    root = ET.Element(qname("mei"))
    root.set("meiversion", meiversion)
    set_xml_id(root, xml_id)
    return root


def build_mei_head(parent: ET.Element, metadata: OutputDocumentMetadata) -> None:
    """Construit un meiHead structuré depuis OutputDocumentMetadata uniquement."""
    if metadata.title is None:
        raise WriterError("missing title in output metadata")
    if metadata.composer is None:
        raise WriterError("missing composer in output metadata")
    if metadata.source_siglum is None:
        raise WriterError("missing source_siglum in output metadata")
    if metadata.source_repo is None:
        raise WriterError("missing source_repo in output metadata")
    if metadata.source_idno is None:
        raise WriterError("missing source_idno in output metadata")
    if metadata.transcriber is None:
        raise WriterError("missing transcriber in output metadata")
    if metadata.license is None:
        raise WriterError("missing license in output metadata")
    if metadata.notation_type is None:
        raise WriterError("missing notation_type in output metadata")
    if metadata.modusminor is None or metadata.tempus is None or metadata.prolatio is None:
        raise WriterError("missing structured mensuration in output metadata")
    if metadata.mensur_in_source is None:
        raise WriterError("missing mensur_in_source in output metadata")

    mei_head = sub(parent, "meiHead")
    file_desc = sub(mei_head, "fileDesc")

    title_stmt = sub(file_desc, "titleStmt")
    title = sub(title_stmt, "title", type="main")
    title.text = metadata.title
    resp = sub(title_stmt, "respStmt")
    pers = sub(resp, "persName", role="transcriber")
    pers.text = metadata.transcriber

    pub_stmt = sub(file_desc, "pubStmt")
    availability = sub(pub_stmt, "availability")
    use_restrict = sub(availability, "useRestrict")
    use_restrict.text = metadata.license

    source_desc = sub(file_desc, "sourceDesc")
    source = sub(source_desc, "source")
    bibl = sub(source, "bibl")
    identifier = sub(bibl, "identifier", type="siglum")
    identifier.text = metadata.source_siglum
    phys_loc = sub(bibl, "physLoc")
    repository = sub(phys_loc, "repository")
    repository.text = metadata.source_repo
    shelfmark = sub(phys_loc, "identifier", type="shelfmark")
    shelfmark.text = metadata.source_idno

    work_list = sub(mei_head, "workList")
    work = sub(work_list, "work")
    work_title = sub(work, "title", type="main")
    work_title.text = metadata.title
    composer = sub(work, "composer")
    composer_pers = sub(composer, "persName", role="composer")
    composer_pers.text = metadata.composer
    sub(
        work,
        "mensuration",
        type="source",
        modusminor=str(metadata.modusminor),
        tempus=str(metadata.tempus),
        prolatio=str(metadata.prolatio),
    )
    notation = sub(work, "otherChar", type="source-notation")
    notation.text = metadata.notation_type
    mensur_flag = sub(work, "otherChar", type="mensur-in-source")
    mensur_flag.text = "true" if metadata.mensur_in_source else "false"
    for paratext in metadata.paratexts:
        other_char = sub(work, "otherChar", type=paratext.other_char_type())
        other_char.text = paratext.text


def append_anchored_text(
    layer: ET.Element,
    anchored: OutputAnchoredText,
    *,
    startid: str,
    xml_id: str,
) -> None:
    """Émet un ``anchoredText`` immédiatement après la note cible."""
    element = sub(
        layer,
        "anchoredText",
        func=anchored.func,
        startid=f"#{startid}",
    )
    set_xml_id(element, xml_id)
    element.text = anchored.text


def format_anchored_text_anchor(anchored: OutputAnchoredText) -> str:
    """Contexte structuré pour les erreurs de résolution d'ancrage."""
    anchor = anchored.anchor
    return (
        f"func={anchored.func!r} "
        f"voice={anchor.voice_identity!r} "
        f"measure={anchor.measure_n} "
        f"ordinal={anchor.ordinal} "
        f"event_kind={anchor.event_kind!r}"
    )


def append_lyrics(note_el: ET.Element, lyrics: Iterable[InputLyricSyllable]) -> None:
    for syllable in lyrics:
        verse_attrs: dict[str, str | None] = {}
        if syllable.verse_n is not None:
            verse_attrs["n"] = str(syllable.verse_n)
        verse = sub(note_el, "verse", **verse_attrs)
        syl_attrs: dict[str, str | None] = {
            "wordpos": syllable.wordpos,
            "con": syllable.con,
        }
        syl = sub(verse, "syl", **syl_attrs)
        syl.text = syllable.text


def append_written_accidental(
    note_el: ET.Element, accidental: OutputWrittenAccidental | None
) -> None:
    if accidental is None:
        return
    sub(note_el, "accid", accid=accidental.accid, enclose=accidental.enclose)


def serialize_mei_document(root: ET.Element, schema_href: str) -> bytes:
    """Sérialise un arbre MEI en bytes UTF-8 déterministes (sans BOM)."""
    ET.indent(root, space="  ")
    body = ET.tostring(root, encoding="unicode")
    # ElementTree may emit a default xmlns declaration; keep it as produced.
    lines = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        (
            f'<?xml-model href="{schema_href}" type="application/xml" '
            'schematypens="http://relaxng.org/ns/structure/1.0"?>'
        ),
        (
            f'<?xml-model href="{schema_href}" type="application/xml" '
            'schematypens="http://purl.oclc.org/dsdl/schematron"?>'
        ),
        body,
    ]
    text = "\n".join(lines)
    if not text.endswith("\n"):
        text += "\n"
    return text.encode("utf-8")
