"""Construction XML MEI déterministe partagée (J7.3)."""

from __future__ import annotations

import xml.etree.ElementTree as ET
from typing import Iterable

from mei_scribe.io.errors import WriterError
from mei_scribe.model.document import (
    AnchoredTextAbbr,
    AnchoredTextChoice,
    AnchoredTextDamage,
    AnchoredTextGap,
    AnchoredTextPart,
    AnchoredTextPlain,
    AnchoredTextSupplied,
    AnchoredTextUnclear,
    InputLyricSyllable,
)
from mei_scribe.transform.model import (
    EditorialAttrs,
    LyricEditorialEdit,
    OutputAnchoredText,
    OutputDamage,
    OutputDocumentMetadata,
    OutputGap,
    OutputWrittenAccidental,
    ResolvedEditorialAttachment,
)

MEI_NS = "http://www.music-encoding.org/ns/mei"
XML_NS = "http://www.w3.org/XML/1998/namespace"

CMN_MEIVERSION = "5.1+CMN"
MENSURAL_MEIVERSION = "5.1+Mensural"
CMN_RNG = "https://music-encoding.org/schema/5.1/mei-CMN.rng"
MENSURAL_RNG = "https://music-encoding.org/schema/5.1/mei-Mensural.rng"

ET.register_namespace("", MEI_NS)
ET.register_namespace("xml", XML_NS)


def qname(tag: str) -> str:
    return f"{{{MEI_NS}}}{tag}"


def sub(parent: ET.Element, tag: str, **attrs: str | None) -> ET.Element:
    element = ET.SubElement(parent, qname(tag))
    for key, value in attrs.items():
        if value is None:
            continue
        if key == "xml_id":
            element.set(f"{{{XML_NS}}}id", value)
        else:
            element.set(key.replace("_", "."), value)
    return element


def set_xml_id(element: ET.Element, value: str) -> None:
    element.set(f"{{{XML_NS}}}id", value)


def build_mei_root(meiversion: str, xml_id: str) -> ET.Element:
    root = ET.Element(qname("mei"))
    root.set("meiversion", meiversion)
    set_xml_id(root, xml_id)
    return root


def _emit_work_mensuration(metadata: OutputDocumentMetadata, sibling: str | None) -> bool:
    mode = metadata.projection_mode
    if mode in (None, "interpretive-232"):
        return True
    if mode == "diplomatic-known-222":
        return sibling != "cmn"
    if mode == "diplomatic-unknown":
        return False
    raise WriterError(f"unknown projection_mode {mode!r}")


def build_mei_head(
    parent: ET.Element,
    metadata: OutputDocumentMetadata,
    *,
    sibling: str | None = None,
) -> None:
    """Construit un meiHead structuré depuis OutputDocumentMetadata uniquement."""
    if metadata.title is None:
        raise WriterError("missing title in output metadata")
    if metadata.composer is None:
        raise WriterError("missing composer in output metadata")
    if metadata.source_siglum is None:
        raise WriterError("missing source_siglum in output metadata")
    if metadata.source_repo is None:
        raise WriterError("missing source_repo in output metadata")
    if metadata.source_idno is None:
        raise WriterError("missing source_idno in output metadata")
    if metadata.transcriber is None:
        raise WriterError("missing transcriber in output metadata")
    if metadata.license is None:
        raise WriterError("missing license in output metadata")
    if metadata.notation_type is None:
        raise WriterError("missing notation_type in output metadata")

    emit_mensuration = _emit_work_mensuration(metadata, sibling)
    if emit_mensuration:
        if metadata.modusminor is None or metadata.tempus is None or metadata.prolatio is None:
            raise WriterError("missing structured mensuration in output metadata")
    if emit_mensuration and metadata.mensur_in_source is None:
        raise WriterError("missing mensur_in_source in output metadata")
    if (
        metadata.projection_mode == "diplomatic-known-222"
        and metadata.mensur_in_source is None
        and sibling != "cmn"
    ):
        # 222 Mensural may omit the flag only when the source omitted it;
        # the work mensuration triple is still required above.
        pass

    mei_head = sub(parent, "meiHead")
    file_desc = sub(mei_head, "fileDesc")

    title_stmt = sub(file_desc, "titleStmt")
    title = sub(title_stmt, "title", type="main")
    title.text = metadata.title
    resp = sub(title_stmt, "respStmt")
    pers = sub(resp, "persName", role="transcriber")
    pers.text = metadata.transcriber

    pub_stmt = sub(file_desc, "pubStmt")
    availability = sub(pub_stmt, "availability")
    use_restrict = sub(availability, "useRestrict")
    use_restrict.text = metadata.license

    source_desc = sub(file_desc, "sourceDesc")
    source = sub(source_desc, "source")
    bibl = sub(source, "bibl")
    identifier = sub(bibl, "identifier", type="siglum")
    identifier.text = metadata.source_siglum
    phys_loc = sub(bibl, "physLoc")
    repository = sub(phys_loc, "repository")
    repository.text = metadata.source_repo
    shelfmark = sub(phys_loc, "identifier", type="shelfmark")
    shelfmark.text = metadata.source_idno

    work_list = sub(mei_head, "workList")
    work = sub(work_list, "work")
    work_title = sub(work, "title", type="main")
    work_title.text = metadata.title
    composer = sub(work, "composer")
    composer_pers = sub(composer, "persName", role="composer")
    composer_pers.text = metadata.composer
    if emit_mensuration:
        sub(
            work,
            "mensuration",
            type="source",
            modusminor=str(metadata.modusminor),
            tempus=str(metadata.tempus),
            prolatio=str(metadata.prolatio),
        )
    notation = sub(work, "otherChar", type="source-notation")
    notation.text = metadata.notation_type
    if metadata.mensur_in_source is not None:
        mensur_flag = sub(work, "otherChar", type="mensur-in-source")
        mensur_flag.text = "true" if metadata.mensur_in_source else "false"
    elif emit_mensuration:
        raise WriterError("missing mensur_in_source in output metadata")
    for paratext in metadata.paratexts:
        other_char = sub(work, "otherChar", type=paratext.other_char_type())
        other_char.text = paratext.text


def append_anchored_text(
    layer: ET.Element,
    anchored: OutputAnchoredText,
    *,
    startid: str,
    xml_id: str,
) -> None:
    """Émet un ``anchoredText`` immédiatement après la note cible."""
    if anchored.verse_n is not None and anchored.func != "lyricFragment":
        raise WriterError(
            "verse association is only authorized on lyricFragment, "
            f"got {anchored.func!r}"
        )
    element = sub(
        layer,
        "anchoredText",
        func=anchored.func,
        startid=f"#{startid}",
        n=anchored.n,
        type=(
            f"verse{anchored.verse_n}" if anchored.verse_n is not None else None
        ),
    )
    set_xml_id(element, xml_id)
    if not anchored.parts:
        element.text = anchored.text
        return
    _append_mixed_content(element, anchored.parts)


def _append_mixed_content(
    element: ET.Element, parts: tuple[AnchoredTextPart, ...]
) -> None:
    last_child: ET.Element | None = None
    for part in parts:
        if isinstance(part, AnchoredTextPlain):
            if last_child is None:
                element.text = (element.text or "") + part.text
            else:
                last_child.tail = (last_child.tail or "") + part.text
            continue
        last_child = _append_inline_part(element, part)


def _append_inline_part(parent: ET.Element, part: AnchoredTextPart) -> ET.Element:
    if isinstance(part, AnchoredTextChoice):
        choice = sub(parent, "choice")
        for reading in part.readings:
            _append_inline_part(choice, reading)
        return choice
    if isinstance(part, AnchoredTextAbbr):
        child = sub(parent, "abbr", expan=part.expan)
        if part.text:
            child.text = part.text
        return child
    if isinstance(part, AnchoredTextUnclear):
        child = sub(
            parent,
            "unclear",
            reason=part.reason,
            agent=part.agent,
            evidence=part.evidence,
            cert=part.cert,
        )
        child.text = part.text
        return child
    if isinstance(part, AnchoredTextSupplied):
        child = sub(
            parent,
            "supplied",
            reason=part.reason,
            agent=part.agent,
            evidence=part.evidence,
            cert=part.cert,
        )
        child.text = part.text
        return child
    if isinstance(part, AnchoredTextGap):
        return sub(
            parent,
            "gap",
            reason=part.reason,
            extent=part.extent,
            unit=part.unit,
        )
    if isinstance(part, AnchoredTextDamage):
        return sub(
            parent,
            "damage",
            agent=part.agent,
            extent=part.extent,
            unit=part.unit,
            atleast=part.atleast,
            atmost=part.atmost,
        )
    raise TypeError(f"unsupported anchoredText part {type(part)!r}")


def format_anchored_text_anchor(anchored: OutputAnchoredText) -> str:
    """Contexte structuré pour les erreurs de résolution d'ancrage."""
    anchor = anchored.anchor
    return (
        f"func={anchored.func!r} "
        f"voice={anchor.voice_identity!r} "
        f"measure={anchor.measure_n} "
        f"ordinal={anchor.ordinal} "
        f"event_kind={anchor.event_kind!r}"
    )


def append_lyrics(
    note_el: ET.Element,
    lyrics: Iterable[InputLyricSyllable],
    lyric_edits: Iterable[LyricEditorialEdit] = (),
) -> None:
    syllables = list(lyrics)
    edits = tuple(lyric_edits)
    existing_verses = {syllable.verse_n for syllable in syllables}
    extras: list[InputLyricSyllable] = []
    for edit in edits:
        if not edit.placeholder and (
            edit.verse_n is None or edit.verse_n in existing_verses
        ):
            continue
        if any(item.verse_n == edit.verse_n for item in extras):
            continue
        extras.append(InputLyricSyllable(text="", verse_n=edit.verse_n))
    extras.sort(key=lambda item: (item.verse_n is None, item.verse_n or 0))
    outgoing = tuple(syllables) + tuple(extras)
    edit_by_verse = {edit.verse_n: edit for edit in edits}
    if len(edit_by_verse) != len(edits):
        raise WriterError("duplicate lyric editorial verse identity")
    for syllable in outgoing:
        verse_attrs: dict[str, str | None] = {}
        if syllable.verse_n is not None:
            verse_attrs["n"] = str(syllable.verse_n)
        verse = sub(note_el, "verse", **verse_attrs)
        syl_attrs: dict[str, str | None] = {
            "wordpos": syllable.wordpos,
            "con": syllable.con,
        }
        syl = sub(verse, "syl", **syl_attrs)
        edit = _lyric_edit_for_syllable(syllable, outgoing, edit_by_verse)
        if edit is None:
            syl.text = syllable.text
            continue
        unclear = append_editorial_wrapper(syl, "unclear", edit.attrs)
        if syllable.text:
            unclear.text = syllable.text


def _lyric_edit_for_syllable(
    syllable: InputLyricSyllable,
    outgoing: tuple[InputLyricSyllable, ...],
    edit_by_verse: dict[int | None, LyricEditorialEdit],
) -> LyricEditorialEdit | None:
    if syllable.verse_n in edit_by_verse:
        return edit_by_verse[syllable.verse_n]
    if (
        len(outgoing) == 1
        and len(edit_by_verse) == 1
        and None in edit_by_verse
        and syllable.verse_n is not None
    ):
        return edit_by_verse[None]
    return None


def append_editorial_wrapper(
    parent: ET.Element, tag: str, attrs: EditorialAttrs
) -> ET.Element:
    """Emit ``unclear`` / ``supplied`` without illegal V1 ``@source``."""
    return sub(
        parent,
        tag,
        type=attrs.mei_type,
        reason=attrs.reason,
        agent=attrs.agent,
        evidence=attrs.evidence,
        cert=attrs.cert,
        extent=attrs.extent,
        unit=attrs.unit,
    )


def append_supplied_clef(
    parent: ET.Element,
    *,
    shape: str,
    line: int,
    attrs: EditorialAttrs,
    xml_id: str | None = None,
    dis: int | None = None,
    dis_place: str | None = None,
) -> ET.Element:
    """Emit ``<supplied …><clef …/></supplied>`` with the existing clef values."""
    wrapper = append_editorial_wrapper(parent, "supplied", attrs)
    clef_attrs: dict[str, str | None] = {
        "shape": shape,
        "line": str(line),
    }
    if dis is not None:
        clef_attrs["dis"] = str(dis)
    if dis_place is not None:
        clef_attrs["dis_place"] = dis_place
    clef_el = sub(wrapper, "clef", **clef_attrs)
    if xml_id is not None:
        set_xml_id(clef_el, xml_id)
    return wrapper


def append_damage(parent: ET.Element, damage: OutputDamage) -> ET.Element:
    """Emit empty ``<damage>``; never serialize scope/reason/cert/evidence/source."""
    return sub(
        parent,
        "damage",
        agent=damage.agent,
        extent=damage.extent,
        atleast=damage.atleast,
        atmost=damage.atmost,
        unit=damage.unit,
    )


def append_gap(parent: ET.Element, gap: OutputGap) -> ET.Element:
    """Emit empty ``<gap>``; never serialize scope/agent/source."""
    return sub(
        parent,
        "gap",
        reason=gap.reason,
        extent=gap.extent,
        unit=gap.unit,
        evidence=gap.evidence,
        cert=gap.cert,
    )


def editorial_event_parent(
    parent: ET.Element, attachment: ResolvedEditorialAttachment | None
) -> ET.Element:
    """Insert optional damage and before-gap siblings, then nested event wrappers."""
    if attachment is None:
        return parent
    if attachment.damage is not None:
        append_damage(parent, attachment.damage)
    if attachment.gap_before is not None:
        append_gap(parent, attachment.gap_before)
    if not attachment.event_wrappers:
        return parent
    current = parent
    for element, attrs in attachment.event_wrappers:
        current = append_editorial_wrapper(current, element, attrs)
    return current


def append_post_event_gaps(
    parent: ET.Element, attachment: ResolvedEditorialAttachment | None
) -> None:
    """Emit after-scope gap on the layer parent, never inside a wrapper."""
    if attachment is None or attachment.gap_after is None:
        return
    append_gap(parent, attachment.gap_after)


def append_written_accidental(
    note_el: ET.Element, accidental: OutputWrittenAccidental | None
) -> None:
    if accidental is None:
        return
    sub(note_el, "accid", accid=accidental.accid, enclose=accidental.enclose)


def _snapshot_anchored_text_spacing(
    root: ET.Element,
) -> tuple[tuple[ET.Element, str | None, tuple[tuple[ET.Element, str | None, str | None], ...]], ...]:
    """Preserve mixed-content text/tails from ``ET.indent`` whitespace rewrite."""
    saved: list[
        tuple[
            ET.Element,
            str | None,
            tuple[tuple[ET.Element, str | None, str | None], ...],
        ]
    ] = []
    for element in root.iter():
        if element.tag != qname("anchoredText"):
            continue
        saved.append(
            (
                element,
                element.text,
                tuple((child, child.text, child.tail) for child in element),
            )
        )
    return tuple(saved)


def _restore_anchored_text_spacing(
    saved: tuple[
        tuple[ET.Element, str | None, tuple[tuple[ET.Element, str | None, str | None], ...]],
        ...,
    ],
) -> None:
    for element, text, children in saved:
        element.text = text
        for child, child_text, tail in children:
            child.text = child_text
            child.tail = tail


def serialize_mei_document(root: ET.Element, schema_href: str) -> bytes:
    """Sérialise un arbre MEI en bytes UTF-8 déterministes (sans BOM)."""
    mixed = _snapshot_anchored_text_spacing(root)
    ET.indent(root, space="  ")
    _restore_anchored_text_spacing(mixed)
    body = ET.tostring(root, encoding="unicode")
    # ElementTree may emit a default xmlns declaration; keep it as produced.
    lines = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        (
            f'<?xml-model href="{schema_href}" type="application/xml" '
            'schematypens="http://relaxng.org/ns/structure/1.0"?>'
        ),
        (
            f'<?xml-model href="{schema_href}" type="application/xml" '
            'schematypens="http://purl.oclc.org/dsdl/schematron"?>'
        ),
        body,
    ]
    text = "\n".join(lines)
    if not text.endswith("\n"):
        text += "\n"
    return text.encode("utf-8")
