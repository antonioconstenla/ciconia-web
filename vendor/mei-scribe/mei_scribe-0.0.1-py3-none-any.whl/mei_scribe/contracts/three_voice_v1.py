"""Constantes du contrat three-voice-v1 pour la topologie des voix.

Aligné sur la décision J2 ``id-plus-n`` (identités de sortie stables).
Ces constantes sont la source d'autorité côté package ; les tests vérifient
leur cohérence avec le manifeste J2.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class VoiceSpec:
    """Spécification d'une voix du contrat three-voice-v1."""

    identity: str
    name: str
    source_staff_n: int
    rank: int
    output_mdiv_id: str
    output_order_n: str


THREE_VOICE_V1: tuple[VoiceSpec, ...] = (
    VoiceSpec(
        identity="cantus",
        name="Cantus",
        source_staff_n=1,
        rank=1,
        output_mdiv_id="j2-n-cantus",
        output_order_n="1",
    ),
    VoiceSpec(
        identity="contratenor",
        name="Contratenor",
        source_staff_n=2,
        rank=2,
        output_mdiv_id="j2-n-contratenor",
        output_order_n="2",
    ),
    VoiceSpec(
        identity="tenor",
        name="Tenor",
        source_staff_n=3,
        rank=3,
        output_mdiv_id="j2-n-tenor",
        output_order_n="3",
    ),
)

EXPECTED_VOICE_ORDER: tuple[str, ...] = tuple(spec.name for spec in THREE_VOICE_V1)

VOICE_BY_NAME: dict[str, VoiceSpec] = {spec.name: spec for spec in THREE_VOICE_V1}
