"""Politiques de lecture des voix (J3 historique + J7.1 générale)."""

from __future__ import annotations

from enum import Enum


class VoicePolicy(str, Enum):
    """Politique de construction de la topologie des voix.

    ``THREE_VOICE_V1`` : contrat historique strict (défaut public).
    ``SOURCE_ORDER_V1`` : voix libres en ordre documentaire source.
    """

    THREE_VOICE_V1 = "three-voice-v1"
    SOURCE_ORDER_V1 = "source-order-v1"


def coerce_voice_policy(policy: VoicePolicy | str | None) -> VoicePolicy:
    """Normalise une politique fournie en ``VoicePolicy``."""
    if policy is None:
        return VoicePolicy.THREE_VOICE_V1
    if isinstance(policy, VoicePolicy):
        return policy
    try:
        return VoicePolicy(policy)
    except ValueError as exc:
        allowed = ", ".join(repr(item.value) for item in VoicePolicy)
        raise ValueError(
            f"unknown voice policy {policy!r}; expected one of: {allowed}"
        ) from exc
